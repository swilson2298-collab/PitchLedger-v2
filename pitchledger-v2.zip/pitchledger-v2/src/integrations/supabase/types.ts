export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      connections: {
        Row: {
          connected_user_id: string | null
          connection_type: string | null
          created_at: string | null
          id: string
          player_id: string | null
          status: string | null
        }
        Insert: {
          connected_user_id?: string | null
          connection_type?: string | null
          created_at?: string | null
          id?: string
          player_id?: string | null
          status?: string | null
        }
        Update: {
          connected_user_id?: string | null
          connection_type?: string | null
          created_at?: string | null
          id?: string
          player_id?: string | null
          status?: string | null
        }
        Relationships: []
      }
      pitch_logs: {
        Row: {
          arm_feel: string | null
          created_by: string | null
          date: string | null
          id: string
          innings: number | null
          notes: string | null
          pitch_count: number
          player_id: string | null
          session_type: string | null
          strikes: number | null
          velo: number | null
        }
        Insert: {
          arm_feel?: string | null
          created_by?: string | null
          date?: string | null
          id?: string
          innings?: number | null
          notes?: string | null
          pitch_count: number
          player_id?: string | null
          session_type?: string | null
          strikes?: number | null
          velo?: number | null
        }
        Update: {
          arm_feel?: string | null
          created_by?: string | null
          date?: string | null
          id?: string
          innings?: number | null
          notes?: string | null
          pitch_count?: number
          player_id?: string | null
          session_type?: string | null
          strikes?: number | null
          velo?: number | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          birthdate: string | null
          full_name: string | null
          id: string
          role: string | null
          share_health_data: boolean
          stripe_customer_id: string | null
          subscription_tier: string | null
          team_code: string | null
          updated_at: string | null
        }
        Insert: {
          birthdate?: string | null
          full_name?: string | null
          id: string
          role?: string | null
          share_health_data?: boolean
          stripe_customer_id?: string | null
          subscription_tier?: string | null
          team_code?: string | null
          updated_at?: string | null
        }
        Update: {
          birthdate?: string | null
          full_name?: string | null
          id?: string
          role?: string | null
          share_health_data?: boolean
          stripe_customer_id?: string | null
          subscription_tier?: string | null
          team_code?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      public_player_search: {
        Row: {
          full_name: string | null
          id: string | null
          role: string | null
        }
        Insert: {
          full_name?: string | null
          id?: string | null
          role?: string | null
        }
        Update: {
          full_name?: string | null
          id?: string | null
          role?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      can_player_add_connection: {
        Args: { c_type: string; p_id: string }
        Returns: boolean
      }
      count_player_connections: {
        Args: { p_player_id: string; p_type: string }
        Returns: number
      }
      find_coach_by_team_code: {
        Args: { code: string }
        Returns: {
          coach_id: string
          coach_name: string
        }[]
      }
      find_player_by_email: {
        Args: { lookup_email: string }
        Returns: {
          player_id: string
          player_name: string
        }[]
      }
      generate_team_code: { Args: never; Returns: string }
      get_connected_player_ids: {
        Args: { _coach_id: string }
        Returns: string[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
