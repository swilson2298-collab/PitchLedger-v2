// PitchSmart rest day rules by age group
export interface PitchSmartRule {
  age: number;
  maxPitches: number;
  restThresholds: { pitches: number; days: number }[];
}

const pitchSmartRules: PitchSmartRule[] = [
  { age: 7, maxPitches: 50, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }] },
  { age: 8, maxPitches: 50, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }] },
  { age: 9, maxPitches: 75, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }, { pitches: 66, days: 4 }] },
  { age: 10, maxPitches: 75, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }, { pitches: 66, days: 4 }] },
  { age: 11, maxPitches: 85, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }, { pitches: 66, days: 4 }] },
  { age: 12, maxPitches: 85, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }, { pitches: 66, days: 4 }] },
  { age: 13, maxPitches: 95, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }, { pitches: 66, days: 4 }] },
  { age: 14, maxPitches: 95, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 21, days: 1 }, { pitches: 36, days: 2 }, { pitches: 51, days: 3 }, { pitches: 66, days: 4 }] },
  { age: 15, maxPitches: 95, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 76, days: 4 }] },
  { age: 16, maxPitches: 95, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 76, days: 4 }] },
  { age: 17, maxPitches: 105, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 81, days: 4 }] },
  { age: 18, maxPitches: 105, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 81, days: 4 }] },
  { age: 19, maxPitches: 120, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 81, days: 4 }, { pitches: 106, days: 5 }] },
  { age: 20, maxPitches: 120, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 81, days: 4 }, { pitches: 106, days: 5 }] },
  { age: 21, maxPitches: 120, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 81, days: 4 }, { pitches: 106, days: 5 }] },
  { age: 22, maxPitches: 120, restThresholds: [{ pitches: 1, days: 0 }, { pitches: 31, days: 1 }, { pitches: 46, days: 2 }, { pitches: 61, days: 3 }, { pitches: 81, days: 4 }, { pitches: 106, days: 5 }] },
];

export function getRulesForAge(age: number): PitchSmartRule {
  if (age <= 7) return pitchSmartRules[0];
  if (age >= 20) return pitchSmartRules[pitchSmartRules.length - 1];
  return pitchSmartRules.find(r => r.age === age) || pitchSmartRules[pitchSmartRules.length - 1];
}

export function calculateRestDays(pitchCount: number, age: number): number {
  const rules = getRulesForAge(age);
  let restDays = 0;
  for (const threshold of rules.restThresholds) {
    if (pitchCount >= threshold.pitches) {
      restDays = threshold.days;
    }
  }
  return restDays;
}

export function getAvailableDate(sessionDate: string, restDays: number): Date {
  const date = new Date(sessionDate);
  date.setDate(date.getDate() + restDays);
  return date;
}

export function getStatusColor(restDays: number): 'green' | 'yellow' | 'red' {
  if (restDays === 0) return 'green';
  if (restDays <= 2) return 'yellow';
  return 'red';
}

// ─── Types ───────────────────────────────────────────────────────────────────

export type AgeGroup = "youth" | "junior" | "hs" | "college";

export interface RecoveryDay {
  day: number;
  title: string;
  activities: string[];
  description: string;
}

type RoadmapTemplate = Record<number, RecoveryDay[]>;

// ─── Age group helper ─────────────────────────────────────────────────────────

export function getAgeGroup(age: number): AgeGroup {
  if (age <= 12) return "youth";
  if (age <= 14) return "junior";
  if (age <= 18) return "hs";
  return "college";
}

// ─── Roadmaps (single source of truth) ───────────────────────────────────────

const youthRoadmap: RoadmapTemplate = {
  0: [
    {
      day: 1,
      title: "Post-Game Stretch",
      activities: ["Post-game stretch", "Play catch tomorrow"],
      description: "Light stretch after the game. You're good to go tomorrow.",
    },
  ],
  1: [
    {
      day: 1,
      title: "No Overhead Throwing",
      activities: ["Stretching & mobility", "Light lower body activity", "Hydration focus"],
      description: "Keep the arm quiet. Light movement only — no overhead throwing today.",
    },
    {
      day: 2,
      title: "Light Catch",
      activities: ["Light catch (50–60ft)", "Post-catch stretch"],
      description: "Easy tosses to get the arm moving again. Keep it fun and low intensity.",
    },
  ],
  2: [
    {
      day: 1,
      title: "Total Rest",
      activities: ["Complete rest from throwing", "Hydrate & stretch"],
      description: "Full rest day. No throwing of any kind.",
    },
    {
      day: 2,
      title: "Mobility",
      activities: ["Light mobility work", "Easy jogging or bike", "Arm circles & stretching"],
      description: "Get blood flowing without stressing the arm.",
    },
    {
      day: 3,
      title: "Light Catch",
      activities: ["Light catch (50–60ft)", "Post-catch stretch"],
      description: "Easy tosses to rebuild arm readiness.",
    },
  ],
  3: [
    {
      day: 1,
      title: "Total Rest",
      activities: ["Complete rest", "Hydrate & nutrition focus"],
      description: "No throwing. Let the arm fully recover.",
    },
    {
      day: 2,
      title: "Total Rest",
      activities: ["Light stretching only", "Rest & recovery"],
      description: "Second day of complete rest for young arms.",
    },
    {
      day: 3,
      title: "Light Catch",
      activities: ["Light catch (60ft max)", "Easy tosses only"],
      description: "Gentle return to throwing at short distance.",
    },
  ],
  4: [
    {
      day: 1,
      title: "Total Rest",
      activities: ["Complete rest", "Hydrate"],
      description: "No throwing. Priority is rest.",
    },
    {
      day: 2,
      title: "Total Rest",
      activities: ["Light stretching", "Rest & recovery"],
      description: "Second rest day. Stay active with non-throwing activities.",
    },
    {
      day: 3,
      title: "Total Rest",
      activities: ["Mobility work", "Light activity"],
      description: "Third rest day. Body is still recovering.",
    },
    {
      day: 4,
      title: "Light Catch",
      activities: ["Light catch (60ft)", "Easy tosses"],
      description: "First throwing day. Keep it light and fun.",
    },
    {
      day: 5,
      title: "Game Ready",
      activities: ["Normal warm-up", "Full throwing"],
      description: "Cleared for game action!",
    },
  ],
};

const juniorRoadmap: RoadmapTemplate = {
  0: [
    {
      day: 1,
      title: "J-Bands + Flush Run",
      activities: ["J-Bands routine", "Flush run"],
      description: "Quick arm care and a flush run. Full go tomorrow.",
    },
    {
      day: 2,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  1: [
    {
      day: 1,
      title: "Active Recovery",
      activities: ["Light catch (60ft)", "J-Bands", "Flush run"],
      description: "Active recovery with easy catch to keep the arm loose.",
    },
    {
      day: 2,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  2: [
    {
      day: 1,
      title: "No Throw Day",
      activities: ["Bike or sprints", "Lower body work", "Stretching"],
      description: "No throwing today. Build legs and get blood flowing.",
    },
    {
      day: 2,
      title: "Light Catch",
      activities: ["Light catch (90ft)", "J-Bands", "Stretching"],
      description: "Ease back into throwing at moderate distance.",
    },
    {
      day: 3,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  3: [
    {
      day: 1,
      title: "Total Rest",
      activities: ["Complete rest from throwing", "Hydrate & stretch"],
      description: "Full rest day to start recovery.",
    },
    {
      day: 2,
      title: "Mobility & Sprints",
      activities: ["Sprint work", "Mobility drills", "J-Bands"],
      description: "Build athleticism without stressing the arm.",
    },
    {
      day: 3,
      title: "Light Catch",
      activities: ["Light catch (90ft)", "Easy long toss"],
      description: "Return to throwing at moderate intensity.",
    },
    {
      day: 4,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  4: [
    {
      day: 1,
      title: "Total Rest",
      activities: ["Complete rest", "Hydrate & nutrition"],
      description: "No throwing. Let the arm fully recover.",
    },
    {
      day: 2,
      title: "Lower Body Work",
      activities: ["Squats & lunges", "Core work", "Mobility"],
      description: "Build the foundation while the arm rests.",
    },
    {
      day: 3,
      title: "Light Catch",
      activities: ["Light catch (90ft)", "Easy tosses"],
      description: "First throwing day. Keep it controlled.",
    },
    {
      day: 4,
      title: "Touch & Feel Pen",
      activities: ["Bullpen at 70–80%", "Command focus", "Cool-down stretch"],
      description: "Reconnect with the mound at reduced effort.",
    },
    {
      day: 5,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
};

const hsRoadmap: RoadmapTemplate = {
  0: [
    {
      day: 1,
      title: "J-Bands + Flush Run",
      activities: ["J-Bands routine", "Flush run"],
      description: "Quick arm care and a flush run. Full go tomorrow.",
    },
    {
      day: 2,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  1: [
    {
      day: 1,
      title: "Recovery Throwing",
      activities: ["Recovery throwing (90ft)", "J-Bands", "Flush run"],
      description: "Light throwing to keep the arm active and promote blood flow.",
    },
    {
      day: 2,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  2: [
    {
      day: 1,
      title: "No Throw / Bike",
      activities: ["Bike or light cardio", "J-Bands", "Foam rolling"],
      description: "No throwing. Focus on recovery modalities.",
    },
    {
      day: 2,
      title: "Touch & Feel",
      activities: ["Flat ground work", "Light catch (100ft)", "Stretching"],
      description: "Easy throwing to reconnect with mechanics.",
    },
    {
      day: 3,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  3: [
    {
      day: 1,
      title: "Rest",
      activities: ["Complete rest from throwing", "Foam roll & stretch"],
      description: "Full rest to start the recovery process.",
    },
    {
      day: 2,
      title: "Sprints & Lift",
      activities: ["Sprint work", "Upper/lower lift", "J-Bands"],
      description: "Build strength while the arm recovers.",
    },
    {
      day: 3,
      title: "Long Toss",
      activities: ["Progressive long toss (120+ ft)", "Cool-down stretch"],
      description: "Rebuild arm speed gradually with long toss.",
    },
    {
      day: 4,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  4: [
    {
      day: 1,
      title: "Rest",
      activities: ["Complete rest", "Recovery modalities"],
      description: "No throwing. Prioritize sleep and nutrition.",
    },
    {
      day: 2,
      title: "Lift",
      activities: ["Full lift session", "Core work", "Mobility"],
      description: "Strength training while the arm rests.",
    },
    {
      day: 3,
      title: "Catch",
      activities: ["Light catch (100ft)", "J-Bands", "Stretching"],
      description: "First throwing day. Keep it easy.",
    },
    {
      day: 4,
      title: "Bullpen",
      activities: ["Bullpen (40–50 pitches at 80%)", "Command focus", "Cool-down"],
      description: "Mound work at reduced effort. Focus on feel.",
    },
    {
      day: 5,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
};

const collegeRoadmap: RoadmapTemplate = {
  0: [
    {
      day: 1,
      title: "Arm Care Protocol",
      activities: ["Personalized arm care routine", "J-Bands", "Flush run"],
      description: "Follow your program's arm care protocol.",
    },
  ],
  1: [
    {
      day: 1,
      title: "Arm Care Protocol",
      activities: ["Personalized arm care routine", "J-Bands", "Flush run"],
      description: "Follow your program's arm care protocol.",
    },
    {
      day: 2,
      title: "Return to Throwing",
      activities: ["Throwing program", "Arm care"],
      description: "Resume throwing per program guidelines.",
    },
  ],
  2: [
    {
      day: 1,
      title: "Recovery Day",
      activities: ["Recovery modalities", "Light cardio", "Arm care"],
      description: "Follow personalized recovery protocol.",
    },
    {
      day: 2,
      title: "Active Recovery",
      activities: ["Light cardio", "Arm care", "Mobility"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 3,
      title: "Return to Throwing",
      activities: ["Throwing program", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
  ],
  3: [
    {
      day: 1,
      title: "Rest",
      activities: ["Complete rest", "Recovery modalities"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 2,
      title: "Active Recovery",
      activities: ["Light cardio", "Arm care", "Mobility"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 3,
      title: "Light Throwing",
      activities: ["Light catch", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 4,
      title: "Return to Throwing",
      activities: ["Throwing program", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
  ],
  4: [
    {
      day: 1,
      title: "Rest",
      activities: ["Complete rest"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 2,
      title: "Recovery",
      activities: ["Recovery modalities", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 3,
      title: "Light Throwing",
      activities: ["Light catch", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 4,
      title: "Bullpen",
      activities: ["Bullpen session", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 5,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
  // restDays: 5 applies to ages 19–22 only (106+ pitches per PitchSmart rules).
  // Other age groups never reach this threshold, so this entry is college-only.
  5: [
    {
      day: 1,
      title: "Rest",
      activities: ["Complete rest", "Recovery modalities"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 2,
      title: "Rest",
      activities: ["Complete rest", "Hydration & nutrition focus"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 3,
      title: "Active Recovery",
      activities: ["Light cardio", "Arm care", "Mobility"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 4,
      title: "Light Throwing",
      activities: ["Light catch", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 5,
      title: "Bullpen",
      activities: ["Bullpen session", "Arm care"],
      description: "Follow personalized arm-care protocol.",
    },
    {
      day: 6,
      title: "Full Go",
      activities: ["Normal throwing program"],
      description: "Full throwing activity.",
    },
  ],
};

// ─── Roadmap lookup ───────────────────────────────────────────────────────────

const roadmapsByGroup: Record<AgeGroup, RoadmapTemplate> = {
  youth: youthRoadmap,
  junior: juniorRoadmap,
  hs: hsRoadmap,
  college: collegeRoadmap,
};

export function getRoadmap(restDays: number, age: number = 14): RecoveryDay[] {
  const group = getAgeGroup(age);
  const template = roadmapsByGroup[group];
  return template[restDays] ?? [];
}

// ─── Emoji severity map ───────────────────────────────────────────────────────

const severityEmoji: Record<number, string> = {
  0: "🟢",
  1: "🟡",
  2: "🟠",
  3: "🔴",
  4: "🛑",
  5: "🛑", // college/pro only — 106+ pitches per PitchSmart rules
};

const groupLabel: Record<AgeGroup, string> = {
  youth: "Youth",
  junior: "Junior",
  hs: "HS",
  college: "College/Pro",
};

// ─── Derived quick recovery (no longer hand-written) ─────────────────────────

export function getQuickRecovery(restDays: number, age: number = 14): string {
  const group = getAgeGroup(age);
  const days = getRoadmap(restDays, age);

  if (days.length === 0) return "Follow your recovery plan.";

  const emoji = severityEmoji[restDays] ?? "🟢";
  const label = groupLabel[group];

  // Build "Day N: Title" segments from the roadmap entries
  const segments = days
    .map((d) => `Day ${d.day}: ${d.title}`)
    .join(". ");

  return `${emoji} ${label} Recovery: ${segments}.`;
}

export type SessionType = 'Game' | 'Practice' | 'Lesson' | 'Bullpen' | 'Other';

export interface PitchEntry {
  id: string;
  date: string;
  pitchCount: number;
  sessionType: SessionType;
  innings: number;
  notes: string;
  restDays: number;
  availableDate: string;
}

export interface PlayerProfile {
  name: string;
  age: number;
}

// Full rest day breakdown table
export interface RestDayRow {
  ageRange: string;
  max: number;
  rest: { days: number; range: string }[];
}

export function getRestDayTable(): RestDayRow[] {
  return [
    { ageRange: "7-8", max: 50, rest: [{ days: 0, range: "1-20" }, { days: 1, range: "21-35" }, { days: 2, range: "36-50" }, { days: 3, range: "N/A" }, { days: 4, range: "N/A" }, { days: 5, range: "N/A" }] },
    { ageRange: "9-10", max: 75, rest: [{ days: 0, range: "1-20" }, { days: 1, range: "21-35" }, { days: 2, range: "36-50" }, { days: 3, range: "51-65" }, { days: 4, range: "66+" }, { days: 5, range: "N/A" }] },
    { ageRange: "11-12", max: 85, rest: [{ days: 0, range: "1-20" }, { days: 1, range: "21-35" }, { days: 2, range: "36-50" }, { days: 3, range: "51-65" }, { days: 4, range: "66+" }, { days: 5, range: "N/A" }] },
    { ageRange: "13-14", max: 95, rest: [{ days: 0, range: "1-20" }, { days: 1, range: "21-35" }, { days: 2, range: "36-50" }, { days: 3, range: "51-65" }, { days: 4, range: "66+" }, { days: 5, range: "N/A" }] },
    { ageRange: "15-16", max: 95, rest: [{ days: 0, range: "1-30" }, { days: 1, range: "31-45" }, { days: 2, range: "46-60" }, { days: 3, range: "61-75" }, { days: 4, range: "76+" }, { days: 5, range: "N/A" }] },
    { ageRange: "17-18", max: 105, rest: [{ days: 0, range: "1-30" }, { days: 1, range: "31-45" }, { days: 2, range: "46-60" }, { days: 3, range: "61-80" }, { days: 4, range: "81+" }, { days: 5, range: "N/A" }] },
    { ageRange: "19-22", max: 120, rest: [{ days: 0, range: "1-30" }, { days: 1, range: "31-45" }, { days: 2, range: "46-60" }, { days: 3, range: "61-80" }, { days: 4, range: "81-105" }, { days: 5, range: "106+" }] },
  ];
}

// Max pitch count reference table (simple version)
export function getMaxPitchTable(): { ageRange: string; max: number }[] {
  return getRestDayTable().map(r => ({ ageRange: r.ageRange, max: r.max }));
}

export interface AgeGuideline {
  ageRange: string;
  distance: string;
  maxInnings: string;
  guidelines: string[];
}

export function getAgeGuidelines(): AgeGuideline[] {
  return [
    {
      ageRange: "8 & Younger",
      distance: "46' Pitching Distance",
      maxInnings: "60 innings / 12 months",
      guidelines: [
        "Focus on athleticism, physical fitness, and fun",
        "Focus on learning baseball rules, general techniques, and teamwork",
        "Do not exceed 60 combined innings pitched in any 12 month period",
        "Take at least 4 months off from throwing every year, with at least 2-3 of those months being continuous",
        "Make sure to properly warm up before pitching",
        "Set and follow pitch-count limits and required rest periods",
        "Avoid throwing pitches other than fastballs and change-ups",
        "Avoid playing for multiple teams at the same time",
        "Avoid playing catcher while not pitching",
        "Players should not pitch in multiple games on the same day",
        "Play other sports during the course of the year",
        "Monitor for other signs of fatigue",
        "Pitchers once removed from the mound may not return as pitchers",
        "No pitcher shall appear in a game as a pitcher for three consecutive days, regardless of pitch counts",
      ],
    },
    {
      ageRange: "9-12",
      distance: "46-50' Pitching Distance",
      maxInnings: "80 innings / 12 months",
      guidelines: [
        "Focus on athleticism, physical fitness, and fun",
        "Focus on learning baseball rules, general techniques, and teamwork",
        "Do not exceed 80 combined innings pitched in any 12 month period",
        "Take at least 4 months off from throwing every year, with at least 2-3 of those months being continuous",
        "Make sure to properly warm up before pitching",
        "Set and follow pitch-count limits and required rest periods",
        "Avoid throwing pitches other than fastballs and change-ups",
        "Avoid playing for multiple teams at the same time",
        "Avoid playing catcher while not pitching",
        "Players should not pitch in multiple games on the same day",
        "Play other sports during the course of the year",
        "Monitor for other signs of fatigue",
        "Pitchers once removed from the mound may not return as pitchers",
        "No pitcher shall appear in a game as a pitcher for three consecutive days, regardless of pitch counts",
      ],
    },
    {
      ageRange: "13-14",
      distance: "60' Pitching Distance",
      maxInnings: "100 innings / 12 months",
      guidelines: [
        "Players can begin using breaking pitches after developing consistent fastball and changeup",
        "Do not exceed 100 combined innings pitched in any 12 month period",
        "Take at least 4 months off from throwing every year, with at least 2-3 of those months being continuous",
        "Make sure to properly warm up before pitching",
        "Set and follow pitch-count limits and required rest periods",
        "Avoid playing for multiple teams at the same time",
        "Avoid playing catcher while not pitching",
        "Players should not pitch in multiple games on the same day",
        "Play other sports during the course of the year",
        "Monitor for other signs of fatigue",
        "A pitcher remaining in the game, but moving to a different position, can return as a pitcher anytime in the remainder of the game, but only once per game",
        "No pitcher shall appear in a game as a pitcher for three consecutive days, regardless of pitch counts",
      ],
    },
    {
      ageRange: "15-18",
      distance: "60' Pitching Distance",
      maxInnings: "100 innings / 12 months",
      guidelines: [
        "Players can begin using breaking pitches after developing consistent fastball and changeup",
        "Do not exceed 100 combined innings pitched in any 12 month period",
        "Take at least 4 months off from competitive pitching every year, including at least 2-3 continuous months off from all overhead throwing",
        "Make sure to properly warm up before pitching",
        "Set and follow pitch-count limits and required rest periods",
        "Avoid playing for multiple teams at the same time",
        "Avoid playing catcher while not pitching",
        "Players should not pitch in multiple games on the same day",
        "Make sure to follow guidelines across leagues, tournaments and showcases",
        "Monitor for other signs of fatigue",
        "A pitcher remaining in the game, but moving to a different position, can return as a pitcher anytime in the remainder of the game, but only once per game",
        "No pitcher shall appear in a game as a pitcher for three consecutive days, regardless of pitch counts",
      ],
    },
    {
      ageRange: "19-22",
      distance: "60'6\" Pitching Distance",
      maxInnings: "Varies by program",
      guidelines: [
        "Keep track of the amount of pitching throughout the course of the year. Although the safe yearly limit varies from pitcher to pitcher, it is important to remember that overuse injuries are the result of short-term and long-term overuse",
        "Take at least 3 months off from competitive pitching every year, including at least 4 continuous weeks off from all overhead throwing",
        "Make sure to properly warm up before pitching",
        "Set and follow pitch-count limits and required rest periods",
        "Avoid playing for multiple teams at the same time",
        "Avoid playing catcher while not pitching",
        "Players should not pitch in multiple games on the same day",
        "Make sure to follow guidelines across leagues, tournaments and showcases",
        "Monitor for other signs of fatigue",
        "No pitcher shall appear in a game as a pitcher for three consecutive days, regardless of pitch counts",
      ],
    },
  ];
}

export const redFlags = [
  "Pain on the medial (inside) elbow during or after throwing",
  "Sharp pain in the shoulder, especially during acceleration",
  "Numbness or tingling in fingers or forearm",
  "Loss of extension — can't fully straighten the arm",
  "Decreased velocity over multiple outings without fatigue explanation",
  "Swelling around the elbow or shoulder joint",
  "Pain that persists beyond 24 hours after throwing",
  "Catching or locking sensation in the elbow",
];

// Alias for backward compatibility
export const getRecoveryRoadmap = getRoadmap;
