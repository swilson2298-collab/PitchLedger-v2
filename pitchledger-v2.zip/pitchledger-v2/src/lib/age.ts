import { differenceInYears } from 'date-fns';

export function calculateAge(birthdate: string | Date): number {
  const bd = typeof birthdate === 'string' ? new Date(birthdate) : birthdate;
  return differenceInYears(new Date(), bd);
}
