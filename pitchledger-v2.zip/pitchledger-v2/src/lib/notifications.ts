const NOTIF_KEY = 'pitchtracker_notifications';

export async function requestNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  const result = await Notification.requestPermission();
  return result === 'granted';
}

export function getNotificationPermission(): NotificationPermission | 'unsupported' {
  if (!('Notification' in window)) return 'unsupported';
  return Notification.permission;
}

interface ScheduledNotif {
  id: string;
  timeoutId?: number;
  day: number;
  title: string;
  body: string;
  scheduledAt: number; // timestamp
}

let activeTimeouts: Map<string, number> = new Map();

export function scheduleRecoveryReminders(
  sessionDate: string,
  roadmap: { day: number; title: string; activities: string[] }[]
) {
  clearAllReminders();

  const baseDate = new Date(sessionDate);
  const reminders: ScheduledNotif[] = [];

  for (const step of roadmap) {
    const reminderDate = new Date(baseDate);
    reminderDate.setDate(reminderDate.getDate() + step.day);
    reminderDate.setHours(8, 0, 0, 0); // 8 AM reminder

    const now = Date.now();
    const delay = reminderDate.getTime() - now;

    if (delay <= 0) continue; // skip past reminders

    const id = `recovery-day-${step.day}`;
    const body = step.activities.slice(0, 2).join(', ');

    const timeoutId = window.setTimeout(() => {
      new Notification(`Day ${step.day}: ${step.title}`, {
        body: `Today's recovery: ${body}`,
        icon: '/favicon.ico',
        tag: id,
      });
    }, delay);

    activeTimeouts.set(id, timeoutId);
    reminders.push({ id, day: step.day, title: step.title, body, scheduledAt: reminderDate.getTime() });
  }

  localStorage.setItem(NOTIF_KEY, JSON.stringify(reminders));
}

export function clearAllReminders() {
  activeTimeouts.forEach((id) => window.clearTimeout(id));
  activeTimeouts.clear();
  localStorage.removeItem(NOTIF_KEY);
}

export function getScheduledReminders(): ScheduledNotif[] {
  const data = localStorage.getItem(NOTIF_KEY);
  return data ? JSON.parse(data) : [];
}

export function areRemindersEnabled(): boolean {
  return localStorage.getItem(NOTIF_KEY) !== null;
}
