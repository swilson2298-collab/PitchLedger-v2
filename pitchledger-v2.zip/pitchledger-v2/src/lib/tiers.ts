// Stripe product/price mapping for PitchLedger tiers
export const TIERS = {
  premium_player: {
    product_id: 'prod_UGo16EGfPt1fAh',
    price_id: 'price_1TIGPOCND7ZmXVzMghpcQx8y',
    label: 'Premium Player',
    price: '$2.99/mo',
    role: 'player',
    features: [
      'Unlimited team & trainer connections',
      'Advanced pitch analytics',
      'Priority recovery recommendations',
      'Export & share reports',
    ],
  },
  premium_coach: {
    product_id: 'prod_UGo2EnX68mnBEJ',
    price_id: 'price_1TIGQRCND7ZmXVzMjS0HKdr9',
    label: 'Premium Coach',
    price: '$4.99/mo',
    role: 'coach',
    features: [
      'Unlimited roster connections',
      'PDF roster & player reports',
      'Velocity trend charts',
      'Advanced team analytics',
    ],
  },
  premium_trainer: {
    product_id: 'prod_UGo2pIdz6bivtt',
    price_id: 'price_1TIGQiCND7ZmXVzMXxi4YC2i',
    label: 'Premium Trainer',
    price: '$9.99/mo',
    role: 'trainer',
    features: [
      'Unlimited player connections',
      'Team Health Dashboard',
      'PDF scouting reports',
      'Video analysis tools',
    ],
  },
} as const;

export type TierKey = keyof typeof TIERS;

/** Get the upgrade tier for a given user role */
export function getTierForRole(role: string | null): TierKey | null {
  switch (role) {
    case 'player':
    case 'parent':
      return 'premium_player';
    case 'coach':
      return 'premium_coach';
    case 'trainer':
      return 'premium_trainer';
    default:
      return null;
  }
}
