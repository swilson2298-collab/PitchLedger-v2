import jsPDF from 'jspdf';

interface ReportData {
  playerName: string;
  role: string;
  teamName: string;
  graduationYear: string;
  veloData: { date: string; velo: number }[];
  maxVelo: number | null;
  avgVelo: number | null;
  strikePercentage: number | null;
  armFeelSummary: { healthy: number; mild: number; sore: number };
  totalSessions30d: number;
  coachNote: string;
  coachName: string;
}

function drawLine(doc: jsPDF, data: ReportData, margin: number, y: number, pageW: number): number {
  const chartW = pageW - margin * 2;
  const chartH = 130;
  const chartX = margin;
  const chartY = y;
  const padL = 36;
  const padR = 12;
  const padT = 12;
  const padB = 22;
  const plotW = chartW - padL - padR;
  const plotH = chartH - padT - padB;

  // Background
  doc.setFillColor(248, 249, 252);
  doc.roundedRect(chartX, chartY, chartW, chartH, 6, 6, 'F');

  const velos = data.veloData.map(v => v.velo);
  const minV = Math.min(...velos) - 2;
  const maxV = Math.max(...velos) + 2;
  const range = maxV - minV || 1;

  // Y-axis grid
  doc.setDrawColor(230, 232, 238);
  doc.setLineWidth(0.3);
  for (let i = 0; i <= 4; i++) {
    const gy = chartY + padT + (plotH / 4) * i;
    doc.line(chartX + padL, gy, chartX + padL + plotW, gy);
    const val = Math.round(maxV - (range / 4) * i);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(160, 163, 175);
    doc.text(`${val}`, chartX + padL - 6, gy + 3, { align: 'right' });
  }

  // Plot line + dots
  const n = data.veloData.length;
  const points = data.veloData.map((v, i) => ({
    x: chartX + padL + (i / Math.max(n - 1, 1)) * plotW,
    y: chartY + padT + plotH - ((v.velo - minV) / range) * plotH,
  }));

  // Gradient fill under line
  if (points.length > 1) {
    doc.setDrawColor(56, 199, 110);
    doc.setLineWidth(2);
    for (let i = 0; i < points.length - 1; i++) {
      doc.line(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
    }
  }

  // Dots
  points.forEach((p, i) => {
    doc.setFillColor(56, 199, 110);
    doc.circle(p.x, p.y, 3, 'F');
    doc.setFillColor(255, 255, 255);
    doc.circle(p.x, p.y, 1.5, 'F');
  });

  // X-axis date labels
  data.veloData.forEach((v, i) => {
    const px = chartX + padL + (i / Math.max(n - 1, 1)) * plotW;
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(160, 163, 175);
    doc.text(v.date, px, chartY + chartH - 4, { align: 'center' });
  });

  return chartY + chartH;
}

export function generateScoutingReport(data: ReportData) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'letter' });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 48;
  let y = 0;

  // ─── Header ───
  doc.setFillColor(15, 20, 30);
  doc.rect(0, 0, pageW, 72, 'F');

  // Accent line
  doc.setFillColor(56, 199, 110);
  doc.rect(0, 72, pageW, 3, 'F');

  doc.setTextColor(56, 199, 110);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('PitchLedger', margin, 32);

  doc.setFontSize(10);
  doc.setTextColor(200, 205, 215);
  doc.setFont('helvetica', 'normal');
  doc.text('SCOUTING REPORT', margin, 50);

  // Right side: player name + grad year
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(data.playerName, pageW - margin, 30, { align: 'right' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(200, 205, 215);
  doc.text(`Class of ${data.graduationYear}  ·  ${data.teamName}`, pageW - margin, 48, { align: 'right' });

  y = 95;

  // ─── Stats Grid ───
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(120, 125, 140);
  doc.text('PERFORMANCE SNAPSHOT', margin, y);
  y += 16;

  const statsW = (pageW - margin * 2 - 24) / 3;
  const stats = [
    { label: 'MAX VELOCITY', value: data.maxVelo ? `${data.maxVelo}` : '—', unit: 'mph' },
    { label: 'AVG VELOCITY', value: data.avgVelo ? `${data.avgVelo}` : '—', unit: 'mph' },
    { label: 'STRIKE %', value: data.strikePercentage != null ? `${data.strikePercentage}` : '—', unit: '%' },
  ];

  stats.forEach((s, i) => {
    const sx = margin + i * (statsW + 12);
    doc.setFillColor(248, 249, 252);
    doc.roundedRect(sx, y, statsW, 56, 6, 6, 'F');

    // Border accent top
    doc.setFillColor(56, 199, 110);
    doc.roundedRect(sx, y, statsW, 3, 6, 6, 'F');

    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(140, 145, 158);
    doc.text(s.label, sx + statsW / 2, y + 18, { align: 'center' });

    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(30, 35, 50);
    doc.text(s.value, sx + statsW / 2, y + 42, { align: 'center' });

    if (s.value !== '—') {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(140, 145, 158);
      const valWidth = doc.getTextWidth(s.value) * 22 / doc.getFontSize();
      doc.text(s.unit, sx + statsW / 2 + valWidth / 2 + 2, y + 42);
    }
  });

  y += 74;

  // ─── Velocity Chart ───
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(120, 125, 140);
  doc.text('VELOCITY PROGRESSION', margin, y);
  y += 14;

  if (data.veloData.length >= 2) {
    y = drawLine(doc, data, margin, y, pageW) + 18;
  } else if (data.veloData.length === 1) {
    doc.setFillColor(248, 249, 252);
    doc.roundedRect(margin, y, pageW - margin * 2, 40, 6, 6, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(140, 145, 158);
    doc.text(`Single session recorded: ${data.veloData[0].velo} mph on ${data.veloData[0].date}`, margin + 12, y + 24);
    y += 58;
  } else {
    doc.setFillColor(248, 249, 252);
    doc.roundedRect(margin, y, pageW - margin * 2, 40, 6, 6, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(140, 145, 158);
    doc.text('No velocity data recorded yet', margin + 12, y + 24);
    y += 58;
  }

  // ─── Health Audit ───
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(120, 125, 140);
  doc.text('30-DAY HEALTH AUDIT', margin, y);
  y += 14;

  const healthW = (pageW - margin * 2 - 24) / 3;
  const total = data.armFeelSummary.healthy + data.armFeelSummary.mild + data.armFeelSummary.sore;

  const healthStats = [
    { label: 'HEALTHY', value: `${data.armFeelSummary.healthy}`, color: [56, 199, 110] as [number, number, number], pct: total > 0 ? Math.round((data.armFeelSummary.healthy / total) * 100) : 0 },
    { label: 'MILD SORENESS', value: `${data.armFeelSummary.mild}`, color: [245, 166, 35] as [number, number, number], pct: total > 0 ? Math.round((data.armFeelSummary.mild / total) * 100) : 0 },
    { label: 'SORE', value: `${data.armFeelSummary.sore}`, color: [220, 80, 80] as [number, number, number], pct: total > 0 ? Math.round((data.armFeelSummary.sore / total) * 100) : 0 },
  ];

  healthStats.forEach((h, i) => {
    const hx = margin + i * (healthW + 12);

    doc.setFillColor(248, 249, 252);
    doc.roundedRect(hx, y, healthW, 52, 6, 6, 'F');

    // Color bar
    doc.setFillColor(h.color[0], h.color[1], h.color[2]);
    doc.roundedRect(hx, y, healthW, 3, 6, 6, 'F');

    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(140, 145, 158);
    doc.text(h.label, hx + healthW / 2, y + 17, { align: 'center' });

    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(30, 35, 50);
    doc.text(`${h.value}`, hx + healthW / 2 - 8, y + 38, { align: 'center' });

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(140, 145, 158);
    doc.text(`(${h.pct}%)`, hx + healthW / 2 + 12, y + 38, { align: 'center' });
  });

  y += 70;

  // ─── Sessions count ───
  doc.setFillColor(248, 249, 252);
  doc.roundedRect(margin, y, pageW - margin * 2, 28, 6, 6, 'F');
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 105, 120);
  doc.text(`${data.totalSessions30d} total sessions in the last 30 days`, margin + 14, y + 18);
  y += 42;

  // ─── Coach's Evaluation ───
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(120, 125, 140);
  doc.text("COACH'S EVALUATION", margin, y);
  y += 14;

  const noteText = data.coachNote || 'No evaluation provided.';
  const noteLines = doc.splitTextToSize(noteText, pageW - margin * 2 - 24);
  const noteBoxH = Math.max(50, noteLines.length * 14 + 20);

  doc.setFillColor(248, 249, 252);
  doc.roundedRect(margin, y, pageW - margin * 2, noteBoxH, 6, 6, 'F');

  // Left accent bar
  doc.setFillColor(56, 199, 110);
  doc.rect(margin, y + 4, 3, noteBoxH - 8, 'F');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 55, 70);
  doc.text(noteLines, margin + 16, y + 16);

  y += noteBoxH + 6;

  // Coach attribution
  doc.setFontSize(8);
  doc.setTextColor(160, 163, 175);
  doc.text(`— ${data.coachName}`, margin + 16, y + 4);

  // ─── Footer ───
  doc.setDrawColor(230, 232, 238);
  doc.setLineWidth(0.5);
  doc.line(margin, pageH - 36, pageW - margin, pageH - 36);

  doc.setFontSize(7);
  doc.setTextColor(160, 163, 175);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated ${new Date().toLocaleDateString()} via PitchLedger`, margin, pageH - 22);
  doc.text('pitchledger.lovable.app', pageW - margin, pageH - 22, { align: 'right' });

  doc.save(`ScoutingReport_${data.playerName.replace(/\s+/g, '_')}.pdf`);
}
