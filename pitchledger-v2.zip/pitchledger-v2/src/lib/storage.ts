import { PitchEntry, PlayerProfile } from './pitchLogic';

const ENTRIES_KEY = 'pitchtracker_entries';
const PROFILE_KEY = 'pitchtracker_profile';

export function getEntries(): PitchEntry[] {
  const data = localStorage.getItem(ENTRIES_KEY);
  return data ? JSON.parse(data) : [];
}

export function saveEntries(entries: PitchEntry[]): void {
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
}

export function addEntry(entry: PitchEntry): void {
  const entries = getEntries();
  entries.unshift(entry);
  saveEntries(entries);
}

export function getProfile(): PlayerProfile {
  const data = localStorage.getItem(PROFILE_KEY);
  return data ? JSON.parse(data) : { name: '', age: 14 };
}

export function saveProfile(profile: PlayerProfile): void {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}
