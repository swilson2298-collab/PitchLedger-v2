/**
 * PitchSmart Automated Rest Engine
 * 
 * Calculates mandatory rest, availability status, and daily max
 * based on age-bracket medical specs.
 */

import { calculateAge } from '@/lib/age';
import { addDays, differenceInCalendarDays, format, parseISO, isAfter, startOfDay } from 'date-fns';

// ── Age Brackets ──
export type AgeBracket = '7-8' | '9-10' | '11-12' | '13-14' | '15-16' | '17-18' | '19-22';

export function getAgeBracket(age: number): AgeBracket {
  if (age <= 8) return '7-8';
  if (age <= 10) return '9-10';
  if (age <= 12) return '11-12';
  if (age <= 14) return '13-14';
  if (age <= 16) return '15-16';
  if (age <= 18) return '17-18';
  return '19-22';
}

// ── Rest Thresholds by bracket ──
interface BracketConfig {
  dailyMax: number;
  thresholds: { min: number; max: number | null; days: number }[];
}

const bracketConfigs: Record<AgeBracket, BracketConfig> = {
  '7-8': {
    dailyMax: 50,
    thresholds: [
      { min: 0, max: 20, days: 0 },
      { min: 21, max: 35, days: 1 },
      { min: 36, max: 50, days: 2 },
    ],
  },
  '9-10': {
    dailyMax: 75,
    thresholds: [
      { min: 0, max: 20, days: 0 },
      { min: 21, max: 35, days: 1 },
      { min: 36, max: 50, days: 2 },
      { min: 51, max: 65, days: 3 },
      { min: 66, max: null, days: 4 },
    ],
  },
  '11-12': {
    dailyMax: 85,
    thresholds: [
      { min: 0, max: 20, days: 0 },
      { min: 21, max: 35, days: 1 },
      { min: 36, max: 50, days: 2 },
      { min: 51, max: 65, days: 3 },
      { min: 66, max: null, days: 4 },
    ],
  },
  '13-14': {
    dailyMax: 95,
    thresholds: [
      { min: 0, max: 20, days: 0 },
      { min: 21, max: 35, days: 1 },
      { min: 36, max: 50, days: 2 },
      { min: 51, max: 65, days: 3 },
      { min: 66, max: null, days: 4 },
    ],
  },
  '15-16': {
    dailyMax: 95,
    thresholds: [
      { min: 0, max: 30, days: 0 },
      { min: 31, max: 45, days: 1 },
      { min: 46, max: 60, days: 2 },
      { min: 61, max: 80, days: 3 },
      { min: 81, max: null, days: 4 },
    ],
  },
  '17-18': {
    dailyMax: 105,
    thresholds: [
      { min: 0, max: 30, days: 0 },
      { min: 31, max: 45, days: 1 },
      { min: 46, max: 60, days: 2 },
      { min: 61, max: 80, days: 3 },
      { min: 81, max: null, days: 4 },
    ],
  },
  '19-22': {
    dailyMax: 120,
    thresholds: [
      { min: 0, max: 30, days: 0 },
      { min: 31, max: 45, days: 1 },
      { min: 46, max: 60, days: 2 },
      { min: 61, max: 80, days: 3 },
      { min: 81, max: 105, days: 4 },
      { min: 106, max: null, days: 5 },
    ],
  },
};

// ── Weekly Limits by age bracket ──
const weeklyLimits: Record<AgeBracket, number> = {
  '7-8': 100,
  '9-10': 150,
  '11-12': 175,
  '13-14': 200,
  '15-16': 250,
  '17-18': 300,
  '19-22': 350,
};

export function getWeeklyLimit(age: number): number {
  return weeklyLimits[getAgeBracket(age)];
}

export function getBracketConfig(age: number): BracketConfig {
  return bracketConfigs[getAgeBracket(age)];
}

export function getDailyMax(age: number): number {
  return getBracketConfig(age).dailyMax;
}

export function getRequiredRestDays(pitchCount: number, age: number): number {
  const config = getBracketConfig(age);
  let rest = 0;
  for (const t of config.thresholds) {
    if (pitchCount >= t.min && (t.max === null || pitchCount <= t.max)) {
      rest = t.days;
    }
  }
  // If exceeds all thresholds, use max rest
  const lastThreshold = config.thresholds[config.thresholds.length - 1];
  if (pitchCount > (lastThreshold.max ?? pitchCount)) {
    rest = lastThreshold.days;
  }
  return rest;
}

// ── Availability Status ──
export type AvailabilityStatus = 'FRESH' | 'CAUTION' | 'SHUT_DOWN';

export interface AvailabilityResult {
  status: AvailabilityStatus;
  eligibleDate: Date | null;       // null if FRESH
  daysUntilEligible: number;       // 0 if FRESH
  reason: string;
  restDays: number;                // raw rest from last session
  sorenessValue: number;           // 0-10
}

// Map arm_feel strings to numeric soreness (higher = worse)
export function armFeelToSoreness(armFeel: string | null | undefined): number {
  if (!armFeel) return 0;
  const map: Record<string, number> = {
    'great': 1, 'fresh': 2, 'good': 3, 'normal': 4,
    'fatigued': 5, 'tight': 6, 'sore': 8, 'pain': 10,
  };
  return map[armFeel.toLowerCase()] ?? 0;
}

export interface PitchLogEntry {
  date: string | null;
  pitch_count: number;
  arm_feel: string | null;
}

/**
 * Calculate a player's availability from their most recent pitch log.
 */
export function calculateAvailability(
  lastLog: PitchLogEntry | null,
  age: number,
): AvailabilityResult {
  const today = startOfDay(new Date());
  const soreness = armFeelToSoreness(lastLog?.arm_feel);

  // No logs at all → FRESH
  if (!lastLog || !lastLog.date) {
    return { status: 'FRESH', eligibleDate: null, daysUntilEligible: 0, reason: 'No recent sessions', restDays: 0, sorenessValue: soreness };
  }

  const sessionDate = startOfDay(parseISO(lastLog.date));
  const restDays = getRequiredRestDays(lastLog.pitch_count, age);
  const eligibleDate = addDays(sessionDate, restDays);
  const daysUntilEligible = Math.max(0, differenceInCalendarDays(eligibleDate, today));

  // SHUT DOWN conditions
  if (daysUntilEligible > 0) {
    return {
      status: 'SHUT_DOWN',
      eligibleDate,
      daysUntilEligible,
      reason: `${daysUntilEligible}d rest remaining (${lastLog.pitch_count} pitches)`,
      restDays,
      sorenessValue: soreness,
    };
  }
  if (soreness >= 7) {
    return {
      status: 'SHUT_DOWN',
      eligibleDate: null,
      daysUntilEligible: 0,
      reason: `Arm soreness too high (${lastLog.arm_feel})`,
      restDays,
      sorenessValue: soreness,
    };
  }

  // CAUTION conditions
  if (daysUntilEligible === 0 && restDays > 0) {
    // Just cleared today — within 1 day of rest ending
    const daysSinceSession = differenceInCalendarDays(today, sessionDate);
    if (daysSinceSession <= restDays) {
      return {
        status: 'CAUTION',
        eligibleDate,
        daysUntilEligible: 0,
        reason: 'Just cleared rest window',
        restDays,
        sorenessValue: soreness,
      };
    }
  }
  if (soreness >= 5 && soreness <= 6) {
    return {
      status: 'CAUTION',
      eligibleDate: null,
      daysUntilEligible: 0,
      reason: `Moderate soreness (${lastLog.arm_feel})`,
      restDays,
      sorenessValue: soreness,
    };
  }

  // FRESH
  return {
    status: 'FRESH',
    eligibleDate: null,
    daysUntilEligible: 0,
    reason: soreness < 3 ? 'All clear' : 'Ready to pitch',
    restDays,
    sorenessValue: soreness,
  };
}

/**
 * Sort priority: SHUT_DOWN first, then CAUTION, then FRESH
 * But we want FRESH at TOP of coach roster, so invert for display.
 */
export function availabilitySortOrder(status: AvailabilityStatus): number {
  switch (status) {
    case 'FRESH': return 0;
    case 'CAUTION': return 1;
    case 'SHUT_DOWN': return 2;
  }
}
