import { useState, useMemo, useEffect } from 'react';
import { format, parseISO, subDays, startOfDay } from 'date-fns';
import { motion } from 'framer-motion';
import { Filter, Download, TrendingUp, Target, Activity } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getEntries } from '@/lib/storage';
import { SessionType } from '@/lib/pitchLogic';
import StatusBadge from '@/components/StatusBadge';
import SessionTypeBadge from '@/components/SessionTypeBadge';
import VeloChart from '@/components/VeloChart';
import CommandChart from '@/components/CommandChart';
import { useAuth } from '@/hooks/useAuth';
import { useConnections } from '@/hooks/useConnections';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { PlayerPitchLog } from '@/hooks/useConnections';

const filterOptions: (SessionType | 'All')[] = ['All', 'Game', 'Practice', 'Lesson', 'Bullpen', 'Other'];

export default function PerformanceScreen() {
  const [filter, setFilter] = useState<SessionType | 'All'>('All');
  const { user, profile } = useAuth();
  const { roster } = useConnections();
  const entries = getEntries();
  const isStaff = profile?.role === 'coach' || profile?.role === 'trainer';
  const [exporting, setExporting] = useState(false);
  const [dbLogs, setDbLogs] = useState<PlayerPitchLog[]>([]);
  const currentYear = new Date().getFullYear();

  // Fetch DB logs for charts (player's own logs)
  useEffect(() => {
    if (!user || isStaff) return;
    supabase
      .from('pitch_logs')
      .select('id, date, pitch_count, innings, session_type, velo, notes, arm_feel, strikes')
      .eq('player_id', user.id)
      .order('date', { ascending: false })
      .limit(50)
      .then(({ data }) => setDbLogs((data as PlayerPitchLog[]) ?? []));
  }, [user, isStaff]);

  const filtered = useMemo(() => {
    if (filter === 'All') return entries;
    return entries.filter(e => e.sessionType === filter);
  }, [entries, filter]);

  // Analytics stats
  const yearlyStats = useMemo(() => {
    const yearEntries = entries.filter(e => parseISO(e.date).getFullYear() === currentYear);
    const totalPitches = yearEntries.reduce((sum, e) => sum + e.pitchCount, 0);
    const totalInnings = yearEntries.reduce((sum, e) => sum + e.innings, 0);
    const ppi = totalInnings > 0 ? (totalPitches / totalInnings).toFixed(1) : '—';
    return { totalPitches, totalInnings: totalInnings.toFixed(1), ppi, sessions: yearEntries.length };
  }, [entries, currentYear]);

  const handleExportCSV = async () => {
    if (roster.length === 0) {
      toast.error('No players on your roster');
      return;
    }
    setExporting(true);
    try {
      const playerIds = roster.map(p => p.id);
      const { data: logs } = await supabase
        .from('pitch_logs')
        .select('player_id, date, pitch_count, velo, strikes, arm_feel, innings')
        .in('player_id', playerIds)
        .order('date', { ascending: false });

      if (!logs || logs.length === 0) {
        toast.error('No pitch logs to export');
        setExporting(false);
        return;
      }

      const nameMap: Record<string, string> = {};
      for (const p of roster) nameMap[p.id] = p.full_name;

      const headers = ['Date', 'Player Name', 'Pitch Count', 'Innings', 'Max Velo', 'Strike %', 'Arm Soreness'];
      const rows = logs.map(l => {
        const strikePercent = l.strikes != null && l.pitch_count > 0
          ? `${Math.round((l.strikes / l.pitch_count) * 100)}%` : '';
        return [
          l.date ?? '', nameMap[l.player_id ?? ''] ?? 'Unknown',
          String(l.pitch_count), l.innings != null ? String(l.innings) : '',
          l.velo != null ? String(l.velo) : '', strikePercent, l.arm_feel ?? '',
        ].join(',');
      });

      const csv = [headers.join(','), ...rows].join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `pitch_logs_${format(new Date(), 'yyyy-MM-dd')}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('CSV downloaded!');
    } catch {
      toast.error('Export failed');
    }
    setExporting(false);
  };

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-4 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Performance</h1>
          <p className="text-sm text-muted-foreground mt-1">{currentYear} Season</p>
        </div>
        {isStaff && (
          <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={handleExportCSV} disabled={exporting}>
            <Download className="w-3.5 h-3.5" />
            {exporting ? 'Exporting...' : 'CSV'}
          </Button>
        )}
      </header>

      <Tabs defaultValue="history" className="w-full">
        <TabsList className="w-full mb-4">
          <TabsTrigger value="history" className="flex-1">History</TabsTrigger>
          <TabsTrigger value="stats" className="flex-1">Stats</TabsTrigger>
        </TabsList>

        {/* History Tab */}
        <TabsContent value="history">
          <div className="mb-4">
            <Select value={filter} onValueChange={(v) => setFilter(v as SessionType | 'All')}>
              <SelectTrigger className="bg-secondary border-border">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                {filterOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
              <p className="text-sm">No sessions logged yet.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filtered.map((entry, i) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="bg-card rounded-xl p-4 border border-border"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">{format(parseISO(entry.date), 'EEE, MMM d')}</span>
                    <StatusBadge restDays={entry.restDays} />
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-mono font-bold">{entry.pitchCount}</span>
                    <span className="text-xs text-muted-foreground">pitches</span>
                    {entry.innings > 0 && (
                      <>
                        <span className="text-muted-foreground">·</span>
                        <span className="text-sm font-mono">{entry.innings} IP</span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <SessionTypeBadge type={entry.sessionType} />
                    {entry.notes && (
                      <span className="text-xs text-muted-foreground truncate">{entry.notes}</span>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Stats Tab */}
        <TabsContent value="stats">
          {/* Season Summary Cards */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            {[
              { label: 'Pitches', value: yearlyStats.totalPitches, icon: Target },
              { label: 'Innings', value: yearlyStats.totalInnings, icon: Activity },
              { label: 'PPI', value: yearlyStats.ppi, icon: TrendingUp },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-card rounded-xl p-4 border border-border text-center"
              >
                <stat.icon className="w-4 h-4 text-primary mx-auto mb-2" />
                <div className="text-xl font-mono font-bold">{stat.value}</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          {/* Charts */}
          {!isStaff && dbLogs.length > 0 && (
            <div className="space-y-4">
              <VeloChart logs={dbLogs} />
              <CommandChart logs={dbLogs} />
            </div>
          )}

          {(isStaff || dbLogs.length === 0) && entries.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-10">No data for {currentYear} yet.</p>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
