import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useConnections, TrafficLight } from '@/hooks/useConnections';
import { LogOut, Users, Copy, RefreshCw, Trash2, Send, FileText, BarChart3, Video, Play, Link } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import TrainerConnectDialog from '@/components/TrainerConnectDialog';
import UpgradeModal from '@/components/UpgradeModal';
import ProFeatureGate from '@/components/ProFeatureGate';
import TrafficLightDot from '@/components/TrafficLightDot';
import TopPerformers from '@/components/TopPerformers';
import HealthFilter from '@/components/HealthFilter';
import TeamGrowth from '@/components/TeamGrowth';

export default function RosterView() {
  const navigate = useNavigate();
  const { profile, signOut, refreshProfile } = useAuth();
  const { roster, loading, generateTeamCode, sendTrainerRequest, removeConnection } = useConnections();
  const [showTrainerDialog, setShowTrainerDialog] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [healthFilter, setHealthFilter] = useState<TrafficLight | 'all'>('all');
  const [teamCode, setTeamCode] = useState(profile?.team_code ?? '');

  useEffect(() => {
    setTeamCode(profile?.team_code ?? '');
  }, [profile?.team_code]);

  const handleGenerateCode = async () => {
    await generateTeamCode();
    await refreshProfile();
  };

  const copyCode = () => {
    if (teamCode) {
      navigator.clipboard.writeText(teamCode);
      toast.success('Team code copied!');
    }
  };

  const copyInviteLink = () => {
    if (teamCode) {
      const link = `${window.location.origin}?code=${teamCode}`;
      navigator.clipboard.writeText(link);
      toast.success('Invite link copied!');
    }
  };

  const isCoach = profile?.role === 'coach';
  const isTrainer = profile?.role === 'trainer';
  const isPremiumCoach = profile?.subscription_tier === 'premium_coach';
  const isPremiumTrainer = profile?.subscription_tier === 'premium_trainer';

  const filteredRoster = useMemo(() => {
    if (healthFilter === 'all') return roster;
    return roster.filter(p => p.trafficLight === healthFilter);
  }, [roster, healthFilter]);

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Roster</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {profile?.full_name ?? 'Coach'} · {isCoach ? 'Coach' : 'Trainer'}
          </p>
        </div>
        <Button variant="ghost" size="icon" onClick={signOut}>
          <LogOut className="w-4 h-4" />
        </Button>
      </header>

      {/* Coach: Team Code Section */}
      {isCoach && (
        <div className="mb-6 p-4 rounded-xl border border-border bg-card">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
            Team Code
          </h3>
          {teamCode ? (
            <>
              <div className="flex items-center gap-3">
                <div className="flex-1 text-2xl font-mono font-bold tracking-[0.3em] text-primary text-center py-2 rounded-lg bg-primary/10 border border-primary/20">
                  {teamCode}
                </div>
                <Button variant="outline" size="icon" onClick={copyCode}>
                  <Copy className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleGenerateCode}>
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
              <Button variant="outline" className="w-full mt-3 gap-2" onClick={copyInviteLink}>
                <Link className="w-4 h-4" />
                Copy Invite Link
              </Button>
            </>
          ) : (
            <Button onClick={handleGenerateCode} className="w-full gap-2">
              <Users className="w-4 h-4" />
              Generate Team Code
            </Button>
          )}
          <p className="text-xs text-muted-foreground mt-2">
            Share this code or invite link with your players so they can join your roster.
          </p>
        </div>
      )}

      {/* Top Performers */}
      {isCoach && roster.length > 0 && <TopPerformers roster={roster} />}

      {/* Team Growth */}
      {isCoach && roster.length > 0 && <TeamGrowth roster={roster} />}


      {/* Coach Pro Features */}
      {isCoach && (
        <div className="mb-6 space-y-2">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            Pro Tools
          </h3>
          <ProFeatureGate
            label="Export Roster PDF"
            icon={<FileText className="w-4 h-4" />}
            locked={!isPremiumCoach}
            onUpgrade={() => setShowUpgrade(true)}
            onClick={() => toast.info('PDF export coming soon')}
          />
          <ProFeatureGate
            label="Advanced Analytics"
            icon={<BarChart3 className="w-4 h-4" />}
            locked={!isPremiumCoach}
            onUpgrade={() => setShowUpgrade(true)}
            onClick={() => toast.info('Advanced analytics coming soon')}
          />
        </div>
      )}

      {/* Trainer Pro Features */}
      {isTrainer && (
        <div className="mb-6 space-y-2">
          <Button onClick={() => setShowTrainerDialog(true)} className="w-full gap-2">
            <Send className="w-4 h-4" />
            Connect with Player
          </Button>
          <ProFeatureGate
            label="Video Analysis"
            icon={<Video className="w-4 h-4" />}
            locked={!isPremiumTrainer}
            onUpgrade={() => setShowUpgrade(true)}
            onClick={() => toast.info('Video analysis coming soon')}
          />
        </div>
      )}

      {/* Roster List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      ) : roster.length > 0 ? (
        <div className="space-y-2">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Connected Players ({filteredRoster.length})
            </h3>
          </div>
          {isCoach && (
            <div className="mb-3">
              <HealthFilter active={healthFilter} onChange={setHealthFilter} />
            </div>
          )}
          {filteredRoster.map((player) => (
            <div
              key={player.id}
              className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card cursor-pointer hover:border-primary/30 transition-colors"
              onClick={() => navigate(`/player/${player.id}`)}
            >
              {/* Traffic Light */}
              <TrafficLightDot status={player.trafficLight} size="md" />

              {/* Player Info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{player.full_name}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>Age {player.age}</span>
                  <span>·</span>
                  <span>{player.recentPitches}p / 48hr</span>
                  {player.lastBullpenVelo && (
                    <>
                      <span>·</span>
                      <span className="text-primary font-medium">{player.lastBullpenVelo} mph</span>
                    </>
                  )}
                  {player.currentArmFeel && (
                    <>
                      <span>·</span>
                      <span className={player.currentArmFeel.toLowerCase() === 'sore' ? 'text-destructive font-medium' : ''}>
                        {player.currentArmFeel}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1">
                {isCoach && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-primary/70 hover:text-primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/live/${player.id}`);
                    }}
                  >
                    <Play className="w-4 h-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive/60 hover:text-destructive"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeConnection(player.connectionId);
                  }}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Users className="w-12 h-12 text-muted-foreground mb-4" />
          <h2 className="font-semibold text-lg mb-1">No Players Yet</h2>
          <p className="text-sm text-muted-foreground max-w-xs">
            {isCoach
              ? 'Generate a team code above and share it with your players.'
              : 'Send a connection request to a player using their email address.'}
          </p>
        </div>
      )}

      <TrainerConnectDialog
        open={showTrainerDialog}
        onOpenChange={setShowTrainerDialog}
        onSend={sendTrainerRequest}
      />
      <UpgradeModal open={showUpgrade} onOpenChange={setShowUpgrade} />
    </div>
  );
}
