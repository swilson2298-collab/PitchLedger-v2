import { useMemo, useCallback, useState, useEffect } from "react";
import MedicalDisclaimer from "@/components/MedicalDisclaimer";
import { addDays, format, startOfDay, differenceInDays } from "date-fns";
import { motion } from "framer-motion";
import { Bell, BellRing, Dumbbell } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { usePlayerStatus } from "@/hooks/usePlayerStatus";
import {
  requestNotificationPermission,
  scheduleRecoveryReminders,
  clearAllReminders,
  areRemindersEnabled,
  getNotificationPermission,
} from "@/lib/notifications";
import { getRecoveryRoadmap } from "@/lib/pitchLogic";
import { getEntries } from "@/lib/storage";
import RecoveryGauge from "@/components/RecoveryGauge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function RecoveryScreen() {
  const { user, profile } = useAuth();
  const status = usePlayerStatus(user?.id, profile?.birthdate);
  const {
    availability,
    todayPitches,
    yearlyPitches,
    seasonLimit,
    yearlyPercent,
    dailyMax,
    age,
    hoursUntilEligible,
    minutesUntilEligible,
    loading,
  } = status;

  const entries = getEntries();
  const lastEntry = entries[0];

  const roadmap = useMemo(() => {
    if (!lastEntry) return [];
    return getRecoveryRoadmap(lastEntry.restDays, age);
  }, [lastEntry, age]);

  const [remindersOn, setRemindersOn] = useState(() => areRemindersEnabled());
  const notifSupport = getNotificationPermission();

  const toggleReminders = useCallback(async () => {
    if (remindersOn) {
      clearAllReminders();
      setRemindersOn(false);
      toast.success("Recovery reminders turned off");
      return;
    }
    const granted = await requestNotificationPermission();
    if (!granted) {
      toast.error("Notification permission denied");
      return;
    }
    if (lastEntry && roadmap.length > 0) {
      scheduleRecoveryReminders(lastEntry.date, roadmap);
      setRemindersOn(true);
      toast.success("Recovery reminders scheduled");
    }
  }, [remindersOn, lastEntry, roadmap]);

  const isShutDown = availability.status === "SHUT_DOWN";
  const isCaution = availability.status === "CAUTION";
  const isFresh = availability.status === "FRESH";

  const recoveryPercent =
    isShutDown && availability.restDays > 0
      ? Math.min(
          100,
          Math.round(((availability.restDays - availability.daysUntilEligible) / availability.restDays) * 100),
        )
      : 100;

  // 7-day timeline
  const today = startOfDay(new Date());
  const timeline = useMemo(() => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = addDays(today, i);
      const isRest = i < availability.daysUntilEligible;
      const isCautionDay = i === availability.daysUntilEligible && isCaution;
      days.push({
        date: d,
        label: i === 0 ? "Today" : format(d, "EEE"),
        dateLabel: format(d, "M/d"),
        status: isRest ? ("rest" as const) : isCautionDay ? ("caution" as const) : ("clear" as const),
      });
    }
    return days;
  }, [today, availability.daysUntilEligible, isCaution]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-5 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Safety & Recovery</h1>
          <p className="text-sm text-muted-foreground mt-1">PitchSmart Status</p>
        </div>
        {roadmap.length > 0 && notifSupport !== "unsupported" && (
          <Button
            variant={remindersOn ? "default" : "outline"}
            size="sm"
            onClick={toggleReminders}
            className="gap-1.5 shrink-0"
          >
            {remindersOn ? <BellRing className="w-3.5 h-3.5" /> : <Bell className="w-3.5 h-3.5" />}
            {remindersOn ? "On" : "Remind"}
          </Button>
        )}
      </header>

      {/* ═══ Recovery Gauge ═══ */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <Card
          className={cn(
            "mb-5",
            isShutDown && "border-destructive/40 bg-gradient-to-br from-card to-destructive/5",
            isCaution &&
              "border-[hsl(var(--status-yellow))]/40 bg-gradient-to-br from-card to-[hsl(var(--status-yellow))]/5",
            isFresh &&
              "border-[hsl(var(--status-green))]/40 bg-gradient-to-br from-card to-[hsl(var(--status-green))]/5",
          )}
        >
          <CardContent className="p-6 flex flex-col items-center">
            <RecoveryGauge
              percent={recoveryPercent}
              daysLeft={availability.daysUntilEligible}
              hoursLeft={hoursUntilEligible}
              minutesLeft={minutesUntilEligible}
            />
            <h2
              className={cn(
                "text-lg font-bold mt-4",
                isShutDown && "text-destructive",
                isCaution && "text-[hsl(var(--status-yellow))]",
                isFresh && "text-[hsl(var(--status-green))]",
              )}
            >
              {isShutDown ? "🛑 Required Rest" : isCaution ? "⚠️ Limited" : "✅ Ready to Throw"}
            </h2>
            <p className="text-xs text-muted-foreground mt-1 text-center">
              {isShutDown
                ? availability.reason
                : isCaution
                  ? "Recovery in progress. Monitor arm soreness."
                  : "Arm feeling good. No PitchSmart restrictions."}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* ═══ 7-Day Recovery Timeline ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-5"
      >
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">7-Day Outlook</p>
            <div className="flex justify-between gap-1">
              {timeline.map((day, i) => (
                <div key={i} className="flex flex-col items-center gap-1 flex-1">
                  <span className="text-[9px] text-muted-foreground font-medium">{day.label}</span>
                  <div
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold border-2",
                      day.status === "rest" && "bg-destructive/15 border-destructive/40 text-destructive",
                      day.status === "caution" &&
                        "bg-[hsl(var(--status-yellow))]/15 border-[hsl(var(--status-yellow))]/40 text-[hsl(var(--status-yellow))]",
                      day.status === "clear" &&
                        "bg-[hsl(var(--status-green))]/15 border-[hsl(var(--status-green))]/40 text-[hsl(var(--status-green))]",
                    )}
                  >
                    {day.status === "rest" ? "🔴" : day.status === "caution" ? "🟡" : "🟢"}
                  </div>
                  <span className="text-[9px] text-muted-foreground">{day.dateLabel}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* ═══ Coach Sync Table ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-5"
      >
        <Card className="border-border">
          <CardContent className="p-4 space-y-4">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Safety Data</p>

            {/* Today's pitches */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Pitches (Today)</span>
              <span
                className={cn(
                  "text-sm font-mono font-bold",
                  todayPitches >= dailyMax
                    ? "text-destructive"
                    : todayPitches >= dailyMax * 0.75
                      ? "text-[hsl(var(--status-yellow))]"
                      : "text-foreground",
                )}
              >
                {todayPitches} / {dailyMax}
              </span>
            </div>

            {/* Required rest */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Required Rest</span>
              <span
                className={cn(
                  "text-sm font-mono font-bold",
                  availability.restDays > 2
                    ? "text-destructive"
                    : availability.restDays > 0
                      ? "text-[hsl(var(--status-yellow))]"
                      : "text-[hsl(var(--status-green))]",
                )}
              >
                {availability.restDays} Day{availability.restDays !== 1 ? "s" : ""}
              </span>
            </div>

            {/* Season total */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-sm text-muted-foreground">Season Total</span>
                <span className="text-xs font-mono text-muted-foreground">
                  {yearlyPitches} / {seasonLimit}
                </span>
              </div>
              <Progress value={yearlyPercent} className="h-3" />
              {yearlyPercent >= 90 && <p className="text-[10px] text-destructive mt-1">⚠️ Approaching season limit</p>}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* ═══ Recovery Roadmap ═══ */}
      {!lastEntry ? (
        <div className="flex flex-col items-center justify-center py-12">
          <Dumbbell className="w-12 h-12 text-muted-foreground mb-4" />
          <p className="text-muted-foreground text-sm">Log a session to see your recovery roadmap.</p>
        </div>
      ) : (
        roadmap.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <Card className="border-border">
              <CardContent className="p-4">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
                  Recovery Roadmap
                </p>
                <div className="space-y-3">
                  {roadmap.map((day, i) => {
                    const daysSince = lastEntry ? differenceInDays(today, new Date(lastEntry.date)) : 0;
                    const isCompleted = daysSince >= day.day;
                    const isCurrent = daysSince + 1 === day.day;
                    return (
                      <div
                        key={day.day}
                        className={cn(
                          "rounded-lg p-3 border",
                          isCurrent ? "border-primary/40 bg-primary/5" : "border-border",
                          isCompleted && "opacity-60",
                        )}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold">
                            Day {day.day}: {day.title}
                          </span>
                          {isCurrent && (
                            <span className="text-[9px] font-semibold uppercase text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">
                              Today
                            </span>
                          )}
                        </div>
                        <ul className="space-y-0.5">
                          {day.activities.map((a, j) => (
                            <li key={j} className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                              <span className="w-1 h-1 rounded-full bg-muted-foreground shrink-0" />
                              {a}
                            </li>
                          ))}
                        </ul>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )
      )}

      <MedicalDisclaimer />
    </div>
  );
}
