import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Users,
  Copy,
  RefreshCw,
  Link,
  Crown,
  Bell,
  LogOut,
  User,
  Calendar,
  Shield,
  Mail,
  ChevronRight,
  CreditCard,
  ChevronDown,
  BookOpen,
  AlertTriangle,
  ShieldOff,
  ShieldAlert,
  Key,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarPicker } from "@/components/ui/calendar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useAuth } from "@/hooks/useAuth";
import AvatarUpload from "@/components/AvatarUpload";
import { useConnections } from "@/hooks/useConnections";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { getRestDayTable, getAgeGuidelines, redFlags } from "@/lib/pitchLogic";
import { calculateAge } from "@/lib/age";
import { calculateAvailability, AvailabilityResult, PitchLogEntry } from "@/lib/pitchSmartEngine";

// ── Shared portal helper ──
function usePortal() {
  const [loading, setLoading] = useState(false);
  const open = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal");
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch {
      toast.error("Could not open billing portal");
    }
    setLoading(false);
  };
  return { loading, open };
}

// ── Shared card wrapper ──
function SettingsCard({
  icon,
  title,
  delay = 0,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  delay?: number;
  children: React.ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-card rounded-xl p-4 border border-border mb-4"
    >
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h2 className="font-semibold text-sm">{title}</h2>
      </div>
      {children}
    </motion.div>
  );
}

// ══════════════════════════════════════════════
// Staff Safety & Settings
// ══════════════════════════════════════════════
function StaffSafetySettings() {
  const navigate = useNavigate();
  const { profile, signOut, refreshProfile } = useAuth();
  const { generateTeamCode, roster } = useConnections();
  const [teamCode, setTeamCode] = useState(profile?.team_code ?? "");
  const [alertSoreness, setAlertSoreness] = useState(true);
  const [weeklySummary, setWeeklySummary] = useState(false);
  const portal = usePortal();
  const isCoach = profile?.role === "coach";
  const isPro = profile?.subscription_tier && profile.subscription_tier !== "free";

  // Flagged players
  interface FlaggedPlayer {
    id: string;
    name: string;
    availability: AvailabilityResult;
    age: number;
  }
  const [flaggedPlayers, setFlaggedPlayers] = useState<FlaggedPlayer[]>([]);

  useEffect(() => {
    setTeamCode(profile?.team_code ?? "");
  }, [profile?.team_code]);

  useEffect(() => {
    if (roster.length === 0) return;
    const playerIds = roster.map((p) => p.id);
    const fetchFlagged = async () => {
      const { data: logs } = await supabase
        .from("pitch_logs")
        .select("player_id, pitch_count, arm_feel, date")
        .in("player_id", playerIds)
        .order("date", { ascending: false });
      const { data: profiles } = await supabase.from("profiles").select("id, birthdate, full_name").in("id", playerIds);
      if (!logs || !profiles) return;
      const flagged: FlaggedPlayer[] = [];
      for (const p of profiles) {
        const playerLogs = logs.filter((l) => l.player_id === p.id);
        const lastLog: PitchLogEntry | null = playerLogs.length > 0 ? playerLogs[0] : null;
        const age = p.birthdate ? calculateAge(p.birthdate) : 14;
        const avail = calculateAvailability(lastLog, age);
        if (avail.status === "SHUT_DOWN" || avail.status === "CAUTION") {
          flagged.push({ id: p.id, name: p.full_name ?? "Unknown", availability: avail, age });
        }
      }
      flagged.sort((a, b) => (a.availability.status === "SHUT_DOWN" ? -1 : 1));
      setFlaggedPlayers(flagged);
    };
    fetchFlagged();
  }, [roster]);

  const handleGenerateCode = async () => {
    await generateTeamCode();
    await refreshProfile();
  };
  const copyCode = () => {
    if (teamCode) {
      navigator.clipboard.writeText(teamCode);
      toast.success("Team code copied!");
    }
  };
  const copyInviteLink = () => {
    if (teamCode) {
      navigator.clipboard.writeText(`${window.location.origin}?code=${teamCode}`);
      toast.success("Invite link copied!");
    }
  };

  return (
    <>
      {/* Player Alerts */}
      {flaggedPlayers.length > 0 && (
        <SettingsCard
          icon={<AlertTriangle className="w-4 h-4 text-destructive" />}
          title={`Player Alerts (${flaggedPlayers.length})`}
          delay={0}
        >
          <div className="space-y-2">
            {flaggedPlayers.map((fp) => (
              <div
                key={fp.id}
                className={cn(
                  "flex items-center justify-between p-2.5 rounded-lg border",
                  fp.availability.status === "SHUT_DOWN"
                    ? "border-destructive/30 bg-destructive/5"
                    : "border-[hsl(var(--status-yellow))]/30 bg-[hsl(var(--status-yellow))]/5",
                )}
              >
                <div>
                  <p className="text-sm font-semibold">{fp.name}</p>
                  <p className="text-[11px] text-muted-foreground">{fp.availability.reason}</p>
                </div>
                {fp.availability.status === "SHUT_DOWN" ? (
                  <Badge variant="destructive" className="text-[9px] px-1.5 py-0 animate-pulse gap-0.5">
                    <ShieldOff className="w-2.5 h-2.5" /> Shut Down
                    {fp.availability.eligibleDate && (
                      <span className="ml-1">→ {format(fp.availability.eligibleDate, "MMM d")}</span>
                    )}
                  </Badge>
                ) : (
                  <Badge className="text-[9px] px-1.5 py-0 gap-0.5 bg-[hsl(var(--status-yellow))]/15 text-[hsl(var(--status-yellow))] border-[hsl(var(--status-yellow))]/30">
                    <ShieldAlert className="w-2.5 h-2.5" /> Caution
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </SettingsCard>
      )}

      {flaggedPlayers.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[hsl(var(--status-green))]/5 border border-[hsl(var(--status-green))]/20 rounded-xl p-4 mb-4 text-center"
        >
          <p className="text-sm font-medium text-[hsl(var(--status-green))]">✅ All players are cleared to pitch</p>
        </motion.div>
      )}

      {/* Team Management */}
      {isCoach && (
        <SettingsCard icon={<Users className="w-4 h-4 text-primary" />} title="Team Management" delay={0.05}>
          <p className="text-xs text-muted-foreground mb-3">Share your team code with players to join your roster.</p>
          {teamCode ? (
            <div className="space-y-3">
              <div className="text-2xl font-mono font-bold tracking-[0.3em] text-primary text-center py-3 rounded-xl bg-primary/10 border border-primary/20">
                {teamCode}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 gap-1.5 text-xs" onClick={copyCode}>
                  <Copy className="w-3.5 h-3.5" /> Code
                </Button>
                <Button variant="outline" size="sm" className="flex-1 gap-1.5 text-xs" onClick={copyInviteLink}>
                  <Link className="w-3.5 h-3.5" /> Link
                </Button>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="w-full gap-2 text-muted-foreground"
                onClick={handleGenerateCode}
              >
                <RefreshCw className="w-3.5 h-3.5" /> Reset Code
              </Button>
            </div>
          ) : (
            <Button onClick={handleGenerateCode} className="w-full gap-2">
              <Users className="w-4 h-4" /> Generate Team Code
            </Button>
          )}
        </SettingsCard>
      )}

      {/* Reference Center */}
      <ReferenceCenter delay={0.1} />

      {/* Subscription */}
      <SettingsCard icon={<Crown className="w-4 h-4 text-primary" />} title="Subscription" delay={0.15}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-sm font-medium capitalize">{profile?.subscription_tier?.replace("_", " ") ?? "Free"}</p>
            <p className="text-xs text-muted-foreground">
              {isPro ? "Full access to all Pro features" : "Upgrade for unlimited connections & exports"}
            </p>
          </div>
          <Badge
            className={isPro ? "bg-primary/15 text-primary border-primary/30" : "bg-secondary text-muted-foreground"}
          >
            {isPro ? "Pro" : "Free"}
          </Badge>
        </div>
        {isPro ? (
          <Button
            variant="outline"
            size="sm"
            className="w-full text-xs"
            onClick={portal.open}
            disabled={portal.loading}
          >
            {portal.loading ? "Loading..." : "Manage Subscription"}
          </Button>
        ) : (
          <Button size="sm" className="w-full text-xs gap-1.5" onClick={() => navigate("/billing")}>
            <Crown className="w-3.5 h-3.5" /> Upgrade to Pro
          </Button>
        )}
      </SettingsCard>

      {/* Notifications */}
      <SettingsCard icon={<Bell className="w-4 h-4 text-primary" />} title="Notifications" delay={0.2}>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">High Soreness Alerts</p>
              <p className="text-xs text-muted-foreground">Get notified when a player reports 7+ soreness</p>
            </div>
            <Switch checked={alertSoreness} onCheckedChange={setAlertSoreness} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Weekly Summary Email</p>
              <p className="text-xs text-muted-foreground">Receive a roster summary every Monday</p>
            </div>
            <Switch checked={weeklySummary} onCheckedChange={setWeeklySummary} />
          </div>
        </div>
      </SettingsCard>

      <Button
        variant="outline"
        className="w-full gap-2 text-destructive border-destructive/30 hover:bg-destructive/5"
        onClick={signOut}
      >
        <LogOut className="w-4 h-4" /> Sign Out
      </Button>
    </>
  );
}

// ══════════════════════════════════════════════
// Player Safety & Settings
// ══════════════════════════════════════════════
function PlayerSafetySettings() {
  const navigate = useNavigate();
  const { user, profile, signOut, refreshProfile } = useAuth();
  const { roster, removeConnection } = useConnections();
  const portal = usePortal();
  const isPro = profile?.subscription_tier && profile.subscription_tier !== "free";
  const playerAge = profile?.birthdate ? calculateAge(profile.birthdate) : 14;

  // Coach connection
  const [coachName, setCoachName] = useState<string | null>(null);
  const [teamName, setTeamName] = useState<string | null>(null); // Add this line
  const [coachConnectionId, setCoachConnectionId] = useState<string | null>(null);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [leaveConfirmText, setLeaveConfirmText] = useState("");

  // Birthdate editing
  const [editingBirthdate, setEditingBirthdate] = useState(false);
  const [birthdateInput, setBirthdateInput] = useState(
    profile?.birthdate ? format(new Date(profile.birthdate), "MM/dd/yyyy") : "",
  );
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(
    profile?.birthdate ? new Date(profile.birthdate) : undefined,
  );

  // Invite code
  const inviteCode = profile?.invite_code ?? null;

  const handleBirthdateInput = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 8);
    let formatted = digits;
    if (digits.length > 2) formatted = digits.slice(0, 2) + "/" + digits.slice(2);
    if (digits.length > 4) formatted = digits.slice(0, 2) + "/" + digits.slice(2, 4) + "/" + digits.slice(4);
    setBirthdateInput(formatted);
    if (digits.length === 8) {
      const m = parseInt(digits.slice(0, 2), 10);
      const d = parseInt(digits.slice(2, 4), 10);
      const y = parseInt(digits.slice(4, 8), 10);
      const parsed = new Date(y, m - 1, d);
      if (!isNaN(parsed.getTime()) && parsed <= new Date() && parsed >= new Date("1900-01-01")) {
        setSelectedDate(parsed);
      } else {
        setSelectedDate(undefined);
      }
    } else {
      setSelectedDate(undefined);
    }
  };

  useEffect(() => {
    if (!user) return;
    const fetchCoach = async () => {
      const { data: connections } = await supabase
        .from("connections")
        .select("id, connected_user_id")
        .eq("player_id", user.id)
        .eq("connection_type", "team")
        .eq("status", "active")
        .limit(1);

      if (connections && connections.length > 0) {
        setCoachConnectionId(connections[0].id);
        const coachId = connections[0].connected_user_id;
        if (coachId) {
          const { data: cp } = await supabase
            .from("profiles")
            .select("full_name, team_name")
            .eq("id", coachId)
            .single();

          setCoachName(cp?.full_name ?? "Coach");
          setTeamName(cp?.team_name ?? "Independent");
        }
      }
    };
    fetchCoach();
  }, [user]);

  const handleSaveBirthdate = async () => {
    if (!selectedDate || !user) return;
    const dateStr = format(selectedDate, "yyyy-MM-dd");
    const { error } = await supabase.from("profiles").update({ birthdate: dateStr }).eq("id", user.id);
    if (error) {
      toast.error("Failed to update birthdate");
    } else {
      toast.success("Birthdate updated");
      await refreshProfile();
    }
    setEditingBirthdate(false);
  };

  const handleLeaveTeam = async () => {
    if (coachConnectionId) {
      await removeConnection(coachConnectionId);
      setCoachName(null);
      setCoachConnectionId(null);
      toast.success("Left team");
    }
    setShowLeaveConfirm(false);
    setLeaveConfirmText("");
  };

  const copyInviteCode = () => {
    if (inviteCode) {
      navigator.clipboard.writeText(inviteCode);
      toast.success("Invite code copied!");
    }
  };

  return (
    <>
      {/* Profile — Avatar, Name, Birthdate */}
      <SettingsCard icon={<User className="w-4 h-4 text-primary" />} title="Profile" delay={0}>
        <div className="flex items-center gap-4 mb-4">
          <AvatarUpload currentUrl={null} onUploaded={() => toast.success("Avatar updated")} />
          <div className="flex-1">
            <p className="text-sm font-bold">{profile?.full_name ?? "Player"}</p>
            <p className="text-xs text-muted-foreground capitalize">{profile?.role ?? "Player"}</p>
          </div>
        </div>
        {/* Birthdate */}
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <div>
            <p className="text-xs text-muted-foreground">Birthdate (drives PitchSmart)</p>
            <p className="text-sm font-medium">
              {profile?.birthdate ? format(new Date(profile.birthdate), "MMM d, yyyy") : "Not set"}
            </p>
            {profile?.birthdate && <p className="text-[10px] text-primary/70">Age: {playerAge}</p>}
          </div>
          <Popover open={editingBirthdate} onOpenChange={setEditingBirthdate}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="text-xs">
                Edit
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-2" align="end">
              <div className="px-1 pb-2">
                <label className="text-xs text-muted-foreground">Type date (MM/DD/YYYY)</label>
                <Input
                  placeholder="MM/DD/YYYY"
                  value={birthdateInput}
                  onChange={(e) => handleBirthdateInput(e.target.value)}
                  className="mt-1 font-mono text-sm h-9"
                  maxLength={10}
                />
              </div>
              <CalendarPicker
                mode="single"
                selected={selectedDate}
                onSelect={(d) => {
                  setSelectedDate(d);
                  if (d) setBirthdateInput(format(d, "MM/dd/yyyy"));
                }}
                disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                month={selectedDate}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
              <div className="p-3 pt-0 flex justify-end">
                <Button size="sm" onClick={handleSaveBirthdate} disabled={!selectedDate}>
                  Save
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </SettingsCard>

      {/* My Team */}
      <SettingsCard icon={<Shield className="w-4 h-4 text-primary" />} title="My Team" delay={0.1}>
        {coachName ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-bold leading-tight">{teamName || "No Team Name"}</p>
                <p className="text-xs text-muted-foreground">Coach: {coachName}</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="text-[10px] h-7 px-2 text-destructive border-destructive/30 hover:bg-destructive/5"
              onClick={() => {
                setLeaveConfirmText("");
                setShowLeaveConfirm(true);
              }}
            >
              Leave
            </Button>
          </div>
        ) : (
          <div className="text-center py-2">
            <p className="text-sm text-muted-foreground">Not connected to a team yet.</p>
            <p className="text-[10px] text-muted-foreground/60 mt-1">Share your Invite Code with a coach to join.</p>
          </div>
        )}
      </SettingsCard>

      {/* Reference Center */}
      <ReferenceCenter delay={0.15} />

      {/* Invite Code */}
      {(profile?.role === "player" || profile?.role === "parent") && inviteCode && (
        <SettingsCard icon={<Key className="w-4 h-4 text-primary" />} title="Your Invite Code" delay={0.05}>
          <p className="text-[11px] text-muted-foreground mb-3">
            Share this code with your parent, coach, or trainer to connect.
          </p>
          <div className="flex items-center gap-3">
            <div className="flex-1 text-2xl font-mono font-bold tracking-[0.3em] text-primary text-center py-3 rounded-xl bg-primary/10 border border-primary/20">
              {inviteCode}
            </div>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={copyInviteCode}>
              <Copy className="w-3.5 h-3.5" /> Copy
            </Button>
          </div>
        </SettingsCard>
      )}

      {/* Account */}
      <SettingsCard icon={<Mail className="w-4 h-4 text-primary" />} title="Account" delay={0.2}>
        <div>
          <p className="text-xs text-muted-foreground">Email</p>
          <p className="text-sm font-medium">{user?.email ?? "—"}</p>
        </div>
      </SettingsCard>

      {/* Billing */}
      <SettingsCard icon={<CreditCard className="w-4 h-4 text-primary" />} title="Billing" delay={0.25}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-sm font-medium capitalize">{profile?.subscription_tier?.replace("_", " ") ?? "Free"}</p>
            <p className="text-xs text-muted-foreground">
              {isPro ? "Active subscription" : "Free tier — upgrade for Pro features"}
            </p>
          </div>
          <Badge
            className={isPro ? "bg-primary/15 text-primary border-primary/30" : "bg-secondary text-muted-foreground"}
          >
            {isPro ? "Pro" : "Free"}
          </Badge>
        </div>
        {isPro ? (
          <Button
            variant="outline"
            size="sm"
            className="w-full text-xs"
            onClick={portal.open}
            disabled={portal.loading}
          >
            {portal.loading ? "Loading..." : "Manage Subscription"}
          </Button>
        ) : (
          <Button size="sm" className="w-full text-xs gap-1.5" onClick={() => navigate("/billing")}>
            <Crown className="w-3.5 h-3.5" /> Upgrade to Pro
          </Button>
        )}
      </SettingsCard>

      {/* Sign Out */}
      <Button
        variant="outline"
        className="w-full gap-2 text-destructive border-destructive/30 hover:bg-destructive/5"
        onClick={signOut}
      >
        <LogOut className="w-4 h-4" /> Sign Out
      </Button>

      {/* Leave Team Confirmation */}
      <Dialog open={showLeaveConfirm} onOpenChange={setShowLeaveConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Leave Team</DialogTitle>
            <DialogDescription>
              This will disconnect you from <strong>{coachName}</strong>. Type "LEAVE" to confirm.
            </DialogDescription>
          </DialogHeader>
          <Input
            placeholder="Type LEAVE to confirm"
            value={leaveConfirmText}
            onChange={(e) => setLeaveConfirmText(e.target.value)}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowLeaveConfirm(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={leaveConfirmText.trim().toUpperCase() !== "LEAVE"}
              onClick={handleLeaveTeam}
            >
              Leave Team
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ══════════════════════════════════════════════
// Reference Center (shared between staff & player)
// ══════════════════════════════════════════════
function ReferenceCenter({ delay = 0 }: { delay?: number }) {
  const restTable = getRestDayTable();
  const guidelines = getAgeGuidelines();

  return (
    <SettingsCard icon={<BookOpen className="w-4 h-4 text-primary" />} title="Reference Center" delay={delay}>
      <div className="space-y-2">
        {/* PitchSmart Matrix */}
        <Collapsible>
          <CollapsibleTrigger className="flex items-center justify-between w-full py-2.5 px-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors text-left">
            <span className="text-sm font-semibold">PitchSmart Matrix</span>
            <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
          </CollapsibleTrigger>
          <CollapsibleContent className="pt-2">
            <div className="overflow-x-auto -mx-2 px-2">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 pr-2 text-muted-foreground font-medium">Age</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">Max</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">0d</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">1d</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">2d</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">3d</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">4d</th>
                    <th className="text-center py-2 px-1 text-muted-foreground font-medium">5d</th>
                  </tr>
                </thead>
                <tbody>
                  {restTable.map((row) => (
                    <tr key={row.ageRange} className="border-b border-border last:border-0">
                      <td className="py-2 pr-2 font-medium">{row.ageRange}</td>
                      <td className="text-center py-2 px-1 font-mono font-bold text-primary">{row.max}</td>
                      {row.rest.map((r) => (
                        <td key={r.days} className="text-center py-2 px-1 text-muted-foreground">
                          {r.range}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Age-Specific Guidelines */}
        <Collapsible>
          <CollapsibleTrigger className="flex items-center justify-between w-full py-2.5 px-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors text-left">
            <span className="text-sm font-semibold">Age-Specific Guidelines</span>
            <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
          </CollapsibleTrigger>
          <CollapsibleContent className="pt-2">
            <div className="space-y-2">
              {guidelines.map((g) => (
                <Collapsible key={g.ageRange}>
                  <CollapsibleTrigger className="flex items-center justify-between w-full py-2 px-3 rounded-lg bg-muted/50 hover:bg-muted/80 transition-colors text-left">
                    <div>
                      <span className="text-xs font-semibold">{g.ageRange}</span>
                      <span className="text-[10px] text-muted-foreground ml-2">({g.distance})</span>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  </CollapsibleTrigger>
                  <CollapsibleContent className="px-3 pt-2 pb-3">
                    <div className="text-[11px] text-primary font-medium mb-2">Max: {g.maxInnings}</div>
                    <ul className="space-y-1.5">
                      {g.guidelines.map((item, j) => (
                        <li key={j} className="text-[11px] text-secondary-foreground flex items-start gap-2">
                          <span className="w-1 h-1 rounded-full bg-muted-foreground mt-1.5 shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CollapsibleContent>
                </Collapsible>
              ))}
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Medical Red Flags */}
        <Collapsible>
          <CollapsibleTrigger className="flex items-center justify-between w-full py-2.5 px-3 rounded-lg bg-destructive/10 hover:bg-destructive/15 transition-colors text-left">
            <span className="text-sm font-semibold text-destructive">When to See a Doctor</span>
            <ChevronDown className="w-4 h-4 text-destructive/60 shrink-0" />
          </CollapsibleTrigger>
          <CollapsibleContent className="pt-2 px-1">
            <ul className="space-y-2">
              {redFlags.map((flag, i) => (
                <li key={i} className="text-xs text-secondary-foreground flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-destructive mt-1.5 shrink-0" />
                  {flag}
                </li>
              ))}
            </ul>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </SettingsCard>
  );
}

// ══════════════════════════════════════════════
// Main Screen
// ══════════════════════════════════════════════
export default function SafetySettingsScreen() {
  const { profile, signOut } = useAuth();
  const isStaff = profile?.role === "coach" || profile?.role === "trainer";

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Safety & Settings</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {profile?.full_name ?? "User"} · <span className="capitalize">{profile?.role ?? "Player"}</span>
          </p>
        </div>
        <Button variant="ghost" size="icon" onClick={signOut}>
          <LogOut className="w-4 h-4" />
        </Button>
      </header>
      {isStaff ? <StaffSafetySettings /> : <PlayerSafetySettings />}
    </div>
  );
}
