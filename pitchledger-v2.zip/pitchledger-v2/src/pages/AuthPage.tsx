import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { format } from "date-fns";
import { CalendarIcon, Eye, EyeOff, LogIn, UserPlus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Role = "player" | "parent" | "coach" | "trainer";

const roles: { value: Role; label: string; emoji: string; desc: string }[] = [
  { value: "player",  label: "Player",  emoji: "⚾", desc: "Track my own sessions" },
  { value: "parent",  label: "Parent",  emoji: "👨‍👩‍👦", desc: "Monitor my child" },
  { value: "coach",   label: "Coach",   emoji: "📋", desc: "Manage my roster" },
  { value: "trainer", label: "Trainer", emoji: "💪", desc: "Work with players" },
];

export default function AuthPage() {
  const [searchParams] = useSearchParams();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [signedUp, setSignedUp] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [birthdate, setBirthdate] = useState<Date | undefined>();
  const [role, setRole] = useState<Role | null>(null);

  useEffect(() => {
    const code = searchParams.get("code");
    if (code) {
      localStorage.setItem("invite_code", code.toUpperCase());
      setIsLogin(false);
    }
  }, [searchParams]);

  const handleToggle = (loginMode: boolean) => {
    setIsLogin(loginMode);
    setEmail(""); setPassword(""); setFullName("");
    setBirthdate(undefined); setRole(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !loading) isLogin ? handleLogin() : handleSignUp();
  };

  const handleLogin = async () => {
    if (!email || !password) { toast.error("Please fill in all fields"); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) toast.error(error.message);
  };

  const handleSignUp = async () => {
    if (!email || !password || !fullName || !role) {
      toast.error("Please fill in all fields and select a role"); return;
    }
    if ((role === "player" || role === "parent") && !birthdate) {
      toast.error("Birthdate is required for players and parents"); return;
    }
    if (password.length < 6) { toast.error("Password must be at least 6 characters"); return; }

    const inviteCode = localStorage.getItem("invite_code");
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email, password,
      options: {
        emailRedirectTo: window.location.origin,
        data: {
          full_name: fullName,
          role,
          birthdate: birthdate ? format(birthdate, "yyyy-MM-dd") : null,
          invite_code: inviteCode ?? undefined,
        },
      },
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    localStorage.removeItem("invite_code");
    setSignedUp(true);
  };

  if (signedUp) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm space-y-4">
          <div className="w-16 h-16 rounded-full bg-primary/15 border-2 border-primary/30 flex items-center justify-center mx-auto text-3xl">📬</div>
          <h2 className="text-2xl font-bold">Check your email</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            We sent a confirmation link to <span className="font-semibold text-foreground">{email}</span>.<br />
            Click it to activate your account.
          </p>
          <p className="text-xs text-muted-foreground">Didn't get it? Check your spam folder.</p>
          <Button variant="outline" className="w-full" onClick={() => { setSignedUp(false); setIsLogin(true); setPassword(""); }}>
            Back to Sign In
          </Button>
        </motion.div>
      </div>
    );
  }

  const needsBirthdate = role === "player" || role === "parent";

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Pitch<span className="text-primary">Ledger</span></h1>
          <p className="text-sm text-muted-foreground mt-1">Track. Recover. Compete.</p>
        </div>

        <div className="flex bg-secondary rounded-lg p-1 mb-6">
          {[{ label: "Sign In", login: true }, { label: "Sign Up", login: false }].map(({ label, login }) => (
            <button key={label} onClick={() => handleToggle(login)}
              className={cn("flex-1 py-2 text-sm font-medium rounded-md transition-colors",
                isLogin === login ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>
              {label}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={isLogin ? "login" : "signup"}
            initial={{ opacity: 0, x: isLogin ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: isLogin ? 20 : -20 }}
            transition={{ duration: 0.2 }} className="space-y-4">

            {!isLogin && (
              <>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Full Name</label>
                  <Input placeholder="John Smith" value={fullName} onChange={e => setFullName(e.target.value)}
                    onKeyDown={handleKeyDown} className="bg-secondary border-border" />
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">I am a...</label>
                  <div className="grid grid-cols-2 gap-2">
                    {roles.map(r => (
                      <button key={r.value} onClick={() => setRole(r.value)}
                        className={cn("flex flex-col items-start gap-0.5 px-3 py-2.5 rounded-lg border text-sm font-medium transition-all text-left",
                          role === r.value ? "border-primary bg-primary/10 text-primary" : "border-border bg-secondary text-muted-foreground hover:border-primary/50")}>
                        <span className="text-base">{r.emoji} {r.label}</span>
                        <span className="text-[10px] font-normal opacity-70">{r.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {needsBirthdate && (
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
                      Birthdate <span className="text-destructive">*</span>
                    </label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className={cn("w-full justify-start text-left font-normal bg-secondary border-border", !birthdate && "text-muted-foreground")}>
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {birthdate ? format(birthdate, "MMM d, yyyy") : "Select birthdate"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={birthdate} onSelect={setBirthdate}
                          disabled={date => date > new Date() || date < new Date("1950-01-01")}
                          initialFocus className="p-3 pointer-events-auto"
                          captionLayout="dropdown-buttons" fromYear={1950} toYear={new Date().getFullYear()} />
                      </PopoverContent>
                    </Popover>
                  </div>
                )}
              </>
            )}

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Email</label>
              <Input type="email" placeholder="you@email.com" value={email}
                onChange={e => setEmail(e.target.value)} onKeyDown={handleKeyDown} className="bg-secondary border-border" />
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Password</label>
              <div className="relative">
                <Input type={showPassword ? "text" : "password"} placeholder="••••••••" value={password}
                  onChange={e => setPassword(e.target.value)} onKeyDown={handleKeyDown}
                  className="bg-secondary border-border pr-10" />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <Button onClick={isLogin ? handleLogin : handleSignUp} disabled={loading} className="w-full h-12 text-base font-semibold gap-2">
              {loading
                ? <span className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full" />
                : isLogin
                  ? <><LogIn className="w-4 h-4" /> Sign In</>
                  : <><UserPlus className="w-4 h-4" /> Create Account</>}
            </Button>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
