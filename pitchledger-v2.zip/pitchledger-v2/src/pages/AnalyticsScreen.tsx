import { useMemo } from 'react';
import { format, parseISO } from 'date-fns';
import { motion } from 'framer-motion';
import { TrendingUp, Target, Activity } from 'lucide-react';
import { getEntries } from '@/lib/storage';

export default function AnalyticsScreen() {
  const entries = getEntries();
  const currentYear = new Date().getFullYear();

  const yearlyStats = useMemo(() => {
    const yearEntries = entries.filter(e => parseISO(e.date).getFullYear() === currentYear);
    const totalPitches = yearEntries.reduce((sum, e) => sum + e.pitchCount, 0);
    const totalInnings = yearEntries.reduce((sum, e) => sum + e.innings, 0);
    const ppi = totalInnings > 0 ? (totalPitches / totalInnings).toFixed(1) : '—';
    return { totalPitches, totalInnings: totalInnings.toFixed(1), ppi, sessions: yearEntries.length };
  }, [entries, currentYear]);

  const monthlyData = useMemo(() => {
    const months: { month: string; pitches: number; innings: number; sessions: number }[] = [];
    for (let m = 0; m < 12; m++) {
      const monthEntries = entries.filter(e => {
        const d = parseISO(e.date);
        return d.getFullYear() === currentYear && d.getMonth() === m;
      });
      if (monthEntries.length > 0) {
        months.push({
          month: format(new Date(currentYear, m, 1), 'MMM'),
          pitches: monthEntries.reduce((s, e) => s + e.pitchCount, 0),
          innings: monthEntries.reduce((s, e) => s + e.innings, 0),
          sessions: monthEntries.length,
        });
      }
    }
    return months;
  }, [entries, currentYear]);

  const maxPitches = Math.max(...monthlyData.map(m => m.pitches), 1);

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
        <p className="text-sm text-muted-foreground mt-1">{currentYear} Season</p>
      </header>

      {/* Year Cards */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: 'Pitches', value: yearlyStats.totalPitches, icon: Target },
          { label: 'Innings', value: yearlyStats.totalInnings, icon: Activity },
          { label: 'PPI', value: yearlyStats.ppi, icon: TrendingUp },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-xl p-4 border border-border text-center"
          >
            <stat.icon className="w-4 h-4 text-primary mx-auto mb-2" />
            <div className="text-xl font-mono font-bold">{stat.value}</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mt-1">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Monthly Breakdown */}
      <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Monthly Breakdown</h2>
      {monthlyData.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-10">No data for {currentYear} yet.</p>
      ) : (
        <div className="space-y-3">
          {monthlyData.map((m, i) => (
            <motion.div
              key={m.month}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-xl p-4 border border-border"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold">{m.month}</span>
                <span className="text-xs text-muted-foreground">{m.sessions} sessions</span>
              </div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-lg font-mono font-bold">{m.pitches}</span>
                <span className="text-xs text-muted-foreground">pitches</span>
                <span className="text-muted-foreground">·</span>
                <span className="text-sm font-mono">{m.innings.toFixed(1)} IP</span>
              </div>
              {/* Bar */}
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(m.pitches / maxPitches) * 100}%` }}
                  transition={{ delay: i * 0.05 + 0.2, duration: 0.5 }}
                  className="h-full bg-primary rounded-full"
                />
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
