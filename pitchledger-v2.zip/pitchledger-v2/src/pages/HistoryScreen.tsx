import { useState, useMemo, useEffect, useCallback } from 'react';
import { format, parseISO } from 'date-fns';
import { motion } from 'framer-motion';
import { Filter, Download } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { SessionType } from '@/lib/pitchLogic';
import { getEntries, saveEntries } from '@/lib/storage';
import StatusBadge from '@/components/StatusBadge';
import SessionTypeBadge from '@/components/SessionTypeBadge';
import { useAuth } from '@/hooks/useAuth';
import { useConnections } from '@/hooks/useConnections';
import { supabase } from '@/integrations/supabase/client';
import { calculateAge } from '@/lib/age';
import { getRequiredRestDays } from '@/lib/pitchSmartEngine';
import { toast } from 'sonner';

const filterOptions: (SessionType | 'All')[] = ['All', 'Game', 'Practice', 'Lesson', 'Bullpen', 'Other'];

// Capitalise first letter to match SessionType union
function normaliseSessionType(raw: string | null): SessionType {
  if (!raw) return 'Other';
  const map: Record<string, SessionType> = {
    game: 'Game', practice: 'Practice', lesson: 'Lesson',
    bullpen: 'Bullpen', other: 'Other',
  };
  return map[raw.toLowerCase()] ?? 'Other';
}

interface HistoryEntry {
  id: string;
  date: string;
  pitchCount: number;
  sessionType: SessionType;
  innings: number;
  notes: string;
  restDays: number;
}

export default function HistoryScreen() {
  const [filter, setFilter] = useState<SessionType | 'All'>('All');
  const { user, profile } = useAuth();
  const { roster } = useConnections();
  const isStaff = profile?.role === 'coach' || profile?.role === 'trainer';
  const [exporting, setExporting] = useState(false);
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  // ── One-time migration: push any localStorage entries to Supabase ──
  const migrateLocalStorage = useCallback(async (userId: string, age: number) => {
    const local = getEntries();
    if (local.length === 0) return;

    const { data: existing } = await supabase
      .from('pitch_logs')
      .select('date, pitch_count')
      .eq('player_id', userId);

    const toInsert = local.filter(entry => {
      // Skip if an identical date+count already exists in Supabase
      return !existing?.some(
        e => e.date === entry.date && e.pitch_count === entry.pitchCount
      );
    });

    if (toInsert.length > 0) {
      await supabase.from('pitch_logs').insert(
        toInsert.map(entry => ({
          player_id: userId,
          created_by: userId,
          date: entry.date,
          pitch_count: entry.pitchCount,
          innings: entry.innings || null,
          session_type: entry.sessionType.toLowerCase(),
          notes: entry.notes || null,
        }))
      );
    }

    // Clear localStorage now that data is in Supabase
    saveEntries([]);
  }, []);

  // ── Fetch history from Supabase ──
  const fetchHistory = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const age = profile?.birthdate ? calculateAge(profile.birthdate) : 14;

    // Migrate any leftover localStorage data first
    await migrateLocalStorage(user.id, age);

    const { data: logs, error } = await supabase
      .from('pitch_logs')
      .select('id, date, pitch_count, innings, session_type, notes')
      .eq('player_id', user.id)
      .order('date', { ascending: false });

    if (error) {
      toast.error('Failed to load history');
      setLoading(false);
      return;
    }

    const mapped: HistoryEntry[] = (logs ?? []).map(l => ({
      id: l.id,
      date: l.date ?? '',
      pitchCount: l.pitch_count,
      sessionType: normaliseSessionType(l.session_type),
      innings: l.innings ?? 0,
      notes: l.notes ?? '',
      restDays: getRequiredRestDays(l.pitch_count, age),
    }));

    setEntries(mapped);
    setLoading(false);
  }, [user, profile, migrateLocalStorage]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const filtered = useMemo(() => {
    if (filter === 'All') return entries;
    return entries.filter(e => e.sessionType === filter);
  }, [entries, filter]);

  const handleExportCSV = async () => {
    if (roster.length === 0) {
      toast.error('No players on your roster');
      return;
    }
    setExporting(true);
    try {
      const playerIds = roster.map(p => p.id);
      const { data: logs } = await supabase
        .from('pitch_logs')
        .select('player_id, date, pitch_count, velo, strikes, arm_feel')
        .in('player_id', playerIds)
        .order('date', { ascending: false });

      if (!logs || logs.length === 0) {
        toast.error('No pitch logs to export');
        setExporting(false);
        return;
      }

      const nameMap: Record<string, string> = {};
      for (const p of roster) nameMap[p.id] = p.full_name;

      const headers = ['Date', 'Player Name', 'Pitch Count', 'Max Velo', 'Strike %', 'Arm Soreness'];
      const rows = logs.map(l => {
        const strikePercent = l.strikes != null && l.pitch_count > 0
          ? `${Math.round((l.strikes / l.pitch_count) * 100)}%`
          : '';
        return [
          l.date ?? '',
          nameMap[l.player_id ?? ''] ?? 'Unknown',
          String(l.pitch_count),
          l.velo != null ? String(l.velo) : '',
          strikePercent,
          l.arm_feel ?? '',
        ].join(',');
      });

      const csv = [headers.join(','), ...rows].join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `pitch_logs_${format(new Date(), 'yyyy-MM-dd')}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('CSV downloaded!');
    } catch {
      toast.error('Export failed');
    }
    setExporting(false);
  };

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-4 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">History</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {loading ? 'Loading...' : `${entries.length} total sessions`}
          </p>
        </div>
        {isStaff && (
          <Button
            variant="outline"
            size="sm"
            className="h-8 gap-1.5 text-xs"
            onClick={handleExportCSV}
            disabled={exporting}
          >
            <Download className="w-3.5 h-3.5" />
            {exporting ? 'Exporting...' : 'CSV'}
          </Button>
        )}
      </header>

      <div className="mb-4">
        <Select value={filter} onValueChange={(v) => setFilter(v as SessionType | 'All')}>
          <SelectTrigger className="bg-secondary border-border">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <SelectValue />
            </div>
          </SelectTrigger>
          <SelectContent>
            {filterOptions.map(o => (
              <SelectItem key={o} value={o}>{o}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <p className="text-sm">No sessions logged yet.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((entry, i) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.03 }}
              className="bg-card rounded-xl p-4 border border-border"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">
                  {entry.date ? format(parseISO(entry.date), 'EEE, MMM d') : '—'}
                </span>
                <StatusBadge restDays={entry.restDays} />
              </div>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-mono font-bold">{entry.pitchCount}</span>
                <span className="text-xs text-muted-foreground">pitches</span>
                {entry.innings > 0 && (
                  <>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-sm font-mono">{entry.innings} IP</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <SessionTypeBadge type={entry.sessionType} />
                {entry.notes && (
                  <span className="text-xs text-muted-foreground truncate">{entry.notes}</span>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
