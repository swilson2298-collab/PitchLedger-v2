import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { TIERS, TierKey, getTierForRole } from '@/lib/tiers';
import { Button } from '@/components/ui/button';
import { Sparkles, CreditCard, Crown, ArrowLeft, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function BillingPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState<string | null>(null);

  const currentTier = profile?.subscription_tier ?? 'free';
  const isPremium = currentTier !== 'free';
  const relevantTier = getTierForRole(profile?.role ?? null);

  const handleUpgrade = async (tier: TierKey) => {
    setLoading(tier);
    const { data, error } = await supabase.functions.invoke('create-checkout', {
      body: { tier },
    });
    if (error || !data?.url) {
      toast.error('Failed to start checkout');
      setLoading(null);
      return;
    }
    window.open(data.url, '_blank');
    setLoading(null);
  };

  const handleManage = async () => {
    setLoading('manage');
    const { data, error } = await supabase.functions.invoke('customer-portal');
    if (error || !data?.url) {
      toast.error('Failed to open billing portal');
      setLoading(null);
      return;
    }
    window.open(data.url, '_blank');
    setLoading(null);
  };

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-6 flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Billing</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your subscription</p>
        </div>
      </header>

      {/* Current Plan */}
      <div className="mb-6 p-4 rounded-xl border border-border bg-card">
        <div className="flex items-center gap-2 mb-2">
          {isPremium ? (
            <Crown className="w-5 h-5 text-accent" />
          ) : (
            <CreditCard className="w-5 h-5 text-muted-foreground" />
          )}
          <h3 className="font-semibold">
            {isPremium ? TIERS[currentTier as TierKey]?.label ?? 'Premium' : 'Free Plan'}
          </h3>
        </div>
        <p className="text-sm text-muted-foreground">
          {isPremium
            ? 'You have full access to all premium features.'
            : 'Upgrade to unlock advanced features and remove connection limits.'}
        </p>
        {isPremium && (
          <Button
            variant="outline"
            className="mt-3 gap-2"
            onClick={handleManage}
            disabled={loading === 'manage'}
          >
            <ExternalLink className="w-4 h-4" />
            {loading === 'manage' ? 'Opening…' : 'Manage Subscription'}
          </Button>
        )}
      </div>

      {/* Upgrade Card */}
      {!isPremium && relevantTier && (
        <div className="rounded-xl border-2 border-accent/40 bg-accent/5 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-accent" />
            <h3 className="font-bold text-lg">{TIERS[relevantTier].label}</h3>
            <span className="ml-auto font-mono font-bold text-accent">{TIERS[relevantTier].price}</span>
          </div>

          <ul className="space-y-2">
            {TIERS[relevantTier].features.map((f) => (
              <li key={f} className="text-sm flex items-start gap-2">
                <span className="text-accent mt-0.5">✓</span>
                <span>{f}</span>
              </li>
            ))}
          </ul>

          <Button
            className="w-full h-12 text-base font-semibold gap-2"
            onClick={() => handleUpgrade(relevantTier)}
            disabled={loading === relevantTier}
          >
            {loading === relevantTier ? (
              <>
                <span className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full" />
                Redirecting to Stripe…
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Upgrade Now
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
