import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, AlertTriangle, User, BookOpen, ChevronDown, ShieldOff, ShieldAlert } from 'lucide-react';
import { getRestDayTable, getAgeGuidelines, redFlags } from '@/lib/pitchLogic';
import { useAuth } from '@/hooks/useAuth';
import { calculateAge } from '@/lib/age';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { useConnections } from '@/hooks/useConnections';
import { supabase } from '@/integrations/supabase/client';
import { calculateAvailability, AvailabilityResult, PitchLogEntry } from '@/lib/pitchSmartEngine';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface FlaggedPlayer {
  id: string;
  name: string;
  availability: AvailabilityResult;
  age: number;
}

export default function SafetyScreen() {
  const restTable = getRestDayTable();
  const guidelines = getAgeGuidelines();
  const { user, profile, signOut } = useAuth();
  const playerAge = profile?.birthdate ? calculateAge(profile.birthdate) : 14;
  const playerName = profile?.full_name ?? '';
  const isStaff = profile?.role === 'coach' || profile?.role === 'trainer';
  const { roster } = useConnections();
  const [flaggedPlayers, setFlaggedPlayers] = useState<FlaggedPlayer[]>([]);

  // For staff: mirror SHUT_DOWN and CAUTION players here
  useEffect(() => {
    if (!isStaff || roster.length === 0) return;
    const playerIds = roster.map(p => p.id);

    const fetchFlagged = async () => {
      const { data: logs } = await supabase
        .from('pitch_logs')
        .select('player_id, pitch_count, arm_feel, date')
        .in('player_id', playerIds)
        .order('date', { ascending: false });

      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, birthdate, full_name')
        .in('id', playerIds);

      if (!logs || !profiles) return;

      const flagged: FlaggedPlayer[] = [];
      for (const p of profiles) {
        const playerLogs = logs.filter(l => l.player_id === p.id);
        const lastLog: PitchLogEntry | null = playerLogs.length > 0 ? playerLogs[0] : null;
        const age = p.birthdate ? calculateAge(p.birthdate) : 14;
        const avail = calculateAvailability(lastLog, age);

        if (avail.status === 'SHUT_DOWN' || avail.status === 'CAUTION') {
          flagged.push({ id: p.id, name: p.full_name ?? 'Unknown', availability: avail, age });
        }
      }
      // SHUT_DOWN first
      flagged.sort((a, b) => (a.availability.status === 'SHUT_DOWN' ? -1 : 1));
      setFlaggedPlayers(flagged);
    };
    fetchFlagged();
  }, [isStaff, roster]);

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Safety & Profile</h1>
        <p className="text-sm text-muted-foreground mt-1">PitchSmart guidelines & settings</p>
      </header>

      {/* Staff: Flagged Players Section */}
      {isStaff && flaggedPlayers.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-destructive/5 border border-destructive/20 rounded-xl p-4 mb-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            <h2 className="font-semibold text-sm">Player Alerts ({flaggedPlayers.length})</h2>
          </div>
          <div className="space-y-2">
            {flaggedPlayers.map(fp => (
              <div
                key={fp.id}
                className={cn(
                  "flex items-center justify-between p-2.5 rounded-lg border",
                  fp.availability.status === 'SHUT_DOWN'
                    ? 'border-destructive/30 bg-destructive/5'
                    : 'border-[hsl(var(--status-yellow))]/30 bg-[hsl(var(--status-yellow))]/5'
                )}
              >
                <div>
                  <p className="text-sm font-semibold">{fp.name}</p>
                  <p className="text-[11px] text-muted-foreground">{fp.availability.reason}</p>
                </div>
                {fp.availability.status === 'SHUT_DOWN' ? (
                  <Badge variant="destructive" className="text-[9px] px-1.5 py-0 animate-pulse gap-0.5">
                    <ShieldOff className="w-2.5 h-2.5" />
                    Shut Down
                    {fp.availability.eligibleDate && (
                      <span className="ml-1">→ {format(fp.availability.eligibleDate, 'MMM d')}</span>
                    )}
                  </Badge>
                ) : (
                  <Badge className="text-[9px] px-1.5 py-0 gap-0.5 bg-[hsl(var(--status-yellow))]/15 text-[hsl(var(--status-yellow))] border-[hsl(var(--status-yellow))]/30">
                    <ShieldAlert className="w-2.5 h-2.5" />
                    Caution
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {isStaff && flaggedPlayers.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[hsl(var(--status-green))]/5 border border-[hsl(var(--status-green))]/20 rounded-xl p-4 mb-6 text-center"
        >
          <p className="text-sm font-medium text-[hsl(var(--status-green))]">✅ All players are cleared to pitch</p>
        </motion.div>
      )}

      {/* Profile Summary */}
      {!isStaff && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-xl p-4 border border-border mb-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <User className="w-4 h-4 text-primary" />
            <h2 className="font-semibold text-sm">Player Profile</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <span className="text-xs text-muted-foreground block">Name</span>
              <span className="text-sm font-medium">{playerName || 'Not set'}</span>
            </div>
            <div>
              <span className="text-xs text-muted-foreground block">Age</span>
              <span className="text-sm font-medium">{playerAge}</span>
            </div>
            <div>
              <span className="text-xs text-muted-foreground block">Role</span>
              <span className="text-sm font-medium capitalize">{profile?.role || 'Not set'}</span>
            </div>
          </div>
        </motion.div>
      )}

      {/* Pitch Count & Rest Day Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-card rounded-xl p-4 border border-border mb-6"
      >
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm">Pitch Limits & Required Rest Days</h2>
        </div>
        <div className="overflow-x-auto -mx-2 px-2">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 pr-2 text-muted-foreground font-medium">Age</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">Max</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">0d</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">1d</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">2d</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">3d</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">4d</th>
                <th className="text-center py-2 px-1 text-muted-foreground font-medium">5d</th>
              </tr>
            </thead>
            <tbody>
              {restTable.map((row) => (
                <tr key={row.ageRange} className="border-b border-border last:border-0">
                  <td className="py-2 pr-2 font-medium">{row.ageRange}</td>
                  <td className="text-center py-2 px-1 font-mono font-bold text-primary">{row.max}</td>
                  {row.rest.map((r) => (
                    <td key={r.days} className="text-center py-2 px-1 text-muted-foreground">
                      {r.range}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Age-Specific Guidelines */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="bg-card rounded-xl p-4 border border-border mb-6"
      >
        <div className="flex items-center gap-2 mb-3">
          <BookOpen className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm">Suggested Guidelines by Age</h2>
        </div>
        <div className="space-y-2">
          {guidelines.map((g) => (
            <Collapsible key={g.ageRange}>
              <CollapsibleTrigger className="flex items-center justify-between w-full py-2.5 px-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors text-left">
                <div>
                  <span className="text-sm font-semibold">{g.ageRange}</span>
                  <span className="text-xs text-muted-foreground ml-2">({g.distance})</span>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
              </CollapsibleTrigger>
              <CollapsibleContent className="px-3 pt-2 pb-3">
                <div className="text-xs text-primary font-medium mb-2">
                  Max: {g.maxInnings}
                </div>
                <ul className="space-y-1.5">
                  {g.guidelines.map((item, j) => (
                    <li key={j} className="text-xs text-secondary-foreground flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-muted-foreground mt-1.5 shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      </motion.div>

      {/* Red Flags */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-destructive/5 border border-destructive/20 rounded-xl p-4"
      >
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="w-4 h-4 text-destructive" />
          <h2 className="font-semibold text-sm">When to See a Doctor</h2>
        </div>
        <ul className="space-y-2">
          {redFlags.map((flag, i) => (
            <li key={i} className="text-sm text-secondary-foreground flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-destructive mt-1.5 shrink-0" />
              {flag}
            </li>
          ))}
        </ul>
      </motion.div>
    </div>
  );
}
