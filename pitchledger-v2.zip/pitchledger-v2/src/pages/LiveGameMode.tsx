import { useState, useCallback, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Minus, Plus, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import SafetyWarning from '@/components/SafetyWarning';
import TrafficLightDot from '@/components/TrafficLightDot';
import type { TrafficLight } from '@/hooks/useConnections';

function triggerHaptic() {
  if ('vibrate' in navigator) {
    navigator.vibrate(25);
  }
}

export default function LiveGameMode() {
  const { playerId } = useParams<{ playerId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [playerName, setPlayerName] = useState('');
  const [pitchCount, setPitchCount] = useState(0);
  const [inning, setInning] = useState('1');
  const [saving, setSaving] = useState(false);

  // Safety interlock state
  const [trafficLight, setTrafficLight] = useState<TrafficLight>('green');
  const [recentPitches, setRecentPitches] = useState(0);
  const [showSafetyWarning, setShowSafetyWarning] = useState(false);
  const [safetyAcknowledged, setSafetyAcknowledged] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  useEffect(() => {
    if (!playerId) return;

    const load = async () => {
      // Fetch player name
      const { data: prof } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', playerId)
        .single();
      setPlayerName(prof?.full_name ?? 'Player');

      // Fetch 48hr pitch data for traffic light
      const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString().split('T')[0];
      const { data: logs } = await supabase
        .from('pitch_logs')
        .select('pitch_count, arm_feel')
        .eq('player_id', playerId)
        .gte('date', cutoff);

      const total = (logs ?? []).reduce((s, l) => s + (l.pitch_count ?? 0), 0);
      const hasSore = (logs ?? []).some(l => l.arm_feel?.toLowerCase() === 'sore');

      let status: TrafficLight = 'green';
      if (total >= 76 || hasSore) status = 'red';
      else if (total >= 31) status = 'yellow';

      setTrafficLight(status);
      setRecentPitches(total);

      // Show safety warning immediately if red
      if (status === 'red') {
        setShowSafetyWarning(true);
      }

      setInitialLoading(false);
    };

    load();
  }, [playerId]);

  const addPitch = useCallback(() => {
    setPitchCount(prev => prev + 1);
    triggerHaptic();
  }, []);

  const removePitch = useCallback(() => {
    setPitchCount(prev => Math.max(0, prev - 1));
  }, []);

  const resetCount = useCallback(() => {
    setPitchCount(0);
  }, []);

  const saveSession = async () => {
    if (!playerId || !user || pitchCount === 0) return;
    setSaving(true);

    const { error } = await supabase
      .from('pitch_logs')
      .insert({
        player_id: playerId,
        created_by: user.id,
        pitch_count: pitchCount,
        innings: parseFloat(inning),
        session_type: 'Game',
        date: new Date().toISOString().split('T')[0],
      });

    if (error) {
      toast.error('Failed to save session');
    } else {
      triggerHaptic();
      toast.success(`Logged ${pitchCount} pitches for ${playerName}`);
      navigate(-1);
    }
    setSaving(false);
  };

  if (initialLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Safety interlock: must acknowledge before continuing
  if (trafficLight === 'red' && !safetyAcknowledged) {
    return (
      <SafetyWarning
        open={true}
        playerName={playerName}
        recentPitches={recentPitches}
        onAcknowledge={() => {
          setSafetyAcknowledged(true);
          setShowSafetyWarning(false);
        }}
        onCancel={() => navigate(-1)}
      />
    );
  }

  const inningsOptions = Array.from({ length: 10 }, (_, i) => (i + 1).toString());

  return (
    <div className="min-h-screen flex flex-col px-4 pt-6 pb-8 max-w-lg mx-auto">
      {/* Header */}
      <header className="flex items-center gap-3 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-bold tracking-tight">Live Game</h1>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">{playerName}</span>
            <TrafficLightDot status={trafficLight} size="sm" showLabel />
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs text-muted-foreground uppercase tracking-wider">48hr</span>
          <p className="text-sm font-mono font-semibold">{recentPitches + pitchCount}p</p>
        </div>
      </header>

      {/* Pitch Counter — large and centered */}
      <div className="flex-1 flex flex-col items-center justify-center gap-8">
        {/* Count Display */}
        <motion.div
          key={pitchCount}
          initial={{ scale: 1.08 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 15, stiffness: 300 }}
          className="text-center"
        >
          <span className="text-[7rem] leading-none font-mono font-bold text-primary drop-shadow-[0_0_30px_hsl(var(--primary)/0.3)]">
            {pitchCount}
          </span>
          <p className="text-sm text-muted-foreground uppercase tracking-widest mt-1">Pitches</p>
        </motion.div>

        {/* Large Thumb Buttons */}
        <div className="flex items-center gap-6">
          <button
            onClick={removePitch}
            className="w-20 h-20 rounded-full bg-secondary border-2 border-border flex items-center justify-center active:scale-95 transition-transform text-muted-foreground hover:text-foreground"
          >
            <Minus className="w-8 h-8" />
          </button>

          <button
            onClick={addPitch}
            className="w-28 h-28 rounded-full bg-primary text-primary-foreground flex items-center justify-center active:scale-90 transition-transform shadow-[0_0_40px_hsl(var(--primary)/0.4)]"
          >
            <Plus className="w-12 h-12" />
          </button>

          <button
            onClick={resetCount}
            className="w-20 h-20 rounded-full bg-secondary border-2 border-border flex items-center justify-center active:scale-95 transition-transform text-muted-foreground hover:text-foreground"
          >
            <RotateCcw className="w-7 h-7" />
          </button>
        </div>
      </div>

      {/* Inning Selector + Save */}
      <div className="space-y-4 mt-auto pt-6">
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
            Current Inning
          </label>
          <Select value={inning} onValueChange={setInning}>
            <SelectTrigger className="bg-secondary border-border h-14 text-lg font-mono">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {inningsOptions.map(v => (
                <SelectItem key={v} value={v} className="text-lg font-mono">{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={saveSession}
          disabled={pitchCount === 0 || saving}
          className="w-full h-16 text-lg font-semibold"
        >
          {saving ? 'Saving…' : `Save Session — ${pitchCount} Pitches`}
        </Button>
      </div>
    </div>
  );
}
