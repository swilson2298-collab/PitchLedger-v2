import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, LogOut, Shield, Activity, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { calculateAge } from "@/lib/age";
import { calculateAvailability, PitchLogEntry } from "@/lib/pitchSmartEngine";
import { format, parseISO } from "date-fns";
import MedicalDisclaimer from "@/components/MedicalDisclaimer";
import { cn } from "@/lib/utils";

interface LinkedChild {
  id: string;
  full_name: string;
  birthdate: string | null;
  age: number;
  status: "FRESH" | "CAUTION" | "SHUT_DOWN";
  daysUntilEligible: number;
  lastSession: string | null;
  recentPitches: number;
}

export default function ParentDashboard() {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [children, setChildren] = useState<LinkedChild[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchChildren = async () => {
      setLoading(true);

      // Get linked children via parent_child_links
      const { data: links } = await supabase
        .from("parent_child_links")
        .select("child_id")
        .eq("parent_id", user.id)
        .eq("status", "active");

      if (!links || links.length === 0) {
        setLoading(false);
        return;
      }

      const childIds = links.map(l => l.child_id);

      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, birthdate")
        .in("id", childIds);

      const { data: logs } = await supabase
        .from("pitch_logs")
        .select("player_id, date, pitch_count, arm_feel")
        .in("player_id", childIds)
        .order("date", { ascending: false });

      const result: LinkedChild[] = (profiles ?? []).map(p => {
        const playerLogs = (logs ?? []).filter(l => l.player_id === p.id);
        const lastLog: PitchLogEntry | null = playerLogs[0] ?? null;
        const age = p.birthdate ? calculateAge(p.birthdate) : 14;
        const avail = calculateAvailability(lastLog, age);
        const recent7 = playerLogs
          .filter(l => l.date && new Date(l.date) >= new Date(Date.now() - 7 * 86400000))
          .reduce((s, l) => s + (l.pitch_count ?? 0), 0);

        return {
          id: p.id,
          full_name: p.full_name ?? "Child",
          birthdate: p.birthdate,
          age,
          status: avail.status,
          daysUntilEligible: avail.daysUntilEligible,
          lastSession: lastLog?.date ?? null,
          recentPitches: recent7,
        };
      });

      setChildren(result);
      setLoading(false);
    };
    fetchChildren();
  }, [user]);

  const statusColor = (s: LinkedChild["status"]) => {
    if (s === "SHUT_DOWN") return "text-destructive";
    if (s === "CAUTION") return "text-[hsl(var(--status-yellow))]";
    return "text-[hsl(var(--status-green))]";
  };

  const statusEmoji = (s: LinkedChild["status"]) => {
    if (s === "SHUT_DOWN") return "🛑";
    if (s === "CAUTION") return "⚠️";
    return "✅";
  };

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-5 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Parent Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{profile?.full_name ?? "Parent"}</p>
        </div>
        <Button variant="ghost" size="icon" onClick={signOut}>
          <LogOut className="w-4 h-4" />
        </Button>
      </header>

      {loading ? (
        <div className="flex justify-center py-20">
          <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      ) : children.length === 0 ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-20 h-20 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center mb-6">
            <Users className="w-10 h-10 text-primary/60" />
          </div>
          <h2 className="text-xl font-bold mb-2">No linked players yet</h2>
          <p className="text-sm text-muted-foreground max-w-xs">
            Ask your child's coach or trainer to link your account so you can monitor their activity.
          </p>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {children.map((child, i) => (
            <motion.div key={child.id}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}>
              <Card className={cn("border cursor-pointer hover:border-primary/30 transition-colors",
                child.status === "SHUT_DOWN" && "border-destructive/30 bg-destructive/5",
                child.status === "CAUTION" && "border-[hsl(var(--status-yellow))]/30")}
                onClick={() => navigate(`/player/${child.id}`)}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="text-sm font-bold">{child.full_name}</p>
                      <p className="text-xs text-muted-foreground">Age {child.age}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>

                  <div className={cn("text-sm font-semibold mb-1", statusColor(child.status))}>
                    {statusEmoji(child.status)} {child.status === "SHUT_DOWN"
                      ? `Rest required — ${child.daysUntilEligible} day${child.daysUntilEligible !== 1 ? "s" : ""} remaining`
                      : child.status === "CAUTION" ? "Recovery in progress" : "Ready to throw"}
                  </div>

                  <div className="flex gap-4 mt-2">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Activity className="w-3.5 h-3.5" />
                      {child.recentPitches} pitches this week
                    </div>
                    {child.lastSession && (
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Shield className="w-3.5 h-3.5" />
                        Last: {format(parseISO(child.lastSession), "MMM d")}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      <MedicalDisclaimer />
    </div>
  );
}
