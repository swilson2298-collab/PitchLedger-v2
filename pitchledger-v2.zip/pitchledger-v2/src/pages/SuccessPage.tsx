import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import confetti from 'canvas-confetti';
import { TIERS, TierKey } from '@/lib/tiers';

export default function SuccessPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { refreshProfile } = useAuth();
  const tier = searchParams.get('tier') as TierKey | null;
  const tierInfo = tier ? TIERS[tier] : null;

  useEffect(() => {
    // Fire confetti
    const duration = 2000;
    const end = Date.now() + duration;
    const colors = ['#22c55e', '#f59e0b', '#3b82f6'];

    const frame = () => {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors,
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors,
      });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    frame();

    // Sync subscription status
    const sync = async () => {
      await supabase.functions.invoke('check-subscription');
      await refreshProfile();
    };
    sync();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', damping: 15 }}
        className="max-w-sm w-full text-center space-y-6"
      >
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-primary/15 border-2 border-primary/40 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-primary" />
          </div>
        </div>

        <div>
          <h1 className="text-3xl font-bold mb-2">You're Pro!</h1>
          <p className="text-muted-foreground">
            {tierInfo
              ? `Welcome to ${tierInfo.label}. All premium features are now unlocked.`
              : 'Your subscription is now active. All premium features are unlocked.'}
          </p>
        </div>

        {tierInfo && (
          <div className="rounded-xl border border-accent/30 bg-accent/5 p-4 text-left space-y-1">
            <p className="text-sm font-semibold text-accent flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              Now unlocked:
            </p>
            <ul className="text-sm text-muted-foreground space-y-0.5">
              {tierInfo.features.map((f) => (
                <li key={f}>✓ {f}</li>
              ))}
            </ul>
          </div>
        )}

        <Button
          className="w-full h-12 text-base font-semibold"
          onClick={() => navigate('/')}
        >
          Go to Dashboard
        </Button>
      </motion.div>
    </div>
  );
}
