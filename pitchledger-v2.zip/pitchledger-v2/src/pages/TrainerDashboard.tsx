import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, LogOut, Send, Search, ChevronRight, ShieldOff, ShieldAlert, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useConnections } from "@/hooks/useConnections";
import { supabase } from "@/integrations/supabase/client";
import { calculateAge } from "@/lib/age";
import { calculateAvailability, AvailabilityResult, PitchLogEntry, availabilitySortOrder } from "@/lib/pitchSmartEngine";
import { format } from "date-fns";
import TrainerConnectDialog from "@/components/TrainerConnectDialog";
import { cn } from "@/lib/utils";

interface PlayerRow {
  id: string;
  full_name: string;
  age: number;
  availability: AvailabilityResult;
  lastSession: string | null;
  recentPitches: number;
  maxVelo: number | null;
}

export default function TrainerDashboard() {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const { roster, loading, sendTrainerRequest } = useConnections();
  const [showConnect, setShowConnect] = useState(false);
  const [players, setPlayers] = useState<PlayerRow[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (roster.length === 0) return;
    const playerIds = roster.map(p => p.id);

    const fetchStats = async () => {
      const { data: logs } = await supabase
        .from("pitch_logs")
        .select("player_id, date, pitch_count, arm_feel, velo")
        .in("player_id", playerIds)
        .order("date", { ascending: false });

      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, birthdate")
        .in("id", playerIds);

      const ageMap: Record<string, number> = {};
      for (const p of profiles ?? []) {
        ageMap[p.id] = p.birthdate ? calculateAge(p.birthdate) : 14;
      }

      const rows: PlayerRow[] = roster.map(p => {
        const playerLogs = (logs ?? []).filter(l => l.player_id === p.id);
        const lastLog: PitchLogEntry | null = playerLogs[0] ?? null;
        const age = ageMap[p.id] ?? 14;
        const avail = calculateAvailability(lastLog, age);
        const recent = playerLogs
          .filter(l => l.date && new Date(l.date) >= new Date(Date.now() - 7 * 86400000))
          .reduce((s, l) => s + (l.pitch_count ?? 0), 0);
        const velos = playerLogs.filter(l => l.velo).map(l => l.velo!);

        return {
          id: p.id,
          full_name: p.full_name,
          age,
          availability: avail,
          lastSession: lastLog?.date ?? null,
          recentPitches: recent,
          maxVelo: velos.length > 0 ? Math.max(...velos) : null,
        };
      });

      rows.sort((a, b) =>
        availabilitySortOrder(a.availability.status) - availabilitySortOrder(b.availability.status)
      );
      setPlayers(rows);
    };
    fetchStats();
  }, [roster]);

  const filtered = useMemo(() => {
    if (!search.trim()) return players;
    const q = search.toLowerCase();
    return players.filter(p => p.full_name.toLowerCase().includes(q));
  }, [players, search]);

  const StatusBadge = ({ status }: { status: AvailabilityResult["status"] }) => {
    if (status === "SHUT_DOWN") return (
      <Badge variant="destructive" className="text-[9px] px-1.5 py-0 gap-0.5">
        <ShieldOff className="w-2.5 h-2.5" /> Shut Down
      </Badge>
    );
    if (status === "CAUTION") return (
      <Badge className="text-[9px] px-1.5 py-0 gap-0.5 bg-[hsl(var(--status-yellow))]/15 text-[hsl(var(--status-yellow))] border-[hsl(var(--status-yellow))]/30">
        <ShieldAlert className="w-2.5 h-2.5" /> Caution
      </Badge>
    );
    return (
      <Badge className="text-[9px] px-1.5 py-0 gap-0.5 bg-[hsl(var(--status-green))]/15 text-[hsl(var(--status-green))] border-[hsl(var(--status-green))]/30">
        <ShieldCheck className="w-2.5 h-2.5" /> Fresh
      </Badge>
    );
  };

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-5 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Players</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{profile?.full_name ?? "Trainer"}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={() => setShowConnect(true)}>
            <Send className="w-3.5 h-3.5" /> Connect
          </Button>
          <Button variant="ghost" size="icon" onClick={signOut}>
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {loading ? (
        <div className="flex justify-center py-20">
          <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      ) : roster.length === 0 ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-20 h-20 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center mb-6">
            <Users className="w-10 h-10 text-primary/60" />
          </div>
          <h2 className="text-xl font-bold mb-2">No players yet</h2>
          <p className="text-sm text-muted-foreground max-w-xs mb-6">
            Send a connection request to a player using their email address.
          </p>
          <Button onClick={() => setShowConnect(true)} className="gap-2">
            <Send className="w-4 h-4" /> Connect with Player
          </Button>
        </motion.div>
      ) : (
        <>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search players..." value={search} onChange={e => setSearch(e.target.value)}
              className="pl-9 bg-secondary border-border" />
          </div>

          <div className="space-y-2">
            {filtered.map((player, i) => (
              <motion.div key={player.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className={cn("flex items-center gap-3 p-3 rounded-xl border bg-card cursor-pointer hover:border-primary/30 transition-colors",
                  player.availability.status === "SHUT_DOWN" && "border-destructive/30 bg-destructive/5",
                  player.availability.status === "CAUTION" && "border-[hsl(var(--status-yellow))]/30")}
                onClick={() => navigate(`/player/${player.id}`)}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-sm font-bold truncate">{player.full_name}</p>
                    <span className="text-xs text-muted-foreground shrink-0">Age {player.age}</span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <StatusBadge status={player.availability.status} />
                    {player.maxVelo && (
                      <span className="text-[10px] text-muted-foreground">{player.maxVelo} mph top velo</span>
                    )}
                    {player.lastSession && (
                      <span className="text-[10px] text-muted-foreground">
                        Last: {format(new Date(player.lastSession), "MMM d")}
                      </span>
                    )}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </motion.div>
            ))}
          </div>
        </>
      )}

      <TrainerConnectDialog open={showConnect} onOpenChange={setShowConnect} onSend={sendTrainerRequest} />
    </div>
  );
}
