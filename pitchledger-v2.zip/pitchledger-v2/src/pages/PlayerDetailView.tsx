import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { format, parseISO, subDays } from 'date-fns';
import { ArrowLeft, Lock, FileText, Trash2 } from 'lucide-react';
import CommandChart from '@/components/CommandChart';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useConnections } from '@/hooks/useConnections';
import UpgradeModal from '@/components/UpgradeModal';
import ScoutingReportDialog from '@/components/ScoutingReportDialog';
import VeloChart from '@/components/VeloChart';
import { generateScoutingReport } from '@/lib/scoutingReport';
import { calculateAge } from '@/lib/age';
import type { PlayerPitchLog } from '@/hooks/useConnections';

export default function PlayerDetailView() {
  const { playerId } = useParams<{ playerId: string }>();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [playerProfile, setPlayerProfile] = useState<{
    full_name: string;
    share_health_data: boolean;
    birthdate: string | null;
    role: string | null;
  } | null>(null);
  const [logs, setLogs] = useState<PlayerPitchLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);
  const [confirmName, setConfirmName] = useState('');
  const { roster, removeConnection } = useConnections();

  const isCoach = profile?.role === 'coach';
  const isOwnProfile = user?.id === playerId;
  const canGenerateReport = isCoach || isOwnProfile;

  useEffect(() => {
    if (!playerId) return;
    const fetchData = async () => {
      setLoading(true);
      const [{ data: prof }, { data: pitchLogs }] = await Promise.all([
        supabase
          .from('profiles')
          .select('full_name, share_health_data, birthdate, role')
          .eq('id', playerId)
          .single(),
        supabase
          .from('pitch_logs')
          .select('id, date, pitch_count, innings, session_type, velo, notes, arm_feel, strikes')
          .eq('player_id', playerId)
          .order('date', { ascending: false })
          .limit(50),
      ]);
      setPlayerProfile(prof as any);
      setLogs((pitchLogs as PlayerPitchLog[]) ?? []);
      setLoading(false);
    };
    fetchData();
  }, [playerId]);

  const canSeeHealth = playerProfile?.share_health_data === true || isOwnProfile;

  const handleGenerateReport = async (coachNote: string) => {
    if (!playerProfile || !logs) return;
    setGeneratingPdf(true);

    try {
      const veloLogs = logs
        .filter(l => l.velo != null)
        .slice(0, 15)
        .reverse();

      const veloData = veloLogs.map(l => ({
        date: l.date ? format(parseISO(l.date), 'M/d') : '?',
        velo: l.velo!,
      }));

      const allVelos = logs.filter(l => l.velo != null).map(l => l.velo!);
      const maxVelo = allVelos.length > 0 ? Math.max(...allVelos) : null;
      const avgVelo = allVelos.length > 0 ? Math.round(allVelos.reduce((a, b) => a + b, 0) / allVelos.length) : null;

      // Strike percentage from actual data
      const strikeLogs = logs.filter(l => l.strikes != null && l.pitch_count > 0);
      const strikePercentage: number | null = strikeLogs.length > 0
        ? Math.round(strikeLogs.reduce((sum, l) => sum + (l.strikes! / l.pitch_count) * 100, 0) / strikeLogs.length)
        : null;

      // 30-day health
      const cutoff30d = subDays(new Date(), 30).toISOString().split('T')[0];
      const last30 = logs.filter(l => l.date && l.date >= cutoff30d);
      const armFeels = last30.map(l => l.arm_feel?.toLowerCase()).filter(Boolean) as string[];
      const healthy = armFeels.filter(f => f === 'great' || f === 'good' || f === 'normal' || f === 'fresh').length;
      const mild = armFeels.filter(f => f === 'tight' || f === 'fatigued' || f === 'mild').length;
      const sore = armFeels.filter(f => f === 'sore' || f === 'pain').length;

      const age = playerProfile.birthdate ? calculateAge(playerProfile.birthdate) : null;
      const gradYear = age ? `${new Date().getFullYear() + Math.max(0, 18 - age)}` : 'N/A';

      generateScoutingReport({
        playerName: playerProfile.full_name ?? 'Unknown',
        role: playerProfile.role ?? 'Player',
        teamName: profile?.full_name ? `${profile.full_name}'s Team` : 'Team',
        graduationYear: gradYear,
        veloData,
        maxVelo,
        avgVelo,
        strikePercentage,
        armFeelSummary: { healthy, mild, sore },
        totalSessions30d: last30.length,
        coachNote,
        coachName: isCoach ? (profile?.full_name ?? 'Coach') : (playerProfile.full_name ?? 'Player'),
      });

      setShowReportDialog(false);
    } finally {
      setGeneratingPdf(false);
    }
  };

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-6 flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-xl font-bold tracking-tight">
            {playerProfile?.full_name ?? 'Player'}
          </h1>
          <p className="text-xs text-muted-foreground">Pitch Log History</p>
        </div>
      </header>

      {/* Generate Scouting Report — visible to coach and player */}
      {canGenerateReport && (
        <div className="mb-6">
          <Button
            onClick={() => setShowReportDialog(true)}
            className="w-full gap-2"
            variant="outline"
          >
            <FileText className="w-4 h-4" />
            Generate Scouting Report
          </Button>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-12">
          <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      ) : logs.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-16">No pitch logs recorded yet.</p>
      ) : (
        <div className="space-y-4">
          {/* Velocity Chart */}
          <VeloChart logs={logs} />

          {/* Command Chart */}
          <CommandChart logs={logs} />

          {/* Recent Sessions */}
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mt-4">
            Recent Sessions
          </h3>
          {logs.slice(0, 10).map((log) => (
            <div
              key={log.id}
              className="rounded-lg border border-border bg-card p-3 flex items-center gap-3"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-semibold">
                    {log.date ? format(parseISO(log.date), 'MMM d') : '—'}
                  </span>
                  <span className="text-xs text-muted-foreground uppercase">
                    {log.session_type ?? 'Session'}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                  <span className="font-mono font-semibold text-foreground">{log.pitch_count}p</span>
                  {log.velo != null && <span className="font-mono">{log.velo} mph</span>}
                  {canSeeHealth && log.arm_feel && (
                    <span className={log.arm_feel.toLowerCase() === 'sore' || log.arm_feel.toLowerCase() === 'pain' ? 'text-destructive' : ''}>
                      {log.arm_feel}
                    </span>
                  )}
                  {!canSeeHealth && (
                    <span className="inline-flex items-center gap-0.5 text-muted-foreground/50">
                      <Lock className="w-3 h-3" /> Private
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Danger Zone — Remove Player (coaches only) */}
      {isCoach && playerId && (
        <div className="mt-12 pt-6 border-t border-border">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Danger Zone</h3>
          <Button
            variant="outline"
            className="w-full text-destructive border-destructive/30 hover:bg-destructive/5"
            onClick={() => { setConfirmName(''); setShowRemoveConfirm(true); }}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Remove Player from Roster
          </Button>
        </div>
      )}

      {/* Remove Confirmation Dialog */}
      <Dialog open={showRemoveConfirm} onOpenChange={setShowRemoveConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Remove Player</DialogTitle>
            <DialogDescription>
              This will remove <strong>{playerProfile?.full_name}</strong> from your roster. Type their full name to confirm.
            </DialogDescription>
          </DialogHeader>
          <Input
            placeholder={playerProfile?.full_name ?? 'Player name'}
            value={confirmName}
            onChange={e => setConfirmName(e.target.value)}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowRemoveConfirm(false)}>Cancel</Button>
            <Button
              variant="destructive"
              disabled={confirmName.trim().toLowerCase() !== (playerProfile?.full_name ?? '').toLowerCase()}
              onClick={() => {
                const connection = roster.find(p => p.id === playerId);
                if (connection) {
                  removeConnection(connection.connectionId);
                  navigate(-1);
                }
                setShowRemoveConfirm(false);
              }}
            >
              Remove Player
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ScoutingReportDialog
        open={showReportDialog}
        onOpenChange={setShowReportDialog}
        onGenerate={handleGenerateReport}
        playerName={playerProfile?.full_name ?? 'Player'}
        generating={generatingPdf}
        isPlayer={!isCoach}
      />
      <UpgradeModal open={showUpgrade} onOpenChange={setShowUpgrade} />
    </div>
  );
}
