import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MedicalDisclaimer from "@/components/MedicalDisclaimer";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarIcon,
  Send,
  Minus,
  Plus,
  Zap,
  AlertTriangle,
  CheckCircle2,
  ShieldOff,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { SessionType } from "@/lib/pitchLogic";
import { getDailyMax, getRequiredRestDays, calculateAvailability, PitchLogEntry } from "@/lib/pitchSmartEngine";
import { addEntry } from "@/lib/storage";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { calculateAge } from "@/lib/age";
import PlayerConnectionBar from "@/components/PlayerConnectionBar";
import StatusBadge from "@/components/StatusBadge";
import SafetyWarning from "@/components/SafetyWarning";
import { toast } from "sonner";
import { addDays } from "date-fns";

const sessionTypes: SessionType[] = ["Game", "Practice", "Lesson", "Bullpen", "Other"];

const ARM_FEEL_LABELS: Record<number, string> = {
  1: "Pain",
  2: "Sore",
  3: "Tight",
  4: "Fatigued",
  5: "Normal",
  6: "Normal",
  7: "Good",
  8: "Good",
  9: "Fresh",
  10: "Great",
};

function getArmFeelColor(value: number): string {
  if (value <= 2) return "hsl(0, 72%, 55%)";
  if (value <= 4) return "hsl(25, 85%, 55%)";
  if (value <= 6) return "hsl(38, 92%, 55%)";
  if (value <= 8) return "hsl(90, 60%, 50%)";
  return "hsl(145, 72%, 46%)";
}

export default function InputScreen() {
  const navigate = useNavigate();
  const [date, setDate] = useState<Date>(new Date());
  const [pitchCount, setPitchCount] = useState(0);
  const [sessionType, setSessionType] = useState<SessionType>("Bullpen");
  const [velo, setVelo] = useState("");
  const [strikes, setStrikes] = useState("");
  const [armFeel, setArmFeel] = useState(7);
  const [innings, setInnings] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [hasTeamConnection, setHasTeamConnection] = useState(false);
  const [showShutDownWarning, setShowShutDownWarning] = useState(false);
  const [currentAvailability, setCurrentAvailability] = useState<ReturnType<typeof calculateAvailability> | null>(null);
  const { user, profile: authProfile } = useAuth();
  const playerAge = authProfile?.birthdate ? calculateAge(authProfile.birthdate) : 14;
  const playerName = authProfile?.full_name ?? "";
  const dailyMax = getDailyMax(playerAge);

  // Check team connection + current availability
  useEffect(() => {
    if (!user) return;

    // Team connection check
    supabase
      .from("connections")
      .select("id")
      .eq("player_id", user.id)
      .eq("connection_type", "team")
      .eq("status", "active")
      .limit(1)
      .then(({ data }) => setHasTeamConnection((data?.length ?? 0) > 0));

    // Fetch last pitch log for availability
    supabase
      .from("pitch_logs")
      .select("date, pitch_count, arm_feel")
      .eq("player_id", user.id)
      .order("date", { ascending: false })
      .limit(1)
      .then(({ data }) => {
        const lastLog: PitchLogEntry | null = data && data.length > 0 ? data[0] : null;
        const avail = calculateAvailability(lastLog, playerAge);
        setCurrentAvailability(avail);
      });
  }, [user, playerAge]);

  const restDays = pitchCount > 0 ? getRequiredRestDays(pitchCount, playerAge) : 0;
  const availableDate = pitchCount > 0 ? addDays(new Date(format(date, "yyyy-MM-dd")), restDays) : null;

  // Safety alerts
  const isOverMax = pitchCount > dailyMax;
  const isNearMax = pitchCount >= Math.round(dailyMax * 0.75) && pitchCount <= dailyMax;
  const isShutDown = currentAvailability?.status === "SHUT_DOWN";

  const addPitches = (n: number) => setPitchCount((prev) => Math.max(0, prev + n));

  const handleSubmitAttempt = () => {
    if (pitchCount <= 0) return;
    if (isShutDown) {
      setShowShutDownWarning(true);
      return;
    }
    doSubmit();
  };

  const doSubmit = async () => {
    setShowShutDownWarning(false);
    setSubmitting(true);

    if (user) {
      const { error } = await supabase.from("pitch_logs").insert({
        player_id: user.id,
        created_by: user.id,
        date: format(date, "yyyy-MM-dd"),
        pitch_count: pitchCount,
        innings: innings ? parseFloat(innings) : null,
        session_type: sessionType.toLowerCase(),
        velo: velo ? parseInt(velo) : null,
        strikes: strikes ? parseInt(strikes) : null,
        arm_feel: ARM_FEEL_LABELS[armFeel] ?? "Normal",
        notes: notes || null,
      });

      if (error) {
        toast.error("Failed to save session");
        setSubmitting(false);
        return;
      }
    }

    const entry = {
      id: crypto.randomUUID(),
      date: format(date, "yyyy-MM-dd"),
      pitchCount,
      sessionType,
      innings: innings ? parseFloat(innings) : 0,
      notes,
      restDays,
      availableDate: availableDate ? format(availableDate, "yyyy-MM-dd") : format(date, "yyyy-MM-dd"),
    };
    addEntry(entry);

    setSubmitting(false);
    setShowSuccess(true);
  };

  const handleSuccessDismiss = () => {
    setShowSuccess(false);
    setPitchCount(0);
    setVelo("");
    setStrikes("");
    setInnings("");
    setArmFeel(7);
    setNotes("");
    navigate("/recovery");
  };

  // Success screen
  if (showSuccess) {
    return (
      <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto flex flex-col items-center justify-center text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", damping: 15 }}
          className="space-y-4"
        >
          <div className="w-20 h-20 rounded-full bg-primary/15 border-2 border-primary/30 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">Session Logged!</h2>
          {hasTeamConnection ? (
            <p className="text-sm text-muted-foreground">
              ✅ <span className="text-foreground font-medium">Data Synced to Coach</span> — your coach can now see this
              session.
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">Your session has been saved successfully.</p>
          )}
          <Button onClick={handleSuccessDismiss} className="w-full h-12 mt-4">
            Continue to Recovery
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-4">
        <h1 className="text-2xl font-bold tracking-tight">Log Session</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          {playerName ? `${playerName} · Age ${playerAge}` : `Age ${playerAge}`}
          <span className="ml-2 font-mono text-primary">Daily Max: {dailyMax}</span>
        </p>
      </header>

      {/* Shut Down Banner */}
      {isShutDown && currentAvailability && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl p-4 border border-destructive/40 bg-destructive/10 mb-4 flex items-start gap-3"
        >
          <ShieldOff className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-destructive">You are currently SHUT DOWN</p>
            <p className="text-xs text-muted-foreground mt-0.5">{currentAvailability.reason}</p>
            {currentAvailability.eligibleDate && (
              <p className="text-xs text-destructive font-mono mt-1">
                Eligible: {format(currentAvailability.eligibleDate, "MMM d, yyyy")}
              </p>
            )}
          </div>
        </motion.div>
      )}

      <div className="space-y-4">
        {/* Date + Session Type */}
        <div className="flex gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="flex-1 justify-start text-left font-normal bg-secondary border-border text-sm"
              >
                <CalendarIcon className="mr-2 h-3.5 w-3.5 text-muted-foreground" />
                {format(date, "MMM d")}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={date}
                onSelect={(d) => d && setDate(d)}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
          <Select value={sessionType} onValueChange={(v) => setSessionType(v as SessionType)}>
            <SelectTrigger className="flex-1 bg-secondary border-border text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sessionTypes.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Pitch Count */}
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between mb-3">
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Pitch Count</label>
            <span
              className={cn(
                "text-xs font-mono font-bold px-2 py-0.5 rounded-full",
                isOverMax ? "bg-destructive/15 text-destructive" : "bg-primary/10 text-primary",
              )}
            >
              Max: {dailyMax}
            </span>
          </div>
          <div className="text-center mb-4">
            <span
              className={cn(
                "text-6xl font-mono font-bold tabular-nums",
                isOverMax ? "text-destructive" : "text-foreground",
              )}
            >
              {pitchCount}
            </span>
          </div>

          {/* Quick add buttons */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            {[5, 10, 25].map((n) => (
              <button
                key={n}
                onClick={() => addPitches(n)}
                className="h-14 rounded-lg bg-primary/10 border border-primary/20 text-primary font-bold text-lg
                  active:scale-95 active:bg-primary/20 transition-all touch-manipulation"
              >
                +{n}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => addPitches(-1)}
              className="w-10 h-10 rounded-lg bg-secondary border border-border flex items-center justify-center active:scale-95 transition-all touch-manipulation"
            >
              <Minus className="w-4 h-4" />
            </button>
            <button
              onClick={() => addPitches(1)}
              className="w-10 h-10 rounded-lg bg-secondary border border-border flex items-center justify-center active:scale-95 transition-all touch-manipulation"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPitchCount(0)}
              className="px-3 h-10 rounded-lg bg-secondary border border-border text-xs text-muted-foreground active:scale-95 transition-all touch-manipulation"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Innings Pitched - Hybrid Input */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block text-primary/80">
            Innings Pitched — optional
          </label>
          <div className="relative">
            <Input
              list="innings-options"
              type="text"
              inputMode="decimal"
              placeholder="e.g. 2.1"
              value={innings}
              onChange={(e) => {
                const val = e.target.value;
                // Allow digits and one decimal point only
                if (val === "" || /^\d*\.?\d?$/.test(val)) {
                  setInnings(val);
                }
              }}
              className="bg-secondary border-border font-mono text-lg h-12 pr-10 focus:ring-primary/20"
            />

            {/* The Hidden Dropdown List - Numbers Only */}
            <datalist id="innings-options">
              {Array.from({ length: 11 }).map((_, whole) => (
                <React.Fragment key={whole}>
                  <option value={`${whole}.0`} />
                  <option value={`${whole}.1`} />
                  <option value={`${whole}.2`} />
                </React.Fragment>
              ))}
            </datalist>

            {/* Visual Indicator that it's a dropdown too */}
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground/50">
              <ChevronRight className="w-4 h-4 rotate-90" />
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground mt-1.5 leading-relaxed">
            Select from the list or type any value. <br />
            <span className="font-semibold text-primary/60">.1 = 1 out, .2 = 2 outs</span>
          </p>
        </div>
        {/* Arm Feel Slider */}
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center justify-between mb-3">
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Arm Feel</label>
            <span
              className="text-sm font-bold px-2.5 py-0.5 rounded-full"
              style={{ color: getArmFeelColor(armFeel), backgroundColor: `${getArmFeelColor(armFeel)}20` }}
            >
              {ARM_FEEL_LABELS[armFeel]}
            </span>
          </div>
          <div className="relative">
            <div
              className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-2 rounded-full"
              style={{
                background:
                  "linear-gradient(to right, hsl(0,72%,55%), hsl(25,85%,55%), hsl(38,92%,55%), hsl(90,60%,50%), hsl(145,72%,46%))",
              }}
            />
            <Slider
              value={[armFeel]}
              onValueChange={([v]) => setArmFeel(v)}
              min={1}
              max={10}
              step={1}
              className="relative"
            />
          </div>
          <div className="flex justify-between mt-1.5">
            <span className="text-[10px] text-destructive">Sore</span>
            <span className="text-[10px] text-primary">Fresh</span>
          </div>
        </div>

        {/* Velocity */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
            Top Velo (mph) — optional
          </label>
          <Input
            type="number"
            inputMode="numeric"
            placeholder="e.g. 72"
            value={velo}
            onChange={(e) => setVelo(e.target.value)}
            className="bg-secondary border-border font-mono text-lg h-12"
          />
        </div>

        {/* Strikes */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
            Strikes Thrown — optional
          </label>
          <div className="flex items-center gap-3">
            <Input
              type="number"
              inputMode="numeric"
              placeholder="e.g. 45"
              value={strikes}
              onChange={(e) => {
                const val = e.target.value;
                if (val === "") {
                  setStrikes("");
                  return;
                }
                const num = parseInt(val);
                if (!isNaN(num) && num >= 0 && num <= pitchCount) setStrikes(val);
                else if (!isNaN(num) && num > pitchCount) setStrikes(String(pitchCount));
              }}
              max={pitchCount}
              className="bg-secondary border-border font-mono text-lg h-12 flex-1"
            />
            {strikes && pitchCount > 0 && (
              <span className="text-sm font-mono font-bold px-3 py-1.5 rounded-lg bg-secondary border border-border whitespace-nowrap">
                {Math.round((parseInt(strikes) / pitchCount) * 100)}% strikes
              </span>
            )}
          </div>
        </div>

        {/* Live Status */}
        <AnimatePresence>
          {pitchCount > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={cn(
                "rounded-xl p-4 border",
                restDays === 0 && "border-primary/30 bg-primary/5",
                restDays <= 2 && restDays > 0 && "border-accent/30 bg-accent/5",
                restDays > 2 && "border-destructive/30 bg-destructive/5",
              )}
            >
              <div className="flex items-center justify-between mb-1">
                <StatusBadge restDays={restDays} />
                {availableDate && (
                  <span className="text-xs text-muted-foreground">
                    Available: <span className="font-semibold text-foreground">{format(availableDate, "MMM d")}</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {restDays} day{restDays !== 1 ? "s" : ""} rest required
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Over-max warning */}
        <AnimatePresence>
          {isOverMax && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="rounded-xl p-4 border border-destructive/40 bg-destructive/10 flex items-start gap-3"
            >
              <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
              <p className="text-sm font-medium text-destructive">
                ❗ {pitchCount} pitches exceeds the {dailyMax}-pitch daily max for age {playerAge}
              </p>
            </motion.div>
          )}
          {isNearMax && !isOverMax && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="rounded-xl p-4 border border-[hsl(var(--status-yellow))]/40 bg-[hsl(var(--status-yellow))]/10 flex items-start gap-3"
            >
              <AlertTriangle className="w-5 h-5 text-[hsl(var(--status-yellow))] shrink-0 mt-0.5" />
              <p className="text-sm font-medium text-[hsl(var(--status-yellow))]">
                ⚠️ Approaching daily max ({pitchCount}/{dailyMax})
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Notes */}
        <details className="group">
          <summary className="text-xs font-medium text-muted-foreground uppercase tracking-wider cursor-pointer select-none">
            Notes <span className="text-muted-foreground/50">(optional)</span>
          </summary>
          <textarea
            placeholder="Mechanics, cues, observations..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="mt-2 w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </details>

        {/* Submit */}
        <Button
          onClick={handleSubmitAttempt}
          disabled={pitchCount <= 0 || submitting}
          className={cn(
            "w-full h-14 text-base font-semibold gap-2",
            isShutDown && "bg-destructive hover:bg-destructive/90",
          )}
        >
          {submitting ? (
            <span className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full" />
          ) : isShutDown ? (
            <>
              <ShieldOff className="w-5 h-5" />
              Log Session (Shut Down)
            </>
          ) : (
            <>
              <Zap className="w-5 h-5" />
              Log Session
            </>
          )}
        </Button>
      </div>

      {/* PitchSmart Warning Modal */}
      <SafetyWarning
        open={showShutDownWarning}
        playerName={playerName || "Player"}
        recentPitches={currentAvailability?.restDays ?? 0}
        onAcknowledge={doSubmit}
        onCancel={() => setShowShutDownWarning(false)}
      />

      <MedicalDisclaimer />
    </div>
  );
}
