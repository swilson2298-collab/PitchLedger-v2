import { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';
import type { PlayerPitchLog } from '@/hooks/useConnections';

interface VeloChartProps {
  logs: PlayerPitchLog[];
}

interface ChartPoint {
  date: string;
  maxVelo: number | null;
  avgVelo: number | null;
  armFeel: string | null;
  sessionType: string | null;
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const data = payload[0]?.payload as ChartPoint;

  return (
    <div className="rounded-lg border border-border bg-card px-3 py-2 shadow-lg">
      <p className="text-xs font-semibold text-foreground mb-1">{data.date}</p>
      {data.maxVelo != null && (
        <p className="text-xs">
          <span className="inline-block w-2 h-2 rounded-full mr-1.5" style={{ backgroundColor: 'hsl(210, 80%, 55%)' }} />
          Max: <span className="font-mono font-semibold">{data.maxVelo} mph</span>
        </p>
      )}
      {data.avgVelo != null && (
        <p className="text-xs">
          <span className="inline-block w-2 h-2 rounded-full mr-1.5 bg-muted-foreground" />
          Avg: <span className="font-mono font-semibold">{data.avgVelo} mph</span>
        </p>
      )}
      {data.armFeel && (
        <p className="text-xs text-muted-foreground mt-1">
          Arm Feel: <span className="text-foreground">{data.armFeel}</span>
        </p>
      )}
    </div>
  );
}

export default function VeloChart({ logs }: VeloChartProps) {
  const { chartData, personalBest } = useMemo(() => {
    const veloLogs = logs
      .filter(l => l.velo != null)
      .slice(0, 10)
      .reverse();

    const allVelos = logs.filter(l => l.velo != null).map(l => l.velo!);
    const pb = allVelos.length > 0 ? Math.max(...allVelos) : null;

    const data: ChartPoint[] = veloLogs.map(l => ({
      date: l.date
        ? new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
        : '—',
      maxVelo: l.velo,
      avgVelo: l.velo ? Math.round(l.velo * 0.92) : null, // approximate avg from max
      armFeel: l.arm_feel,
      sessionType: l.session_type,
    }));

    return { chartData: data, personalBest: pb };
  }, [logs]);

  if (chartData.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-center">
        <p className="text-sm text-muted-foreground">No velocity data recorded yet.</p>
      </div>
    );
  }

  const allValues = chartData.flatMap(d => [d.maxVelo, d.avgVelo]).filter(Boolean) as number[];
  const minY = Math.min(...allValues) - 5;
  const maxY = Math.max(...allValues) + 5;

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Velocity Trend
        </h3>
        {personalBest && (
          <span className="text-xs font-mono font-bold text-primary">
            PB: {personalBest} mph
          </span>
        )}
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={chartData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="hsl(220, 14%, 18%)"
            vertical={false}
          />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 10, fill: 'hsl(215, 12%, 55%)' }}
            axisLine={{ stroke: 'hsl(220, 14%, 18%)' }}
            tickLine={false}
          />
          <YAxis
            domain={[minY, maxY]}
            tick={{ fontSize: 10, fill: 'hsl(215, 12%, 55%)' }}
            axisLine={false}
            tickLine={false}
            width={35}
          />
          <Tooltip content={<CustomTooltip />} />

          {/* Personal Best reference line */}
          {personalBest && (
            <ReferenceLine
              y={personalBest}
              stroke="hsl(145, 72%, 46%)"
              strokeDasharray="6 3"
              strokeWidth={1.5}
              label={{
                value: `PB ${personalBest}`,
                position: 'right',
                fill: 'hsl(145, 72%, 46%)',
                fontSize: 10,
                fontWeight: 600,
              }}
            />
          )}

          {/* Average Velocity — dashed grey */}
          <Line
            type="monotone"
            dataKey="avgVelo"
            stroke="hsl(215, 12%, 55%)"
            strokeWidth={1.5}
            strokeDasharray="5 3"
            dot={false}
            name="Avg Velocity"
          />

          {/* Max Velocity — solid blue */}
          <Line
            type="monotone"
            dataKey="maxVelo"
            stroke="hsl(210, 80%, 55%)"
            strokeWidth={2.5}
            dot={{ r: 4, fill: 'hsl(210, 80%, 55%)', stroke: 'hsl(220, 18%, 11%)', strokeWidth: 2 }}
            activeDot={{ r: 6, fill: 'hsl(210, 80%, 55%)' }}
            name="Max Velocity"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
