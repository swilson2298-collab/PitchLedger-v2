import { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Cell,
  ReferenceLine,
} from 'recharts';
import type { PlayerPitchLog } from '@/hooks/useConnections';

interface CommandChartProps {
  logs: PlayerPitchLog[];
}

interface ChartPoint {
  date: string;
  strikePct: number;
  strikes: number;
  pitches: number;
}

function getStrikeColor(pct: number): string {
  if (pct >= 65) return 'hsl(145, 72%, 46%)';
  if (pct >= 55) return 'hsl(38, 92%, 55%)';
  return 'hsl(0, 72%, 55%)';
}

function getStrikeLabel(pct: number): string {
  if (pct >= 65) return 'Elite Command';
  if (pct >= 55) return 'Average';
  return 'Needs Work';
}

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const data = payload[0]?.payload as ChartPoint;

  return (
    <div className="rounded-lg border border-border bg-card px-3 py-2 shadow-lg">
      <p className="text-xs font-semibold text-foreground mb-1">{data.date}</p>
      <p className="text-xs">
        Strike %: <span className="font-mono font-semibold" style={{ color: getStrikeColor(data.strikePct) }}>
          {data.strikePct}%
        </span>
      </p>
      <p className="text-xs text-muted-foreground">
        {data.strikes}/{data.pitches} pitches
      </p>
      <p className="text-[10px] mt-0.5" style={{ color: getStrikeColor(data.strikePct) }}>
        {getStrikeLabel(data.strikePct)}
      </p>
    </div>
  );
}

export default function CommandChart({ logs }: CommandChartProps) {
  const chartData = useMemo(() => {
    return logs
      .filter(l => l.strikes != null && l.pitch_count > 0)
      .slice(0, 10)
      .reverse()
      .map(l => ({
        date: l.date
          ? new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
          : '—',
        strikePct: Math.round((l.strikes! / l.pitch_count) * 100),
        strikes: l.strikes!,
        pitches: l.pitch_count,
      }));
  }, [logs]);

  if (chartData.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-center">
        <p className="text-sm text-muted-foreground">No strike data recorded yet.</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
        Command (Strike %)
      </h3>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={chartData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="hsl(220, 14%, 18%)"
            vertical={false}
          />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 10, fill: 'hsl(215, 12%, 55%)' }}
            axisLine={{ stroke: 'hsl(220, 14%, 18%)' }}
            tickLine={false}
          />
          <YAxis
            domain={[0, 100]}
            tick={{ fontSize: 10, fill: 'hsl(215, 12%, 55%)' }}
            axisLine={false}
            tickLine={false}
            width={35}
            tickFormatter={(v) => `${v}%`}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine
            y={65}
            stroke="hsl(145, 72%, 46%)"
            strokeDasharray="4 3"
            strokeWidth={1}
            label={{ value: '65%', position: 'right', fill: 'hsl(145, 72%, 46%)', fontSize: 9 }}
          />
          <ReferenceLine
            y={55}
            stroke="hsl(38, 92%, 55%)"
            strokeDasharray="4 3"
            strokeWidth={1}
            label={{ value: '55%', position: 'right', fill: 'hsl(38, 92%, 55%)', fontSize: 9 }}
          />
          <Bar dataKey="strikePct" radius={[4, 4, 0, 0]} maxBarSize={32}>
            {chartData.map((entry, index) => (
              <Cell key={index} fill={getStrikeColor(entry.strikePct)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="flex justify-center gap-4 mt-2">
        <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'hsl(145, 72%, 46%)' }} /> ≥65% Elite
        </span>
        <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'hsl(38, 92%, 55%)' }} /> 55-64% Avg
        </span>
        <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'hsl(0, 72%, 55%)' }} /> &lt;55%
        </span>
      </div>
    </div>
  );
}
