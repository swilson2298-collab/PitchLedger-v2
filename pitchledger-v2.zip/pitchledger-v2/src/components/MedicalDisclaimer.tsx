import { AlertTriangle } from "lucide-react";

export default function MedicalDisclaimer() {
  return (
    <div className="mt-6 mb-2 px-1">
      <div className="flex items-start gap-2 rounded-lg bg-muted/50 border border-border p-3">
        <AlertTriangle className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
        <p className="text-[10px] leading-relaxed text-muted-foreground">
          <span className="font-semibold">Disclaimer:</span> PitchLedger is a workload management tool, not a medical device. Always consult your athletic trainers and/or physician for pain or injury.
        </p>
      </div>
    </div>
  );
}
