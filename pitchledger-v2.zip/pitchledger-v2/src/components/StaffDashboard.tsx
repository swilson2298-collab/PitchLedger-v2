import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useConnections } from '@/hooks/useConnections';
import { LogOut, Users, Copy, RefreshCw, Link, Search, Send, UserPlus, ShieldAlert, ShieldCheck, ShieldOff, ArrowUpDown, ChevronRight } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import TrainerConnectDialog from '@/components/TrainerConnectDialog';
import UpgradeModal from '@/components/UpgradeModal';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { calculateAge } from '@/lib/age';
import {
  calculateAvailability,
  availabilitySortOrder,
  AvailabilityResult,
  AvailabilityStatus,
  PitchLogEntry,
} from '@/lib/pitchSmartEngine';
import { format } from 'date-fns';

interface PlayerAvailability extends AvailabilityResult {
  maxVelo: number | null;
  avgStrikePercent: number | null;
}

function StatusBadgeInline({ availability }: { availability: PlayerAvailability }) {
  const { status, eligibleDate, reason } = availability;

  if (status === 'SHUT_DOWN') {
    return (
      <div className="flex items-center gap-1.5">
        <Badge variant="destructive" className="text-[9px] px-1.5 py-0 animate-pulse gap-0.5 shrink-0">
          <ShieldOff className="w-2.5 h-2.5" />
          Shut Down
        </Badge>
        {eligibleDate && (
          <span className="text-[10px] text-destructive font-mono">
            → {format(eligibleDate, 'MMM d')}
          </span>
        )}
      </div>
    );
  }

  if (status === 'CAUTION') {
    return (
      <Badge className="text-[9px] px-1.5 py-0 gap-0.5 shrink-0 bg-[hsl(var(--status-yellow))]/15 text-[hsl(var(--status-yellow))] border-[hsl(var(--status-yellow))]/30 hover:bg-[hsl(var(--status-yellow))]/20">
        <ShieldAlert className="w-2.5 h-2.5" />
        Caution
      </Badge>
    );
  }

  return (
    <Badge className="text-[9px] px-1.5 py-0 gap-0.5 shrink-0 bg-[hsl(var(--status-green))]/15 text-[hsl(var(--status-green))] border-[hsl(var(--status-green))]/30 hover:bg-[hsl(var(--status-green))]/20">
      <ShieldCheck className="w-2.5 h-2.5" />
      Fresh
    </Badge>
  );
}

function AvailabilityDot({ status }: { status: AvailabilityStatus }) {
  const color = status === 'SHUT_DOWN'
    ? 'bg-[hsl(var(--status-red))]'
    : status === 'CAUTION'
      ? 'bg-[hsl(var(--status-yellow))]'
      : 'bg-[hsl(var(--status-green))]';
  const pulse = status === 'SHUT_DOWN';

  return (
    <span className="relative flex shrink-0">
      {pulse && (
        <span className={cn('absolute inline-flex h-full w-full rounded-full opacity-40 animate-ping', color)} />
      )}
      <span className={cn('relative inline-flex rounded-full w-3 h-3', color)} />
    </span>
  );
}

type AvailabilityFilter = AvailabilityStatus | 'all';
type SortOption = 'availability' | 'alpha' | 'age' | 'lastSession';

export default function StaffDashboard() {
  const navigate = useNavigate();
  const { user, profile, signOut, refreshProfile } = useAuth();
  const { roster, loading, generateTeamCode, sendTrainerRequest, removeConnection } = useConnections();
  const [showTrainerDialog, setShowTrainerDialog] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [statusFilter, setStatusFilter] = useState<AvailabilityFilter>('all');
  const [sortBy, setSortBy] = useState<SortOption>('availability');
  const [searchQuery, setSearchQuery] = useState('');
  const [teamCode, setTeamCode] = useState(profile?.team_code ?? '');
  const [playerAvailability, setPlayerAvailability] = useState<Record<string, PlayerAvailability>>({});
  const [playerAges, setPlayerAges] = useState<Record<string, number>>({});
  const [playerLastSession, setPlayerLastSession] = useState<Record<string, string | null>>({});
  const [showInvite, setShowInvite] = useState(false);

  useEffect(() => {
    setTeamCode(profile?.team_code ?? '');
  }, [profile?.team_code]);

  // Fetch pitch logs and compute availability for each player
  useEffect(() => {
    if (roster.length === 0) return;
    const playerIds = roster.map(p => p.id);

    const fetchStats = async () => {
      const { data: allLogs } = await supabase
        .from('pitch_logs')
        .select('player_id, velo, strikes, pitch_count, arm_feel, date')
        .in('player_id', playerIds)
        .order('date', { ascending: false });

      if (!allLogs) return;

      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, birthdate')
        .in('id', playerIds);

      const ageMap: Record<string, number> = {};
      for (const p of profiles ?? []) {
        ageMap[p.id] = p.birthdate ? calculateAge(p.birthdate) : 14;
      }
      setPlayerAges(ageMap);

      const avail: Record<string, PlayerAvailability> = {};
      const lastSessions: Record<string, string | null> = {};
      for (const pid of playerIds) {
        const logs = allLogs.filter(l => l.player_id === pid);
        const lastLog: PitchLogEntry | null = logs.length > 0 ? logs[0] : null;
        const age = ageMap[pid] ?? 14;
        const result = calculateAvailability(lastLog, age);

        const velos = logs.filter(l => l.velo != null).map(l => l.velo!);
        const strikeLogs = logs.filter(l => l.strikes != null && l.pitch_count > 0);

        avail[pid] = {
          ...result,
          maxVelo: velos.length > 0 ? Math.max(...velos) : null,
          avgStrikePercent: strikeLogs.length > 0
            ? Math.round(strikeLogs.reduce((s, l) => s + (l.strikes! / l.pitch_count) * 100, 0) / strikeLogs.length)
            : null,
        };
        lastSessions[pid] = lastLog?.date ?? null;
      }
      setPlayerAvailability(avail);
      setPlayerLastSession(lastSessions);
    };
    fetchStats();
  }, [roster]);

  const handleGenerateCode = async () => {
    await generateTeamCode();
    await refreshProfile();
  };

  const copyCode = () => {
    if (teamCode) {
      navigator.clipboard.writeText(teamCode);
      toast.success('Team code copied!');
    }
  };

  const copyInviteLink = () => {
    if (teamCode) {
      const link = `${window.location.origin}?code=${teamCode}`;
      navigator.clipboard.writeText(link);
      toast.success('Invite link copied!');
    }
  };

  const isCoach = profile?.role === 'coach';
  const isTrainer = profile?.role === 'trainer';

  // Filter + sort roster
  const filteredRoster = useMemo(() => {
    let result = roster;
    if (statusFilter !== 'all') {
      result = result.filter(p => (playerAvailability[p.id]?.status ?? 'FRESH') === statusFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p => p.full_name.toLowerCase().includes(q));
    }
    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'alpha': {
          const aLast = a.full_name.split(' ').slice(-1)[0] ?? '';
          const bLast = b.full_name.split(' ').slice(-1)[0] ?? '';
          return aLast.localeCompare(bLast);
        }
        case 'age':
          return (playerAges[a.id] ?? 99) - (playerAges[b.id] ?? 99);
        case 'lastSession': {
          const aDate = playerLastSession[a.id] ?? '';
          const bDate = playerLastSession[b.id] ?? '';
          return bDate.localeCompare(aDate); // most recent first
        }
        case 'availability':
        default:
          return availabilitySortOrder(playerAvailability[a.id]?.status ?? 'FRESH')
            - availabilitySortOrder(playerAvailability[b.id]?.status ?? 'FRESH');
      }
    });
    return result;
  }, [roster, statusFilter, searchQuery, playerAvailability, sortBy, playerAges, playerLastSession]);

  // ── Empty State ──
  if (!loading && roster.length === 0) {
    return (
      <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
        <header className="mb-8 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {profile?.full_name ?? 'Staff'} · {isCoach ? 'Coach' : 'Trainer'}
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={signOut}>
            <LogOut className="w-4 h-4" />
          </Button>
        </header>

        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-20 h-20 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center mb-6">
            <Users className="w-10 h-10 text-primary/60" />
          </div>
          <h2 className="text-xl font-bold mb-2">
            Welcome, {profile?.full_name?.split(' ')[0] ?? 'Coach'}!
          </h2>
          <p className="text-sm text-muted-foreground max-w-xs mb-6">
            {isCoach
              ? 'Share your team code with players so they can join your roster.'
              : 'Send a connection request to a player using their email.'}
          </p>

          {isCoach && (
            teamCode ? (
              <div className="w-full max-w-xs space-y-3">
                <div className="text-3xl font-mono font-bold tracking-[0.3em] text-primary text-center py-4 rounded-xl bg-primary/10 border-2 border-primary/20">
                  {teamCode}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 gap-2" onClick={copyCode}>
                    <Copy className="w-4 h-4" /> Copy Code
                  </Button>
                  <Button variant="outline" className="flex-1 gap-2" onClick={copyInviteLink}>
                    <Link className="w-4 h-4" /> Copy Link
                  </Button>
                </div>
                <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground" onClick={handleGenerateCode}>
                  <RefreshCw className="w-3.5 h-3.5" /> Regenerate Code
                </Button>
              </div>
            ) : (
              <Button onClick={handleGenerateCode} size="lg" className="gap-2">
                <Users className="w-5 h-5" />
                Generate Team Code
              </Button>
            )
          )}

          {isTrainer && (
            <Button onClick={() => setShowTrainerDialog(true)} size="lg" className="gap-2">
              <Send className="w-5 h-5" />
              Connect with Player
            </Button>
          )}
        </div>

        <TrainerConnectDialog
          open={showTrainerDialog}
          onOpenChange={setShowTrainerDialog}
          onSend={sendTrainerRequest}
        />
        <UpgradeModal open={showUpgrade} onOpenChange={setShowUpgrade} />
      </div>
    );
  }

  // Count by status
  const shutDownCount = roster.filter(p => playerAvailability[p.id]?.status === 'SHUT_DOWN').length;
  const cautionCount = roster.filter(p => playerAvailability[p.id]?.status === 'CAUTION').length;
  const freshCount = roster.filter(p => (playerAvailability[p.id]?.status ?? 'FRESH') === 'FRESH').length;

  // ── Main Dashboard ──
  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      {/* Header */}
      <header className="mb-4 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {profile?.full_name ?? 'Staff'} · {isCoach ? 'Coach' : 'Trainer'}
          </p>
        </div>
        <Button variant="ghost" size="icon" onClick={signOut}>
          <LogOut className="w-4 h-4" />
        </Button>
      </header>

      {/* Roster Heading + Invite */}
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Active Roster ({filteredRoster.length})
        </h2>
        <div className="flex items-center gap-1.5">
          {isCoach && (
            <Button variant="outline" size="sm" className="h-7 px-2.5 gap-1.5 text-xs" onClick={() => setShowInvite(true)}>
              <UserPlus className="w-3.5 h-3.5" /> Invite
            </Button>
          )}
          {isTrainer && (
            <Button variant="outline" size="sm" className="h-7 px-2.5 gap-1.5 text-xs" onClick={() => setShowTrainerDialog(true)}>
              <UserPlus className="w-3.5 h-3.5" /> Connect
            </Button>
          )}
        </div>
      </div>

      {/* Search + Sort */}
      <div className="mb-2 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search players..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-9 h-9 bg-secondary border-border text-sm"
          />
        </div>
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
          <SelectTrigger className="w-auto h-9 bg-secondary border-border text-xs gap-1 px-2.5 shrink-0">
            <ArrowUpDown className="w-3.5 h-3.5 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="availability">Availability</SelectItem>
            <SelectItem value="alpha">A–Z</SelectItem>
            <SelectItem value="age">Age</SelectItem>
            <SelectItem value="lastSession">Last Session</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Availability Filter Chips */}
      <div className="flex gap-1.5 mb-3 overflow-x-auto">
        {([
          { key: 'all' as const, label: 'All', count: roster.length },
          { key: 'FRESH' as const, label: 'Fresh', count: freshCount },
          { key: 'CAUTION' as const, label: 'Caution', count: cautionCount },
          { key: 'SHUT_DOWN' as const, label: 'Shut Down', count: shutDownCount },
        ]).map(({ key, label, count }) => (
          <button
            key={key}
            onClick={() => setStatusFilter(key)}
            className={cn(
              'px-2.5 py-1 rounded-full text-[11px] font-medium whitespace-nowrap transition-colors border',
              statusFilter === key
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-secondary text-muted-foreground border-border hover:border-primary/30'
            )}
          >
            {label} ({count})
          </button>
        ))}
      </div>

      {/* Roster Table */}
      {loading ? (
        <div className="flex justify-center py-12">
          <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      ) : filteredRoster.length > 0 ? (
        <div className="space-y-1.5">
          {filteredRoster.map((player) => {
            const avail = playerAvailability[player.id] ?? {
              status: 'FRESH' as AvailabilityStatus,
              eligibleDate: null,
              daysUntilEligible: 0,
              reason: '',
              restDays: 0,
              sorenessValue: 0,
              maxVelo: null,
              avgStrikePercent: null,
            };

            return (
              <div
                key={player.id}
                className={cn(
                  "flex items-center gap-3 p-3 rounded-lg border bg-card cursor-pointer hover:border-primary/30 active:bg-secondary/50 transition-colors touch-manipulation",
                  avail.status === 'SHUT_DOWN' && 'border-destructive/30 bg-destructive/5',
                  avail.status === 'CAUTION' && 'border-[hsl(var(--status-yellow))]/30',
                )}
                onClick={() => navigate(`/player/${player.id}`)}
              >
                <AvailabilityDot status={avail.status} />
                <img
                  src={`${import.meta.env.VITE_SUPABASE_URL ?? ''}/storage/v1/object/public/avatars/${player.id}/avatar.jpg`}
                  alt=""
                  className="w-8 h-8 rounded-full object-cover bg-secondary shrink-0"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />

                <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold truncate">{player.full_name}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <StatusBadgeInline availability={avail} />
                      {avail.status === 'SHUT_DOWN' && avail.daysUntilEligible > 0 ? (
                        <span className="text-[11px] text-muted-foreground">
                          Eligible in {avail.daysUntilEligible}d
                        </span>
                      ) : avail.status === 'CAUTION' ? (
                        <span className="text-[11px] text-muted-foreground">
                          {avail.reason}
                        </span>
                      ) : (
                        <span className="text-[11px] text-[hsl(var(--status-green))]">
                          Available Now
                        </span>
                      )}
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground text-center py-12">No players match your filters.</p>
      )}


      {/* Invite Modal */}
      {showInvite && isCoach && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm" onClick={() => setShowInvite(false)}>
          <div className="bg-card border border-border rounded-xl p-6 max-w-sm w-full mx-4 space-y-4" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold">Invite Players</h3>
            <p className="text-sm text-muted-foreground">Share your team code with players so they can join.</p>
            {teamCode ? (
              <>
                <div className="text-2xl font-mono font-bold tracking-[0.3em] text-primary text-center py-3 rounded-xl bg-primary/10 border border-primary/20">
                  {teamCode}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 gap-2" onClick={copyCode}>
                    <Copy className="w-4 h-4" /> Code
                  </Button>
                  <Button variant="outline" className="flex-1 gap-2" onClick={copyInviteLink}>
                    <Link className="w-4 h-4" /> Link
                  </Button>
                </div>
              </>
            ) : (
              <Button onClick={handleGenerateCode} className="w-full gap-2">
                <Users className="w-4 h-4" /> Generate Team Code
              </Button>
            )}
            <Button variant="ghost" className="w-full" onClick={() => setShowInvite(false)}>Done</Button>
          </div>
        </div>
      )}

      
      <TrainerConnectDialog
        open={showTrainerDialog}
        onOpenChange={setShowTrainerDialog}
        onSend={sendTrainerRequest}
      />
      <UpgradeModal open={showUpgrade} onOpenChange={setShowUpgrade} />
    </div>
  );
}
