import { cn } from '@/lib/utils';
import { getStatusColor } from '@/lib/pitchLogic';

interface StatusBadgeProps {
  restDays: number;
  className?: string;
}

export default function StatusBadge({ restDays, className }: StatusBadgeProps) {
  const status = getStatusColor(restDays);

  return (
    <div className={cn(
      "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold",
      status === 'green' && "bg-status-green/15 text-status-green",
      status === 'yellow' && "bg-status-yellow/15 text-status-yellow",
      status === 'red' && "bg-status-red/15 text-status-red",
      className
    )}>
      <span className={cn(
        "w-2 h-2 rounded-full",
        status === 'green' && "bg-status-green animate-pulse-glow",
        status === 'yellow' && "bg-status-yellow animate-pulse-glow",
        status === 'red' && "bg-status-red animate-pulse-glow",
      )} />
      {restDays === 0 ? 'Ready' : `${restDays}D Rest`}
    </div>
  );
}
