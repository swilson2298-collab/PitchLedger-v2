import { useNavigate } from "react-router-dom";
import MedicalDisclaimer from "@/components/MedicalDisclaimer";
import { motion } from "framer-motion";
import { Zap, Users, Mail, LogOut, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { usePlayerStatus } from "@/hooks/usePlayerStatus";
import { supabase } from "@/integrations/supabase/client";
import PlayerConnectionBar from "@/components/PlayerConnectionBar";
import { useState, useEffect } from "react";

interface CoachInfo {
  name: string;
  email: string | null;
}

export default function AthleteDashboard() {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const status = usePlayerStatus(user?.id, profile?.birthdate);
  const { availability, loading } = status;
  const [coach, setCoach] = useState<CoachInfo | null>(null);

  useEffect(() => {
    if (!user) return;
    const fetchCoach = async () => {
      const { data: connections } = await supabase
        .from("connections")
        .select("connected_user_id")
        .eq("player_id", user.id)
        .eq("connection_type", "team")
        .eq("status", "active")
        .limit(1);

      if (connections && connections.length > 0) {
        const coachId = connections[0].connected_user_id;
        if (coachId) {
          const { data: coachProfile } = await supabase.from("profiles").select("full_name").eq("id", coachId).single();
          setCoach({ name: coachProfile?.full_name ?? "Coach", email: null });
        }
      }
    };
    fetchCoach();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const isShutDown = availability.status === "SHUT_DOWN";
  const isCaution = availability.status === "CAUTION";

  return (
    <div className="min-h-screen pb-20 px-4 pt-6 max-w-lg mx-auto">
      <header className="mb-5 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Command Center</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{profile?.full_name ?? "Player"}</p>
        </div>
        <Button variant="ghost" size="icon" onClick={signOut}>
          <LogOut className="w-4 h-4" />
        </Button>
      </header>

      {/* Hero Recovery Status */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <Card
          className={`mb-5 ${
            isShutDown
              ? "border-destructive/40 bg-gradient-to-br from-card to-destructive/10"
              : isCaution
                ? "border-[hsl(var(--status-yellow))]/40 bg-gradient-to-br from-card to-[hsl(var(--status-yellow))]/10"
                : "border-[hsl(var(--status-green))]/40 bg-gradient-to-br from-card to-[hsl(var(--status-green))]/10"
          }`}
        >
          <CardContent className="p-6 text-center">
            <div className="text-4xl mb-3">{isShutDown ? "🛑" : isCaution ? "⚠️" : "✅"}</div>
            <h2
              className={`text-xl font-bold mb-1 ${
                isShutDown
                  ? "text-destructive"
                  : isCaution
                    ? "text-[hsl(var(--status-yellow))]"
                    : "text-[hsl(var(--status-green))]"
              }`}
            >
              {isShutDown ? "Required Rest" : isCaution ? "Limited" : "Ready to Throw"}
            </h2>
            <p className="text-sm text-muted-foreground">
              {isShutDown && availability.daysUntilEligible > 0
                ? `Eligible in: ${availability.daysUntilEligible} Day${availability.daysUntilEligible !== 1 ? "s" : ""}`
                : isShutDown
                  ? availability.reason
                  : isCaution
                    ? "Recovery in progress. Monitor arm soreness."
                    : "Arm feeling good. No PitchSmart restrictions."}
            </p>
            {isShutDown && availability.daysUntilEligible > 0 && (
              <div className="mt-4 flex items-center justify-center gap-2">
                <div className="text-5xl font-mono font-bold text-destructive tabular-nums">
                  {availability.daysUntilEligible}
                </div>
                <span className="text-sm text-muted-foreground">
                  days
                  <br />
                  remaining
                </span>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Primary Action — Log New Session */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="mb-5"
      >
        <Button
          onClick={() => navigate("/log")}
          className="w-full h-16 text-lg font-semibold gap-3 rounded-xl"
          size="lg"
        >
          <Zap className="w-6 h-6" />
          Log New Session
        </Button>
        {isShutDown && (
          <div className="flex items-center justify-center gap-1.5 mt-2 text-destructive">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span className="text-xs font-medium">You are currently in a PitchSmart rest window.</span>
          </div>
        )}
      </motion.div>

      {/* My Coach Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.15 }}
        className="mb-5"
      >
        {coach ? (
          <Card className="border-border">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">My Coach</p>
                  <p className="text-xs text-muted-foreground">{coach.name}</p>
                </div>
              </div>
              {coach.email && (
                <Button variant="outline" size="sm" className="gap-1.5" asChild>
                  <a href={`mailto:${coach.email}`}>
                    <Mail className="w-3.5 h-3.5" />
                    Message
                  </a>
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card className="border-border border-dashed">
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground mb-2">Not connected to a team yet</p>
            </CardContent>
          </Card>
        )}
      </motion.div>

      {/* Connection Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
      >
        <PlayerConnectionBar />
      </motion.div>

      <MedicalDisclaimer />
    </div>
  );
}
