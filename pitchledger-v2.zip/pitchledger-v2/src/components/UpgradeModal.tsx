import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Sparkles } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { TIERS, TierKey, getTierForRole } from '@/lib/tiers';
import { toast } from 'sonner';

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function UpgradeModal({ open, onOpenChange }: UpgradeModalProps) {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);

  const tier = getTierForRole(profile?.role ?? null) ?? 'premium_player';
  const tierInfo = TIERS[tier];

  const handleUpgrade = async () => {
    setLoading(true);
    const { data, error } = await supabase.functions.invoke('create-checkout', {
      body: { tier },
    });
    if (error || !data?.url) {
      toast.error('Failed to start checkout');
      setLoading(false);
      return;
    }
    window.open(data.url, '_blank');
    setLoading(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <div className="flex justify-center mb-2">
            <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-accent" />
            </div>
          </div>
          <DialogTitle className="text-center">Level Up to {tierInfo.label}</DialogTitle>
          <DialogDescription className="text-center">
            Unlock the full PitchLedger experience for just <strong>{tierInfo.price}</strong>.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3 mt-2">
          <div className="rounded-lg border border-accent/30 bg-accent/5 p-3 space-y-1">
            <p className="text-sm font-medium text-accent">{tierInfo.label} includes:</p>
            <ul className="text-xs text-muted-foreground space-y-0.5">
              {tierInfo.features.map((f) => (
                <li key={f}>✓ {f}</li>
              ))}
            </ul>
          </div>
          <Button
            className="w-full gap-2"
            onClick={handleUpgrade}
            disabled={loading}
          >
            {loading ? (
              <>
                <span className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full" />
                Redirecting to Stripe…
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                {`Upgrade — ${tierInfo.price}`}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
