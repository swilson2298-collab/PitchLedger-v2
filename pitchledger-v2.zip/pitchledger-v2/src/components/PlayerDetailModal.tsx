import { useState, useEffect } from 'react';
import { format, parseISO } from 'date-fns';
import { Gauge, TrendingUp, TrendingDown, Minus, Lock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import VeloChart from '@/components/VeloChart';
import CommandChart from '@/components/CommandChart';
import type { PlayerPitchLog } from '@/hooks/useConnections';

interface PlayerDetailModalProps {
  playerId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function PlayerDetailModal({ playerId, open, onOpenChange }: PlayerDetailModalProps) {
  const { user } = useAuth();
  const [playerProfile, setPlayerProfile] = useState<{
    full_name: string;
    share_health_data: boolean;
    birthdate: string | null;
  } | null>(null);
  const [logs, setLogs] = useState<PlayerPitchLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [maxVelo, setMaxVelo] = useState<number | null>(null);
  const [veloTrend, setVeloTrend] = useState<'up' | 'down' | 'flat'>('flat');

  useEffect(() => {
    if (!playerId || !open) return;

    const fetchData = async () => {
      setLoading(true);
      const [{ data: prof }, { data: pitchLogs }] = await Promise.all([
        supabase
          .from('profiles')
          .select('full_name, share_health_data, birthdate')
          .eq('id', playerId)
          .single(),
        supabase
          .from('pitch_logs')
          .select('id, date, pitch_count, innings, session_type, velo, notes, arm_feel, strikes')
          .eq('player_id', playerId)
          .order('date', { ascending: false })
          .limit(50),
      ]);

      setPlayerProfile(prof as any);
      const typedLogs = (pitchLogs as PlayerPitchLog[]) ?? [];
      setLogs(typedLogs);

      // Compute max velo + trend
      const velos = typedLogs.filter(l => l.velo != null).map(l => l.velo!);
      if (velos.length > 0) {
        setMaxVelo(Math.max(...velos));
        const recent = velos.slice(0, 5);
        const older = velos.slice(5, 10);
        if (older.length > 0) {
          const rAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
          const oAvg = older.reduce((a, b) => a + b, 0) / older.length;
          setVeloTrend(rAvg > oAvg + 0.5 ? 'up' : rAvg < oAvg - 0.5 ? 'down' : 'flat');
        }
      } else {
        setMaxVelo(null);
        setVeloTrend('flat');
      }

      setLoading(false);
    };
    fetchData();
  }, [playerId, open]);

  const canSeeHealth = playerProfile?.share_health_data === true;
  const TrendIcon = veloTrend === 'up' ? TrendingUp : veloTrend === 'down' ? TrendingDown : Minus;
  const trendColor = veloTrend === 'up'
    ? 'text-[hsl(var(--status-green))]'
    : veloTrend === 'down'
      ? 'text-destructive'
      : 'text-muted-foreground';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto p-0">
        <DialogHeader className="p-5 pb-0">
          <DialogTitle className="text-lg font-bold">
            {playerProfile?.full_name ?? 'Player'} — Athlete View
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-12">
            <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
          </div>
        ) : (
          <div className="p-5 pt-3 space-y-4">
            {/* Hero — Max Velo */}
            <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
              <CardContent className="p-5 text-center">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">
                  All-Time Max Velo
                </p>
                <div className="flex items-center justify-center gap-3">
                  <Gauge className="w-6 h-6 text-primary/60" />
                  <span className="text-4xl font-mono font-bold tabular-nums">
                    {maxVelo ?? '—'}
                  </span>
                  <span className="text-sm text-muted-foreground">mph</span>
                </div>
                <div className={`flex items-center justify-center gap-1.5 mt-2 ${trendColor}`}>
                  <TrendIcon className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-medium uppercase tracking-wider">
                    {veloTrend === 'up' ? 'Trending Up' : veloTrend === 'down' ? 'Trending Down' : 'Steady'}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Charts */}
            <VeloChart logs={logs} />
            <CommandChart logs={logs} />

            {/* Recent Sessions */}
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Recent Sessions
            </h3>
            {logs.slice(0, 8).map((log) => (
              <div
                key={log.id}
                className="rounded-lg border border-border bg-card p-3 flex items-center gap-3"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-semibold">
                      {log.date ? format(parseISO(log.date), 'MMM d') : '—'}
                    </span>
                    <span className="text-xs text-muted-foreground uppercase">
                      {log.session_type ?? 'Session'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                    <span className="font-mono font-semibold text-foreground">{log.pitch_count}p</span>
                    {log.velo != null && <span className="font-mono">{log.velo} mph</span>}
                    {canSeeHealth && log.arm_feel && (
                      <span className={
                        log.arm_feel.toLowerCase() === 'sore' || log.arm_feel.toLowerCase() === 'pain'
                          ? 'text-destructive' : ''
                      }>
                        {log.arm_feel}
                      </span>
                    )}
                    {!canSeeHealth && (
                      <span className="inline-flex items-center gap-0.5 text-muted-foreground/50">
                        <Lock className="w-3 h-3" /> Private
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {logs.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">No sessions logged yet.</p>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
