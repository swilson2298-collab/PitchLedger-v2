import type { TrafficLight } from '@/hooks/useConnections';
import TrafficLightDot from '@/components/TrafficLightDot';

interface HealthFilterProps {
  active: TrafficLight | 'all';
  onChange: (value: TrafficLight | 'all') => void;
}

const options: { value: TrafficLight | 'all'; label: string }[] = [
  { value: 'all', label: 'Show All' },
  { value: 'red', label: 'Sore' },
  { value: 'green', label: 'Ready' },
];

export default function HealthFilter({ active, onChange }: HealthFilterProps) {
  return (
    <div className="flex items-center gap-1 p-1 bg-secondary/60 rounded-lg">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
            active === opt.value
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          {opt.value !== 'all' && <TrafficLightDot status={opt.value} size="sm" />}
          {opt.label}
        </button>
      ))}
    </div>
  );
}
