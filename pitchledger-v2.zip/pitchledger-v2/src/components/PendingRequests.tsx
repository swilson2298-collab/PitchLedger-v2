import { Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PendingConnection } from '@/hooks/useConnections';

interface PendingRequestsProps {
  requests: PendingConnection[];
  onAccept: (id: string) => Promise<{ success: boolean; limitReached?: boolean }>;
  onReject: (id: string) => void;
  onLimitReached: () => void;
}

export default function PendingRequests({ requests, onAccept, onReject, onLimitReached }: PendingRequestsProps) {
  if (requests.length === 0) return null;

  const handleAccept = async (id: string) => {
    const result = await onAccept(id);
    if (result.limitReached) {
      onLimitReached();
    }
  };

  return (
    <div className="space-y-2">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        Pending Requests
      </h3>
      {requests.map((req) => (
        <div
          key={req.id}
          className="flex items-center justify-between p-3 rounded-lg border border-accent/30 bg-accent/5"
        >
          <div>
            <p className="text-sm font-medium">{req.connectedUserName}</p>
            <p className="text-xs text-muted-foreground capitalize">{req.connection_type} request</p>
          </div>
          <div className="flex gap-1">
            <Button size="icon" variant="ghost" className="h-8 w-8 text-primary" onClick={() => handleAccept(req.id)}>
              <Check className="w-4 h-4" />
            </Button>
            <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => onReject(req.id)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
