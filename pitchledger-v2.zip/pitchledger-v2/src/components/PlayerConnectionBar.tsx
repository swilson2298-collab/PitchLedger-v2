import { useState } from 'react';
import { Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import JoinTeamDialog from '@/components/JoinTeamDialog';
import PendingRequests from '@/components/PendingRequests';
import UpgradeModal from '@/components/UpgradeModal';
import { useConnections } from '@/hooks/useConnections';

export default function PlayerConnectionBar() {
  const { pendingRequests, joinTeam, acceptConnection, rejectConnection } = useConnections();
  const [showJoinTeam, setShowJoinTeam] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);

  return (
    <>
      {/* Pending requests */}
      <PendingRequests
        requests={pendingRequests}
        onAccept={acceptConnection}
        onReject={rejectConnection}
        onLimitReached={() => setShowUpgrade(true)}
      />

      {/* Join Team button */}
      <Button
        variant="outline"
        className="w-full gap-2 border-primary/30 text-primary hover:bg-primary/10"
        onClick={() => setShowJoinTeam(true)}
      >
        <Users className="w-4 h-4" />
        Join a Team
      </Button>

      <JoinTeamDialog
        open={showJoinTeam}
        onOpenChange={setShowJoinTeam}
        onJoin={joinTeam}
        onLimitReached={() => setShowUpgrade(true)}
      />

      <UpgradeModal open={showUpgrade} onOpenChange={setShowUpgrade} />
    </>
  );
}
