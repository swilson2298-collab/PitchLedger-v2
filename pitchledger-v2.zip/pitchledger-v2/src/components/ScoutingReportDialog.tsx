import { useState } from 'react';
import { FileText } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface ScoutingReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onGenerate: (coachNote: string) => void;
  playerName: string;
  generating: boolean;
  isPlayer?: boolean;
}

export default function ScoutingReportDialog({
  open,
  onOpenChange,
  onGenerate,
  playerName,
  generating,
  isPlayer = false,
}: ScoutingReportDialogProps) {
  const [note, setNote] = useState('');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Scouting Report
          </DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          Generate a professional 1-page PDF report for <strong>{playerName}</strong>.
        </p>
        {!isPlayer && (
          <div>
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
              Coach's Evaluation
            </label>
            <Textarea
              placeholder="Mechanics, potential, areas for improvement..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              className="bg-secondary border-border resize-none"
            />
          </div>
        )}
        <Button
          onClick={() => onGenerate(note)}
          disabled={generating}
          className="w-full gap-2"
        >
          {generating ? (
            <span className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full" />
          ) : (
            <FileText className="w-4 h-4" />
          )}
          Download PDF
        </Button>
      </DialogContent>
    </Dialog>
  );
}
