import { motion } from 'framer-motion';

interface RecoveryGaugeProps {
  percent: number;
  daysLeft: number;
  hoursLeft: number;
  minutesLeft: number;
}

export default function RecoveryGauge({ percent, daysLeft, hoursLeft, minutesLeft }: RecoveryGaugeProps) {
  const size = 180;
  const strokeWidth = 14;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - percent / 100);

  const isRecovered = percent >= 100;
  const color = isRecovered
    ? 'hsl(var(--status-green))'
    : percent >= 50
      ? 'hsl(var(--status-yellow))'
      : 'hsl(var(--destructive))';

  const displayHours = hoursLeft % 24;

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="absolute inset-0 -rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="hsl(var(--secondary))"
            strokeWidth={strokeWidth}
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1, ease: 'easeOut' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {isRecovered ? (
            <>
              <span className="text-4xl">✅</span>
              <span className="text-xs font-bold text-[hsl(var(--status-green))] mt-1">Ready to Throw</span>
            </>
          ) : (
            <>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium mb-1">Eligible in</span>
              <span className="text-2xl font-mono font-bold tabular-nums" style={{ color }}>
                {daysLeft}d {displayHours}h {minutesLeft}m
              </span>
              <span className="text-[10px] text-muted-foreground mt-0.5">
                {Math.round(percent)}% recovered
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
