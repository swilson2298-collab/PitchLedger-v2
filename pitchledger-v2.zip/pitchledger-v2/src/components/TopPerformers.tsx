import { TrendingUp } from 'lucide-react';
import type { RosterPlayer } from '@/hooks/useConnections';

interface TopPerformersProps {
  roster: RosterPlayer[];
}

export default function TopPerformers({ roster }: TopPerformersProps) {
  // Get top 3 players by velocity (those with recorded velo)
  const topByVelo = [...roster]
    .filter(p => p.lastBullpenVelo != null)
    .sort((a, b) => (b.lastBullpenVelo ?? 0) - (a.lastBullpenVelo ?? 0))
    .slice(0, 3);

  if (topByVelo.length === 0) return null;

  const medals = ['🥇', '🥈', '🥉'];

  return (
    <div className="mb-6 p-4 rounded-xl border border-border bg-card">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
        <TrendingUp className="w-3.5 h-3.5" />
        Top Performers — Velocity
      </h3>
      <div className="space-y-2">
        {topByVelo.map((player, i) => (
          <div
            key={player.id}
            className="flex items-center gap-3 p-2 rounded-lg bg-secondary/50"
          >
            <span className="text-lg">{medals[i]}</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{player.full_name}</p>
            </div>
            <span className="text-sm font-mono font-bold text-primary">
              {player.lastBullpenVelo} mph
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
