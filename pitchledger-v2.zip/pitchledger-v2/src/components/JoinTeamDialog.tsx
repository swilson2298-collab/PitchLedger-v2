import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users } from 'lucide-react';

interface JoinTeamDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onJoin: (code: string) => Promise<{ success: boolean; limitReached?: boolean }>;
  onLimitReached: () => void;
}

export default function JoinTeamDialog({ open, onOpenChange, onJoin, onLimitReached }: JoinTeamDialogProps) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleJoin = async () => {
    if (!code.trim()) return;
    setLoading(true);
    const result = await onJoin(code.trim());
    setLoading(false);
    if (result.limitReached) {
      onOpenChange(false);
      onLimitReached();
    } else if (result.success) {
      setCode('');
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Join a Team
          </DialogTitle>
          <DialogDescription>
            Enter the 6-character team code from your coach.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <Input
            placeholder="e.g. BASE42"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 6))}
            className="text-center text-lg font-mono tracking-widest bg-secondary border-border uppercase"
            maxLength={6}
          />
          <Button
            onClick={handleJoin}
            disabled={code.length < 4 || loading}
            className="w-full"
          >
            {loading ? 'Joining...' : 'Join Team'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
