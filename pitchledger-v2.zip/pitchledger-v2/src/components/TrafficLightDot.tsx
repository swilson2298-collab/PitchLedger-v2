import { cn } from '@/lib/utils';
import type { TrafficLight } from '@/hooks/useConnections';

interface TrafficLightDotProps {
  status: TrafficLight;
  size?: 'sm' | 'md';
  showLabel?: boolean;
}

const config: Record<TrafficLight, { color: string; label: string; pulse: boolean }> = {
  green: { color: 'bg-[hsl(var(--status-green))]', label: 'Go', pulse: false },
  yellow: { color: 'bg-[hsl(var(--status-yellow))]', label: 'Caution', pulse: false },
  red: { color: 'bg-[hsl(var(--status-red))]', label: 'Rest', pulse: true },
};

export default function TrafficLightDot({ status, size = 'sm', showLabel = false }: TrafficLightDotProps) {
  const { color, label, pulse } = config[status];
  const dotSize = size === 'sm' ? 'w-2.5 h-2.5' : 'w-4 h-4';

  return (
    <div className="flex items-center gap-1.5">
      <span className="relative flex">
        {pulse && (
          <span className={cn('absolute inline-flex h-full w-full rounded-full opacity-40 animate-ping', color)} />
        )}
        <span className={cn('relative inline-flex rounded-full', dotSize, color)} />
      </span>
      {showLabel && (
        <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
      )}
    </div>
  );
}
