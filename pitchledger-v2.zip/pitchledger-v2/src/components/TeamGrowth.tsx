import { TrendingUp, ArrowUp } from 'lucide-react';
import type { RosterPlayer } from '@/hooks/useConnections';

interface TeamGrowthProps {
  roster: RosterPlayer[];
}

export default function TeamGrowth({ roster }: TeamGrowthProps) {
  const playersWithVelo = roster.filter(p => p.lastBullpenVelo != null);
  
  if (playersWithVelo.length === 0) return null;

  const avgVelo = Math.round(
    playersWithVelo.reduce((s, p) => s + (p.lastBullpenVelo ?? 0), 0) / playersWithVelo.length
  );

  return (
    <div className="mb-6 p-4 rounded-xl border border-border bg-card">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
        <TrendingUp className="w-3.5 h-3.5" />
        Team Growth
      </h3>
      <div className="flex items-end gap-3">
        <div>
          <p className="text-3xl font-mono font-bold text-primary">{avgVelo}</p>
          <p className="text-xs text-muted-foreground">avg team velo (mph)</p>
        </div>
        <div className="flex-1 text-right">
          <p className="text-xs text-muted-foreground">
            {playersWithVelo.length} player{playersWithVelo.length !== 1 ? 's' : ''} tracked
          </p>
        </div>
      </div>
    </div>
  );
}
