import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SafetyWarningProps {
  open: boolean;
  playerName: string;
  recentPitches: number;
  onAcknowledge: () => void;
  onCancel: () => void;
}

export default function SafetyWarning({ open, playerName, recentPitches, onAcknowledge, onCancel }: SafetyWarningProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-md p-6"
        >
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.85, opacity: 0 }}
            transition={{ type: 'spring', damping: 20 }}
            className="max-w-sm w-full text-center space-y-6"
          >
            {/* Pulsing Icon */}
            <div className="flex justify-center">
              <div className="relative">
                <span className="absolute inset-0 rounded-full bg-destructive/20 animate-ping" />
                <div className="relative w-20 h-20 rounded-full bg-destructive/15 border-2 border-destructive/40 flex items-center justify-center">
                  <ShieldAlert className="w-10 h-10 text-destructive" />
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-destructive mb-2">Safety Warning</h2>
              <p className="text-foreground font-semibold text-lg">{playerName}</p>
            </div>

            <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 space-y-2">
              <div className="flex items-center justify-center gap-2 text-destructive">
                <AlertTriangle className="w-5 h-5" />
                <span className="font-semibold uppercase text-sm tracking-wider">Red Status Active</span>
              </div>
              <p className="text-sm text-muted-foreground">
                This player has thrown <span className="font-bold text-foreground">{recentPitches} pitches</span> in the last 48 hours or has reported arm soreness. Logging additional pitches increases injury risk.
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <Button
                variant="destructive"
                className="w-full h-14 text-base font-semibold gap-2"
                onClick={onAcknowledge}
              >
                <AlertTriangle className="w-5 h-5" />
                Acknowledge Risk & Continue
              </Button>
              <Button
                variant="outline"
                className="w-full h-12"
                onClick={onCancel}
              >
                Cancel — Return to Roster
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
