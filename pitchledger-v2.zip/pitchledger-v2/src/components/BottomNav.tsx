import { useLocation, useNavigate } from "react-router-dom";
import { PlusCircle, Shield, Activity, Settings, Users, Heart, Home } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const role = profile?.role;

  const tabs = (() => {
    switch (role) {
      case "coach":
        return [
          { path: "/",           icon: Users,      label: "Roster" },
          { path: "/performance", icon: Activity,  label: "Analytics" },
          { path: "/safety",     icon: Shield,     label: "Safety" },
          { path: "/settings",   icon: Settings,   label: "Settings" },
        ];
      case "trainer":
        return [
          { path: "/",           icon: Users,      label: "Players" },
          { path: "/performance", icon: Activity,  label: "Analytics" },
          { path: "/settings",   icon: Settings,   label: "Settings" },
        ];
      case "parent":
        return [
          { path: "/",           icon: Home,       label: "Home" },
          { path: "/performance", icon: Activity,  label: "History" },
          { path: "/settings",   icon: Settings,   label: "Settings" },
        ];
      default: // player
        return [
          { path: "/",           icon: Heart,      label: "Home" },
          { path: "/log",        icon: PlusCircle, label: "Log" },
          { path: "/recovery",   icon: Shield,     label: "Recovery" },
          { path: "/performance", icon: Activity,  label: "Stats" },
          { path: "/settings",   icon: Settings,   label: "Settings" },
        ];
    }
  })();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-lg border-t border-border">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-2">
        {tabs.map(tab => {
          const isActive = location.pathname === tab.path;
          return (
            <button key={tab.path} onClick={() => navigate(tab.path)}
              className={cn("flex flex-col items-center justify-center gap-0.5 w-16 h-full transition-colors",
                isActive ? "text-primary" : "text-muted-foreground")}>
              <tab.icon className={cn("w-5 h-5", isActive && "drop-shadow-[0_0_6px_hsl(var(--primary)/0.5)]")} />
              <span className="text-[10px] font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
