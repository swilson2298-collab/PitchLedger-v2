import { Lock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ProFeatureGateProps {
  label: string;
  icon: React.ReactNode;
  locked: boolean;
  onUpgrade: () => void;
  onClick?: () => void;
  className?: string;
}

export default function ProFeatureGate({ label, icon, locked, onUpgrade, onClick, className }: ProFeatureGateProps) {
  if (!locked) {
    return (
      <Button variant="outline" className={cn('w-full gap-2', className)} onClick={onClick}>
        {icon}
        {label}
      </Button>
    );
  }

  return (
    <div className={cn('relative', className)}>
      <Button
        variant="outline"
        className="w-full gap-2 opacity-40 blur-[1px] pointer-events-none"
        disabled
      >
        {icon}
        {label}
      </Button>
      <button
        onClick={onUpgrade}
        className="absolute inset-0 flex items-center justify-center gap-2 bg-card/80 backdrop-blur-sm rounded-md border border-accent/30 text-accent text-sm font-medium hover:bg-card/90 transition-colors"
      >
        <Lock className="w-3.5 h-3.5" />
        Upgrade to Pro
        <Sparkles className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
