import { cn } from '@/lib/utils';
import { SessionType } from '@/lib/pitchLogic';

interface SessionTypeBadgeProps {
  type: SessionType;
  className?: string;
}

const sessionStyles: Record<SessionType, string> = {
  Game: 'bg-session-game/20 text-session-game',
  Bullpen: 'bg-session-bullpen/20 text-session-bullpen',
  Practice: 'bg-session-practice/20 text-session-practice',
  Lesson: 'bg-session-lesson/20 text-session-lesson',
  Other: 'bg-muted text-muted-foreground',
};

export default function SessionTypeBadge({ type, className }: SessionTypeBadgeProps) {
  return (
    <span className={cn(
      "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider",
      sessionStyles[type],
      className
    )}>
      {type}
    </span>
  );
}
