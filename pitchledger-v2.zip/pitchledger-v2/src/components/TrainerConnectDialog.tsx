import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send } from 'lucide-react';

interface TrainerConnectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSend: (email: string) => Promise<{ success: boolean; limitReached?: boolean }>;
}

export default function TrainerConnectDialog({ open, onOpenChange, onSend }: TrainerConnectDialogProps) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!email.trim()) return;
    setLoading(true);
    const result = await onSend(email.trim());
    setLoading(false);
    if (result.success) {
      setEmail('');
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-5 h-5 text-primary" />
            Connect with Player
          </DialogTitle>
          <DialogDescription>
            Enter the player's email address to send a connection request.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <Input
            type="email"
            placeholder="player@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-secondary border-border"
          />
          <Button
            onClick={handleSend}
            disabled={!email.includes('@') || loading}
            className="w-full"
          >
            {loading ? 'Sending...' : 'Send Request'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
