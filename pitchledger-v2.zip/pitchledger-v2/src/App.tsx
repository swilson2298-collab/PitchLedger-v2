import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import BottomNav from "@/components/BottomNav";
import AuthPage from "@/pages/AuthPage";

// Player
import AthleteDashboard from "@/components/AthleteDashboard";
import InputScreen from "@/pages/InputScreen";
import RecoveryScreen from "@/pages/RecoveryScreen";

// Coach
import StaffDashboard from "@/components/StaffDashboard";

// Trainer
import TrainerDashboard from "@/pages/TrainerDashboard";

// Parent
import ParentDashboard from "@/pages/ParentDashboard";

// Shared
import PerformanceScreen from "@/pages/PerformanceScreen";
import SafetyScreen from "@/pages/SafetyScreen";
import SettingsScreen from "@/pages/SettingsScreen";
import PlayerDetailView from "@/pages/PlayerDetailView";
import LiveGameMode from "@/pages/LiveGameMode";
import BillingPage from "@/pages/BillingPage";
import SuccessPage from "@/pages/SuccessPage";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

function DashboardPage() {
  const { profile } = useAuth();
  switch (profile?.role) {
    case "coach":    return <StaffDashboard />;
    case "trainer":  return <TrainerDashboard />;
    case "parent":   return <ParentDashboard />;
    default:         return <AthleteDashboard />;
  }
}

function AppRoutes() {
  const { session, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!session) {
    return (
      <Routes>
        <Route path="*" element={<AuthPage />} />
      </Routes>
    );
  }

  const isPlayer  = profile?.role === "player";
  const isCoach   = profile?.role === "coach";
  const isParent  = profile?.role === "parent";
  const isTrainer = profile?.role === "trainer";
  const isStaff   = isCoach || isTrainer;

  return (
    <>
      <Routes>
        {/* Dashboard — role-aware */}
        <Route path="/" element={<DashboardPage />} />

        {/* Player-only routes */}
        {(isPlayer || isParent) && (
          <>
            <Route path="/log"      element={isPlayer ? <InputScreen /> : <NotFound />} />
            <Route path="/recovery" element={isPlayer ? <RecoveryScreen /> : <NotFound />} />
          </>
        )}

        {/* Staff-only routes */}
        {isStaff && (
          <>
            <Route path="/safety"          element={<SafetyScreen />} />
            <Route path="/player/:playerId" element={<PlayerDetailView />} />
            <Route path="/live/:playerId"   element={<LiveGameMode />} />
          </>
        )}

        {/* Parent can view child detail */}
        {isParent && (
          <Route path="/player/:playerId" element={<PlayerDetailView />} />
        )}

        {/* Shared routes */}
        <Route path="/performance" element={<PerformanceScreen />} />
        <Route path="/settings"    element={<SettingsScreen />} />
        <Route path="/billing"     element={<BillingPage />} />
        <Route path="/success"     element={<SuccessPage />} />
        <Route path="*"            element={<NotFound />} />
      </Routes>
      <BottomNav />
    </>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
