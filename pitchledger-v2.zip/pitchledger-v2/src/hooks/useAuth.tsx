import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export interface Profile {
  id: string;
  full_name: string | null;
  birthdate: string | null;
  role: 'player' | 'parent' | 'coach' | 'trainer' | null;
  subscription_tier: string | null;
  team_code: string | null;
  invite_code: string | null;
  team_name: string | null;
  coach_name: string | null;
  pitch_arsenal: string[] | null;
  throwing_hand: string | null;
  share_health_data: boolean;
}

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  profile: null,
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase
      .from('profiles')
      .select('id, full_name, birthdate, role, subscription_tier, team_code, invite_code, team_name, coach_name, pitch_arsenal, throwing_hand, share_health_data')
      .eq('id', userId)
      .single();
    setProfile(data as Profile | null);
  };

  const refreshProfile = async () => {
    if (session?.user?.id) await fetchProfile(session.user.id);
  };

  const handleInviteCode = async (userId: string) => {
    const code = localStorage.getItem('invite_code');
    if (!code) return;
    localStorage.removeItem('invite_code');
    try {
      const { data: coach } = await supabase.rpc('find_coach_by_team_code', { code });
      if (coach && coach.length > 0) {
        await supabase.from('connections').insert({
          player_id: userId,
          connected_user_id: coach[0].coach_id,
          connection_type: 'team',
          status: 'pending',
        });
      }
    } catch (e) {
      console.error('Auto-connect failed:', e);
    }
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        if (session?.user) {
          setTimeout(async () => {
            await fetchProfile(session.user.id);
            if (event === 'SIGNED_IN') await handleInviteCode(session.user.id);
          }, 0);
        } else {
          setProfile(null);
        }
        setLoading(false);
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) fetchProfile(session.user.id);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ session, user: session?.user ?? null, profile, loading, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
