import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { calculateAge } from '@/lib/age';
import { toast } from 'sonner';

export type TrafficLight = 'green' | 'yellow' | 'red';

export interface RosterPlayer {
  id: string;
  full_name: string;
  age: number;
  role: string;
  connectionId: string;
  connectionType: string;
  shareHealthData: boolean;
  trafficLight: TrafficLight;
  recentPitches: number;
  lastBullpenVelo: number | null;
  currentArmFeel: string | null;
}

export interface PlayerPitchLog {
  id: string;
  date: string | null;
  pitch_count: number;
  innings: number | null;
  session_type: string | null;
  velo: number | null;
  notes: string | null;
  arm_feel: string | null;
  strikes: number | null;
}

export interface PendingConnection {
  id: string;
  connected_user_id: string;
  connection_type: string;
  created_at: string;
  connectedUserName?: string;
}

export function useConnections() {
  const { user, profile } = useAuth();
  const [roster, setRoster] = useState<RosterPlayer[]>([]);
  const [pendingRequests, setPendingRequests] = useState<PendingConnection[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRoster = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    // Fetch active connections where this user is connected_user_id (coach/trainer viewing players)
    const { data: connections } = await supabase
      .from('connections')
      .select('id, player_id, connection_type')
      .eq('connected_user_id', user.id)
      .eq('status', 'active');

    if (connections && connections.length > 0) {
      const playerIds = connections.map(c => c.player_id).filter(Boolean) as string[];
      // Only fetch non-sensitive fields
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name, role, birthdate, share_health_data')
        .in('id', playerIds);

      // Fetch 48hr pitch data for traffic light
      const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString().split('T')[0];
      const { data: recentLogs } = await supabase
        .from('pitch_logs')
        .select('player_id, pitch_count, arm_feel, velo, session_type, date')
        .in('player_id', playerIds)
        .gte('date', cutoff);

      // Fetch last bullpen log per player (for velo)
      const { data: allLogs } = await supabase
        .from('pitch_logs')
        .select('player_id, velo, arm_feel, session_type, date')
        .in('player_id', playerIds)
        .order('date', { ascending: false });

      if (profiles) {
        const rosterItems: RosterPlayer[] = profiles.map(p => {
          const conn = connections.find(c => c.player_id === p.id);
          const playerLogs = (recentLogs ?? []).filter(l => l.player_id === p.id);
          const totalPitches = playerLogs.reduce((s, l) => s + (l.pitch_count ?? 0), 0);
          const hasSore = playerLogs.some(l => l.arm_feel?.toLowerCase() === 'sore');

          let trafficLight: TrafficLight = 'green';
          if (totalPitches >= 76 || hasSore) trafficLight = 'red';
          else if (totalPitches >= 31) trafficLight = 'yellow';

          // Last bullpen velo
          const playerAllLogs = (allLogs ?? []).filter(l => l.player_id === p.id);
          const lastBullpen = playerAllLogs.find(l => l.session_type === 'bullpen' && l.velo);
          
          // Most recent arm feel
          const latestLog = playerLogs[0];

          return {
            id: p.id,
            full_name: p.full_name ?? 'Unknown',
            age: p.birthdate ? calculateAge(p.birthdate) : 0,
            role: p.role ?? 'player',
            connectionId: conn?.id ?? '',
            connectionType: conn?.connection_type ?? 'team',
            shareHealthData: (p as any).share_health_data ?? false,
            trafficLight,
            recentPitches: totalPitches,
            lastBullpenVelo: lastBullpen?.velo ?? null,
            currentArmFeel: latestLog?.arm_feel ?? null,
          };
        });
        setRoster(rosterItems);
      }
    } else {
      setRoster([]);
    }

    // Fetch pending requests for players
    if (profile?.role === 'player' || profile?.role === 'parent') {
      const { data: pending } = await supabase
        .from('connections')
        .select('id, connected_user_id, connection_type, created_at')
        .eq('player_id', user.id)
        .eq('status', 'pending');

      if (pending && pending.length > 0) {
        const userIds = pending.map(p => p.connected_user_id).filter(Boolean) as string[];
        const { data: connProfiles } = await supabase
          .from('profiles')
          .select('id, full_name')
          .in('id', userIds);

        const enriched = pending.map(p => ({
          ...p,
          connectedUserName: connProfiles?.find(pr => pr.id === p.connected_user_id)?.full_name ?? 'Unknown',
        }));
        setPendingRequests(enriched);
      } else {
        setPendingRequests([]);
      }
    }

    setLoading(false);
  }, [user, profile]);

  useEffect(() => {
    fetchRoster();
  }, [fetchRoster]);

  // Real-time subscription for connections changes
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel('connections-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'connections' }, () => {
        fetchRoster();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user, fetchRoster]);

  const generateTeamCode = async () => {
    if (!user) return;
    const { data } = await supabase.rpc('generate_team_code');
    if (data) {
      const { error } = await supabase
        .from('profiles')
        .update({ team_code: data })
        .eq('id', user.id);
      if (error) {
        toast.error('Failed to generate team code');
      } else {
        toast.success(`Team code generated: ${data}`);
      }
    }
  };

  const joinTeam = async (code: string): Promise<{ success: boolean; limitReached?: boolean }> => {
    if (!user) return { success: false };

    // Check free tier limits
    if (profile?.subscription_tier === 'free') {
      const { data: count } = await supabase.rpc('count_player_connections', {
        p_player_id: user.id,
        p_type: 'team',
      });
      if ((count ?? 0) >= 2) {
        return { success: false, limitReached: true };
      }
    }

    // Find coach by team code
    const { data: coach } = await supabase.rpc('find_coach_by_team_code', { code: code.toUpperCase() });
    if (!coach || coach.length === 0) {
      toast.error('No coach found with that team code');
      return { success: false };
    }

    const coachId = coach[0].coach_id;

    // Create connection
    const { error } = await supabase
      .from('connections')
      .insert({
        player_id: user.id,
        connected_user_id: coachId,
        connection_type: 'team',
        status: 'active',
      });

    if (error) {
      if (error.code === '23505') {
        toast.error('You are already connected to this team');
      } else {
        toast.error('Failed to join team');
      }
      return { success: false };
    }

    toast.success('Successfully joined team!');
    await fetchRoster();
    return { success: true };
  };

  const sendTrainerRequest = async (email: string): Promise<{ success: boolean; limitReached?: boolean }> => {
    if (!user) return { success: false };

    // Find player by email
    const { data: player } = await supabase.rpc('find_player_by_email', { lookup_email: email });
    if (!player || player.length === 0) {
      toast.error('No player found with that email');
      return { success: false };
    }

    const playerId = player[0].player_id;

    // Check free tier limits for the player
    const { data: count } = await supabase.rpc('count_player_connections', {
      p_player_id: playerId,
      p_type: 'trainer',
    });

    // We'll check on accept, but also warn upfront
    const { error } = await supabase
      .from('connections')
      .insert({
        player_id: playerId,
        connected_user_id: user.id,
        connection_type: 'trainer',
        status: 'pending',
      });

    if (error) {
      if (error.code === '23505') {
        toast.error('Connection request already exists');
      } else {
        toast.error('Failed to send connection request');
      }
      return { success: false };
    }

    toast.success(`Connection request sent to ${player[0].player_name}`);
    return { success: true };
  };

  const acceptConnection = async (connectionId: string): Promise<{ success: boolean; limitReached?: boolean }> => {
    if (!user) return { success: false };

    // Get connection details
    const { data: conn } = await supabase
      .from('connections')
      .select('*')
      .eq('id', connectionId)
      .single();

    if (!conn) return { success: false };

    // Check free tier limits
    if (profile?.subscription_tier === 'free') {
      const { data: count } = await supabase.rpc('count_player_connections', {
        p_player_id: user.id,
        p_type: conn.connection_type ?? 'trainer',
      });
      const limit = conn.connection_type === 'team' ? 2 : 1;
      if ((count ?? 0) >= limit) {
        return { success: false, limitReached: true };
      }
    }

    const { error } = await supabase
      .from('connections')
      .update({ status: 'active' })
      .eq('id', connectionId);

    if (error) {
      toast.error('Failed to accept connection');
      return { success: false };
    }

    toast.success('Connection accepted!');
    await fetchRoster();
    return { success: true };
  };

  const rejectConnection = async (connectionId: string) => {
    const { error } = await supabase
      .from('connections')
      .delete()
      .eq('id', connectionId);

    if (error) {
      toast.error('Failed to reject connection');
    } else {
      toast.success('Connection rejected');
      await fetchRoster();
    }
  };

  const removeConnection = async (connectionId: string) => {
    const { error } = await supabase
      .from('connections')
      .delete()
      .eq('id', connectionId);

    if (error) {
      toast.error('Failed to remove connection');
    } else {
      toast.success('Connection removed');
      await fetchRoster();
    }
  };

  return {
    roster,
    pendingRequests,
    loading,
    generateTeamCode,
    joinTeam,
    sendTrainerRequest,
    acceptConnection,
    rejectConnection,
    removeConnection,
    refresh: fetchRoster,
  };
}
