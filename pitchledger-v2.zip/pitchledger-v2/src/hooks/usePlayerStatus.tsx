import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { calculateAge } from '@/lib/age';
import {
  calculateAvailability,
  getDailyMax,
  armFeelToSoreness,
  AvailabilityResult,
  PitchLogEntry,
} from '@/lib/pitchSmartEngine';
import { startOfDay, subDays, differenceInHours, differenceInMinutes } from 'date-fns';

// ── Season / Yearly Limits by age bracket ──
const seasonLimits: Record<string, number> = {
  '7-8': 1000,
  '9-10': 2000,
  '11-12': 3000,
  '13-14': 3000,
  '15-16': 3500,
  '17-18': 4000,
  '19-22': 4500,
};

function getSeasonLimit(age: number): number {
  if (age <= 8) return seasonLimits['7-8'];
  if (age <= 10) return seasonLimits['9-10'];
  if (age <= 12) return seasonLimits['11-12'];
  if (age <= 14) return seasonLimits['13-14'];
  if (age <= 16) return seasonLimits['15-16'];
  if (age <= 18) return seasonLimits['17-18'];
  return seasonLimits['19-22'];
}

export interface PlayerStatusResult {
  availability: AvailabilityResult;
  todayPitches: number;
  yearlyPitches: number;
  seasonLimit: number;
  yearlyPercent: number;
  dailyMax: number;
  age: number;
  hoursUntilEligible: number;
  minutesUntilEligible: number;
  sorenessTrend: { date: string; value: number }[];
  loading: boolean;
  refetch: () => void;
}

const defaultAvailability: AvailabilityResult = {
  status: 'FRESH',
  eligibleDate: null,
  daysUntilEligible: 0,
  reason: 'No recent sessions',
  restDays: 0,
  sorenessValue: 0,
};

/**
 * Reactive hook that pulls the latest pitch data for a given player
 * and computes PitchSmart availability, yearly workload, and soreness trends.
 * Subscribes to real-time inserts on pitch_logs for live updates.
 */
export function usePlayerStatus(playerId?: string, birthdate?: string | null): PlayerStatusResult {
  const [availability, setAvailability] = useState<AvailabilityResult>(defaultAvailability);
  const [todayPitches, setTodayPitches] = useState(0);
  const [yearlyPitches, setYearlyPitches] = useState(0);
  const [sorenessTrend, setSorenessTrend] = useState<{ date: string; value: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);

  const age = birthdate ? calculateAge(birthdate) : 14;
  const sLimit = getSeasonLimit(age);
  const dMax = getDailyMax(age);

  const refetch = useCallback(() => setTick(t => t + 1), []);

  useEffect(() => {
    if (!playerId) { setLoading(false); return; }

    let cancelled = false;
    const run = async () => {
      setLoading(true);

      const { data: logs } = await supabase
        .from('pitch_logs')
        .select('date, pitch_count, arm_feel')
        .eq('player_id', playerId)
        .order('date', { ascending: false })
        .limit(30);

      if (cancelled) return;

      if (!logs || logs.length === 0) {
        setAvailability(defaultAvailability);
        setTodayPitches(0);
        setYearlyPitches(0);
        setSorenessTrend([]);
        setLoading(false);
        return;
      }

      // Availability from last log
      const lastLog: PitchLogEntry = logs[0];
      const avail = calculateAvailability(lastLog, age);
      setAvailability(avail);

      // Today's pitches
      const todayStr = startOfDay(new Date()).toISOString().split('T')[0];
      const todayLogs = logs.filter(l => l.date === todayStr);
      setTodayPitches(todayLogs.reduce((s, l) => s + (l.pitch_count ?? 0), 0));

      // Yearly pitches
      const yearStart = `${new Date().getFullYear()}-01-01`;
      const { data: yearLogs } = await supabase
        .from('pitch_logs')
        .select('pitch_count')
        .eq('player_id', playerId)
        .gte('date', yearStart);

      if (!cancelled && yearLogs) {
        setYearlyPitches(yearLogs.reduce((s, l) => s + (l.pitch_count ?? 0), 0));
      }

      // Soreness trend (last 10)
      const { format: fmtDate, parseISO: pISO } = await import('date-fns');
      const trend = logs
        .slice(0, 10)
        .reverse()
        .map(l => ({
          date: l.date ? fmtDate(pISO(l.date), 'M/d') : '?',
          value: armFeelToSoreness(l.arm_feel),
        }));
      if (!cancelled) setSorenessTrend(trend);

      setLoading(false);
    };
    run();

    // Real-time subscription
    const channel = supabase
      .channel(`player-status-${playerId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'pitch_logs', filter: `player_id=eq.${playerId}` },
        () => { if (!cancelled) setTick(t => t + 1); }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [playerId, age, tick]);

  // Time until eligible
  let hoursUntilEligible = 0;
  let minutesUntilEligible = 0;
  if (availability.eligibleDate) {
    hoursUntilEligible = Math.max(0, differenceInHours(availability.eligibleDate, new Date()));
    minutesUntilEligible = Math.max(0, differenceInMinutes(availability.eligibleDate, new Date()) % 60);
  }

  return {
    availability,
    todayPitches,
    yearlyPitches,
    seasonLimit: sLimit,
    yearlyPercent: sLimit > 0 ? Math.min(100, Math.round((yearlyPitches / sLimit) * 100)) : 0,
    dailyMax: dMax,
    age,
    hoursUntilEligible,
    minutesUntilEligible,
    sorenessTrend,
    loading,
    refetch,
  };
}
