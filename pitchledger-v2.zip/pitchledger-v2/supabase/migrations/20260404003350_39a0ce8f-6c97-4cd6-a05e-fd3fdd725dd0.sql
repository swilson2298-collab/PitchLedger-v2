
-- Fix search_path on generate_team_code
CREATE OR REPLACE FUNCTION public.generate_team_code()
RETURNS text
LANGUAGE sql
VOLATILE
SET search_path = public
AS $$
  SELECT upper(substr(md5(random()::text), 1, 6))
$$;

-- Fix search_path on protect_user_roles
CREATE OR REPLACE FUNCTION public.protect_user_roles()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
begin
  if (old.role <> new.role or old.subscription_tier <> new.subscription_tier) then
    if (current_setting('role') <> 'service_role') then
      raise exception 'You do not have permission to change your Role or Subscription Tier.';
    end if;
  end if;
  return new;
end;
$$;
