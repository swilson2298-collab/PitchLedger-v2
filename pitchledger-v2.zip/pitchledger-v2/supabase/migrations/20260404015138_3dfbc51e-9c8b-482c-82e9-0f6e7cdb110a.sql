
-- ============================================
-- 1. PROFILES: Replace ALL policies with granular ones
-- ============================================

-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Users can manage own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users manage own profile" ON public.profiles;

-- Keep existing SELECT policies (they're fine), add INSERT/UPDATE/DELETE

-- Users can insert their own profile (signup trigger does this, but just in case)
CREATE POLICY "Users can insert own profile"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

-- Users can update ONLY safe columns on their own profile
-- We use a WITH CHECK that ensures protected fields haven't changed
CREATE POLICY "Users can update own safe fields"
ON public.profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Users can delete their own profile
CREATE POLICY "Users can delete own profile"
ON public.profiles
FOR DELETE
TO authenticated
USING (auth.uid() = id);

-- ============================================
-- 2. CONNECTIONS: Fix update policy so only recipient can approve
-- ============================================

-- Drop the broken policy
DROP POLICY IF EXISTS "Players can update own connections" ON public.connections;

-- Only the recipient (connected_user_id) can update, and only pending connections
CREATE POLICY "Recipients can update pending connections"
ON public.connections
FOR UPDATE
TO authenticated
USING (auth.uid() = connected_user_id AND status = 'pending')
WITH CHECK (auth.uid() = connected_user_id);

-- ============================================
-- 3. PUBLIC_PLAYER_SEARCH: Recreate as security invoker = false
-- ============================================

DROP VIEW IF EXISTS public.public_player_search;

CREATE VIEW public.public_player_search
WITH (security_invoker = false)
AS
SELECT id, full_name, role
FROM public.profiles
WHERE role = 'player';

-- Grant access only to authenticated users
REVOKE ALL ON public.public_player_search FROM anon;
GRANT SELECT ON public.public_player_search TO authenticated;
