
-- Create the security definer function for coach visibility
CREATE OR REPLACE FUNCTION public.get_connected_player_ids(_coach_id uuid)
RETURNS SETOF uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT player_id FROM public.connections
  WHERE connected_user_id = _coach_id
    AND status = 'active'
    AND player_id IS NOT NULL;
$$;

-- Recreate the safe coach policy
DROP POLICY IF EXISTS "Coaches can view connected player profiles" ON public.profiles;
CREATE POLICY "Coaches can view connected player profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  id IN (SELECT public.get_connected_player_ids(auth.uid()))
);
