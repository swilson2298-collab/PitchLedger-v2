
-- public_player_search is a VIEW, not a table, so we can't add RLS policies.
-- Instead, recreate it with security_invoker = true so it uses the caller's permissions.
-- First drop and recreate with proper security settings.

DROP VIEW IF EXISTS public.public_player_search;

CREATE VIEW public.public_player_search 
WITH (security_invoker = true)
AS
  SELECT id, full_name, role
  FROM public.profiles
  WHERE role IN ('player', 'parent');
