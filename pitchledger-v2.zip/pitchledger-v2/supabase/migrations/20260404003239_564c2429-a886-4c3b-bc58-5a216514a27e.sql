
-- Function to generate a random 6-char uppercase team code
CREATE OR REPLACE FUNCTION public.generate_team_code()
RETURNS text
LANGUAGE sql
VOLATILE
AS $$
  SELECT upper(substr(md5(random()::text), 1, 6))
$$;

-- Security definer function to find a player by email (for trainer connection requests)
-- Returns only id and full_name, never sensitive data
CREATE OR REPLACE FUNCTION public.find_player_by_email(lookup_email text)
RETURNS TABLE(player_id uuid, player_name text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.full_name
  FROM auth.users u
  JOIN public.profiles p ON p.id = u.id
  WHERE u.email = lookup_email
    AND (p.role = 'player' OR p.role = 'parent')
  LIMIT 1;
$$;

-- Security definer function to find coach by team_code
CREATE OR REPLACE FUNCTION public.find_coach_by_team_code(code text)
RETURNS TABLE(coach_id uuid, coach_name text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.full_name
  FROM public.profiles p
  WHERE p.team_code = upper(code)
    AND p.role = 'coach'
  LIMIT 1;
$$;

-- Count active connections for a player (for free tier limits)
CREATE OR REPLACE FUNCTION public.count_player_connections(p_player_id uuid, p_type text)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::integer
  FROM public.connections
  WHERE player_id = p_player_id
    AND connection_type = p_type
    AND status = 'active';
$$;

-- Allow trainers to insert connection requests (trainer is connected_user_id)
CREATE POLICY "Trainers can send connection requests"
ON public.connections
FOR INSERT
WITH CHECK (auth.uid() = connected_user_id AND connection_type = 'trainer');

-- Allow players to update their own connection status (accept/reject)
CREATE POLICY "Players can update own connections"
ON public.connections
FOR UPDATE
USING (auth.uid() = player_id);

-- Allow either party to delete a connection
CREATE POLICY "Users can delete own connections"
ON public.connections
FOR DELETE
USING (auth.uid() = player_id OR auth.uid() = connected_user_id);
