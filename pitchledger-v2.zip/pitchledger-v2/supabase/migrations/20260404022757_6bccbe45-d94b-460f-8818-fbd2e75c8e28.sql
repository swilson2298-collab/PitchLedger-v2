-- Allow players to auto-connect via a valid team code
-- Uses the existing SECURITY DEFINER function find_coach_by_team_code
CREATE POLICY "Players can auto-connect via team code"
ON public.connections
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = player_id
  AND connection_type = 'team'
  AND status = 'active'
  AND connected_user_id IN (
    SELECT coach_id FROM public.find_coach_by_team_code(
      -- We validate the coach exists; the connected_user_id must match
      -- This allows insert only if the connected_user_id is a real coach with a team code
      ''
    )
  ) IS NOT TRUE
  -- Simplified: just ensure the player is inserting for themselves with a valid coach
  AND EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = connected_user_id
      AND role = 'coach'
      AND team_code IS NOT NULL
  )
);