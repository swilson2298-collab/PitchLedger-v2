CREATE OR REPLACE FUNCTION public.can_player_add_connection(p_id uuid, c_type text)
RETURNS boolean
LANGUAGE plpgsql
SET search_path = public
AS $$
declare
  v_tier text;
  v_count integer;
begin
  select subscription_tier into v_tier from profiles where id = p_id;
  if v_tier != 'free' then return true; end if;
  select count(*) into v_count from connections 
  where player_id = p_id and connection_type = c_type and status = 'active';
  if c_type = 'team' and v_count >= 2 then return false; end if;
  if c_type = 'trainer' and v_count >= 1 then return false; end if;
  return true;
end;
$$;

CREATE OR REPLACE FUNCTION public.force_read_only_tier()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
begin
  if (TG_OP = 'INSERT') then return new; end if;
  if (old.subscription_tier IS DISTINCT FROM new.subscription_tier or old.role <> new.role) then
    if (current_setting('role', true) <> 'service_role') then
      raise exception 'Protected fields (Tier/Role) can only be updated by the system.';
    end if;
  end if;
  return new;
end;
$$;