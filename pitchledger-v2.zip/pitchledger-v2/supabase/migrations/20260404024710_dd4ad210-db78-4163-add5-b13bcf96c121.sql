
-- =============================================
-- PROFILES: Remove all stale/public policies
-- =============================================

-- Drop stale broad coach policies (should have been dropped earlier but survived)
DROP POLICY IF EXISTS "Coaches can view team members" ON public.profiles;
DROP POLICY IF EXISTS "Coaches view connected players" ON public.profiles;
DROP POLICY IF EXISTS "Coaches can view limited team member data" ON public.profiles;

-- Drop public-role "view own profile" and recreate as authenticated-only
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- =============================================
-- CONNECTIONS: Tighten all policies to authenticated
-- =============================================

-- Drop old trainer INSERT policy (public, no player validation)
DROP POLICY IF EXISTS "Trainers can send connection requests" ON public.connections;

-- Recreate with proper constraints
CREATE POLICY "Trainers can send connection requests"
ON public.connections
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = connected_user_id
  AND connection_type = 'trainer'
  AND status = 'pending'
  AND EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = player_id
      AND (role = 'player' OR role = 'parent')
  )
);

-- Drop old public-role player INSERT policy and recreate as authenticated
DROP POLICY IF EXISTS "Players can add team if under limit" ON public.connections;
CREATE POLICY "Players can add team if under limit"
ON public.connections
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = player_id
  AND can_player_add_connection(player_id, connection_type)
);

-- Fix duplicate SELECT policies - keep one, authenticated
DROP POLICY IF EXISTS "Users can view own connections" ON public.connections;
DROP POLICY IF EXISTS "Users can view their active connections" ON public.connections;
CREATE POLICY "Users can view own connections"
ON public.connections
FOR SELECT
TO authenticated
USING (auth.uid() = player_id OR auth.uid() = connected_user_id);

-- Fix duplicate DELETE policies - keep one, authenticated
DROP POLICY IF EXISTS "Users can delete own connections" ON public.connections;
DROP POLICY IF EXISTS "Users can delete their own connections" ON public.connections;
CREATE POLICY "Users can delete own connections"
ON public.connections
FOR DELETE
TO authenticated
USING (auth.uid() = player_id OR auth.uid() = connected_user_id);

-- =============================================
-- PITCH_LOGS: Tighten to authenticated
-- =============================================

-- Drop duplicate policies
DROP POLICY IF EXISTS "Players can manage own logs" ON public.pitch_logs;
DROP POLICY IF EXISTS "Players manage own logs" ON public.pitch_logs;
DROP POLICY IF EXISTS "Coaches and Trainers can view connected logs" ON public.pitch_logs;
DROP POLICY IF EXISTS "Staff view connected logs" ON public.pitch_logs;

-- Recreate as authenticated-only
CREATE POLICY "Players manage own logs"
ON public.pitch_logs
FOR ALL
TO authenticated
USING (auth.uid() = player_id);

CREATE POLICY "Staff view connected logs"
ON public.pitch_logs
FOR SELECT
TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.connections
  WHERE connections.connected_user_id = auth.uid()
    AND connections.player_id = pitch_logs.player_id
    AND connections.status = 'active'
));
